/* ============================================================
 *  app.js —— 知识星空 v4.7
 *  星空：宇宙（L0）→ 银河（L1）→ 星云（L2）→ 星团（L3+）
 *  星云卡片排布：四尺度混合流形
 *    · 宏观：鞍面 / 球谐片段
 *    · 中观：双频波纹
 *    · 微观：分形噪声（fbm）
 *    · 特征：局部高斯凸起 / 凹陷
 *
 *  学习视图左侧栏：领域目录树（分级筛选）
 * ============================================================ */
(function () {
  'use strict';

  var TAU = Math.PI * 2;
  var DAY = 86400000;

  var STORE_DATA     = 'kstar.data.v1';
  var STORE_PROGRESS = 'kstar.progress.v1';
  var STORE_VIEW     = 'kstar.view.v1';

  var PALETTE = ['#7d9bff', '#5ec8f5', '#6ee7b7', '#f0d264',
                 '#f0a07d', '#c99bff', '#7dd3fc', '#fca5a5'];

  var EMPTY_DATA = {
    meta: { title: '知识星空', version: '4.7', updatedAt: '' },
    decks: []
  };

  /* 多层级布局参数 */
  var UNIVERSE_GAP      = 2400;
  var UNIVERSE_RADIUS   = 1400;
  var GALAXY_RADIUS     = 620;
  var NEBULA_RADIUS     = 150;
  var ARM_COUNT         = 2;
  var ARM_TWIST         = 2.9;
  var GALAXY_TILT_MAX   = 0.42;
  var WAVE_AMP          = 0.55;
  var WAVE_FREQ         = 1.6;

  var SPIN_SPEED = { 0: 0.08, 1: 0.16, 2: 0.28 };
  var SPIN_SPEED_DEEP = 0.10;

  var BASE_SIZE          = 2.6;
  var MASTERY_SIZE_BONUS = 2.4;
  var DEGREE_SIZE_BONUS  = 5.2;

  var $  = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }

  function fmt(s) {
    var out = esc(s);
    out = out.replace(/`([^`]+)`/g, '<code>$1</code>');
    out = out.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
    out = out.replace(/\n/g, '<br>');
    return out;
  }

  function truncate(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  function dateKey(d) {
    d = d || new Date();
    return d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0');
  }

  function hashStr(s) {
    var h = 2166136261;
    s = String(s);
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0) / 4294967295;
  }

  function spinSpeedForLevel(level) {
    if (level <= 0) return SPIN_SPEED[0];
    if (level === 1) return SPIN_SPEED[1];
    if (level === 2) return SPIN_SPEED[2];
    return SPIN_SPEED[2] + SPIN_SPEED_DEEP * (level - 2);
  }

  /* ---- 分形噪声 ---- */
  function noise2D(x, y, seed) {
    seed = seed || 0;
    var ix = Math.floor(x);
    var iy = Math.floor(y);
    var fx = x - ix;
    var fy = y - iy;

    var ux = fx * fx * fx * (fx * (fx * 6 - 15) + 10);
    var uy = fy * fy * fy * (fy * (fy * 6 - 15) + 10);

    function hash(ix, iy) {
      var h = Math.imul(ix | 0, 374761393) +
              Math.imul(iy | 0, 668265263) +
              Math.imul(seed | 0, 982451653);
      h = Math.imul(h ^ (h >>> 13), 1274126177);
      h = h ^ (h >>> 16);
      return (h >>> 0) / 4294967295;
    }

    var a = hash(ix,     iy);
    var b = hash(ix + 1, iy);
    var c = hash(ix,     iy + 1);
    var d = hash(ix + 1, iy + 1);

    return (a * (1 - ux) + b * ux) * (1 - uy) +
           (c * (1 - ux) + d * ux) * uy;
  }

  function fbm2D(x, y, octaves, seed) {
    var total = 0;
    var amp = 1;
    var freq = 1;
    var maxTotal = 0;
    for (var i = 0; i < octaves; i++) {
      total += amp * (noise2D(x * freq, y * freq, (seed || 0) + i * 31) - 0.5);
      maxTotal += amp;
      amp *= 0.5;
      freq *= 2;
    }
    return total / (maxTotal || 1);
  }

  /* ---- KaTeX 渲染 ---- */
  function renderKatex(src, display) {
    if (typeof katex === 'undefined') {
      return '<span class="formula-raw">' + esc(src) + '</span>';
    }
    try {
      return katex.renderToString(src, {
        throwOnError: false,
        displayMode: !!display,
        output: 'html'
      });
    } catch (e) {
      return '<span class="formula-error">' + esc(src) + '</span>';
    }
  }

  function renderMixedLatex(src) {
    var out = '';
    var buf = '';
    var i = 0;
    while (i < src.length) {
      if (src[i] === '$') {
        if (buf) { out += esc(buf).replace(/\n/g, '<br>'); buf = ''; }
        var isBlock = src[i + 1] === '$';
        var start = i + (isBlock ? 2 : 1);
        var closeTag = isBlock ? '$$' : '$';
        var end = src.indexOf(closeTag, start);
        if (end < 0) { buf += src.slice(i); break; }
        out += renderKatex(src.slice(start, end), isBlock);
        i = end + closeTag.length;
      } else {
        buf += src[i];
        i++;
      }
    }
    if (buf) out += esc(buf).replace(/\n/g, '<br>');
    return out;
  }

  function renderFormula(latex) {
    if (!latex || !String(latex).trim()) return '';
    var src = String(latex).trim();
    if (src.indexOf('$') >= 0) return renderMixedLatex(src);
    return renderKatex(src, true);
  }

  /* ---------------- 状态 ---------------- */
  var state = {
    data: null,
    decks: [],
    cards: [],
    cardMap: new Map(),
    galaxy: null,
    progress: null,
    view: 'study',
    studyOrder: [],
    studyIndex: 0,
    selected: null,
    flipped: false,
    filterDeck: 'all',
    filterTags: new Set(),
    search: '',
    editing: false,
    sideOpen: false,
    backTab: 'answer',
    panelTab: 'answer',
    _lastCardId: null,
    _lastPanelId: null,

    /* ★ 学习视图左侧领域目录树：折叠状态 */
    deckTreeCollapsed: {},

    idxFilters: {
      search: '',
      decks: new Set(),
      tags: new Set(),
      states: new Set(),
      collapsedDecks: new Set()
    },
    idxSelected: new Set(),

    customSet: null,
    studySource: 'all'
  };

  /* ---- 进度管理 ---- */
  function defaultRec() {
    return {
      ease: 2.5, interval: 0, reps: 0, lapses: 0,
      due: 0, starred: false, lastGrade: null, lastAt: 0
    };
  }

  function loadProgress() {
    try {
      var raw = localStorage.getItem(STORE_PROGRESS);
      if (raw) {
        var p = JSON.parse(raw);
        return {
          cards: p.cards || {},
          stats: p.stats || { days: {} },
          settings: p.settings || {}
        };
      }
    } catch (e) {}
    return { cards: {}, stats: { days: {} }, settings: {} };
  }

  function saveProgress() {
    try {
      localStorage.setItem(STORE_PROGRESS, JSON.stringify(state.progress));
    } catch (e) {}
  }

  function getRec(id) { return state.progress.cards[id] || defaultRec(); }
  function recOf(id) {
    if (!state.progress.cards[id]) state.progress.cards[id] = defaultRec();
    return state.progress.cards[id];
  }
  function isDue(id) {
    var r = getRec(id);
    return r.reps === 0 || r.due <= Date.now();
  }
  function masteryOf(rec) {
    if (!rec || !rec.reps) return 0;
    var r = Math.min(1, rec.reps / 6);
    var i = Math.min(1, rec.interval / 60);
    var e = clamp((rec.ease - 1.3) / (3.0 - 1.3), 0, 1);
    return clamp(0.55 * r + 0.30 * i + 0.15 * e, 0, 1);
  }
  function masteryOfCard(id) { return masteryOf(getRec(id)); }

  /* ---- 间隔重复 ---- */
  function schedule(rec, g) {
    var ease     = rec.ease || 2.5;
    var interval = rec.interval || 0;
    var reps     = rec.reps || 0;
    var lapses   = rec.lapses || 0;
    var now      = Date.now();

    if (g === 0) {
      reps = 0; interval = 0; lapses++;
      ease = Math.max(1.3, ease - 0.2);
    } else {
      reps++;
      if (reps === 1) interval = g === 3 ? 3 : 1;
      else if (reps === 2) interval = g === 3 ? 7 : (g === 1 ? 3 : 5);
      else {
        var f = g === 1 ? 0.62 : (g === 3 ? 1.35 : 1);
        interval = Math.max(1, Math.round(interval * ease * f));
      }
      ease = Math.max(1.3, ease + (g === 1 ? -0.15 : (g === 3 ? 0.12 : 0)));
      interval = Math.min(interval, 365);
    }

    return {
      ease: ease, interval: interval, reps: reps, lapses: lapses,
      due: g === 0 ? now + 60000 : now + interval * DAY,
      lastGrade: g, lastAt: now, starred: !!rec.starred
    };
  }

  /* ---- 数据加载 ---- */
  function loadData() {
    try {
      var saved = localStorage.getItem(STORE_DATA);
      if (saved) {
        var j = JSON.parse(saved);
        if (j && Array.isArray(j.decks)) return Promise.resolve(j);
      }
    } catch (e) {}
    return Promise.resolve(JSON.parse(JSON.stringify(EMPTY_DATA)));
  }

  function normalize(json) {
    if (!json || typeof json !== 'object') {
      json = JSON.parse(JSON.stringify(EMPTY_DATA));
    }
    if (!json.meta || typeof json.meta !== 'object') {
      json.meta = { title: '知识星空', version: '4.7' };
    }
    if (!Array.isArray(json.decks)) json.decks = [];

    var seenIds = new Set();
    json.decks.forEach(function (deck, di) {
      if (!deck.id || seenIds.has(deck.id)) {
        deck.id = 'deck-' + di + '-' + Math.random().toString(36).slice(2, 6);
      }
      seenIds.add(deck.id);
      if (!deck.name)  deck.name = '未命名领域';
      if (!deck.color) deck.color = PALETTE[di % PALETTE.length];
      if (deck.parentId === undefined) deck.parentId = null;
      if (deck.parentId === '') deck.parentId = null;
      if (!Array.isArray(deck.cards)) deck.cards = [];

      deck.cards.forEach(function (c, ci) {
        if (!c.id) c.id = deck.id + '-' + ci;
        if (!Array.isArray(c.tags))  c.tags = [];
        if (!Array.isArray(c.links)) c.links = [];
        c.front   = c.front   == null ? '' : String(c.front);
        c.back    = c.back    == null ? '' : String(c.back);
        c.formula = c.formula == null ? '' : String(c.formula);
        c.hint    = c.hint    == null ? '' : String(c.hint);
      });
    });

    var idSet = {};
    json.decks.forEach(function (d) { idSet[d.id] = true; });
    json.decks.forEach(function (d) {
      if (d.parentId && (!idSet[d.parentId] || d.parentId === d.id)) {
        d.parentId = null;
      }
    });

    return json;
  }

  function flatten(json) {
    var out = [];
    (json.decks || []).forEach(function (deck) {
      (deck.cards || []).forEach(function (c) {
        out.push({
          id: c.id, front: c.front, back: c.back,
          formula: c.formula || '',
          tags: c.tags || [], links: c.links || [],
          hint: c.hint || '',
          deckId: deck.id, deckName: deck.name, deckColor: deck.color
        });
      });
    });
    return out;
  }

  /* ---- 筛选 ---- */
  function getDescendantIds(deckId) {
    var set = new Set([deckId]);
    var queue = [deckId];
    var guard = 0;
    while (queue.length && guard++ < 5000) {
      var id = queue.shift();
      state.decks.forEach(function (d) {
        if (d.parentId === id && !set.has(d.id)) {
          set.add(d.id);
          queue.push(d.id);
        }
      });
    }
    return set;
  }

  function getDeckById(id) {
    if (!id) return null;
    for (var i = 0; i < state.decks.length; i++) {
      if (state.decks[i].id === id) return state.decks[i];
    }
    return null;
  }

  function getPath(deckId) {
    var parts = [];
    var cur = getDeckById(deckId);
    var guard = 0;
    while (cur && guard++ < 50) {
      parts.unshift(cur.name);
      cur = cur.parentId ? getDeckById(cur.parentId) : null;
    }
    return parts.join(' / ');
  }

  function visibleCards() {
    var list = state.cards;

    if (state.studySource === 'custom' && state.customSet) {
      return list.filter(function (c) { return state.customSet.has(c.id); });
    }

    if (state.filterDeck !== 'all') {
      var ids = getDescendantIds(state.filterDeck);
      list = list.filter(function (c) { return ids.has(c.deckId); });
    }

    if (state.filterTags.size > 0) {
      list = list.filter(function (c) {
        return (c.tags || []).some(function (t) { return state.filterTags.has(t); });
      });
    }

    var q = state.search.trim().toLowerCase();
    if (q) {
      list = list.filter(function (c) {
        var hay = (c.front + ' ' + c.back + ' ' + (c.formula || '') + ' ' +
                   c.tags.join(' ') + ' ' + c.deckName).toLowerCase();
        return hay.indexOf(q) >= 0;
      });
    }
    return list;
  }

  /* ---- 视图切换 ---- */
  function applyViewUI(v) {
    $$('.vs-btn').forEach(function (b) {
      b.classList.toggle('active', b.dataset.view === v);
    });
    var vs = $('#viewStudy');
    var vg = $('#viewGalaxy');
    var vi = $('#viewIndex');
    if (vs) vs.hidden = v !== 'study';
    if (vg) vg.hidden = v !== 'galaxy';
    if (vi) vi.hidden = v !== 'index';

    document.body.dataset.view = v;
  }

  function switchView(v) {
    if (state.view === v) return;
    state.view = v;
    try { localStorage.setItem(STORE_VIEW, v); } catch (e) {}
    applyViewUI(v);

    if (v === 'galaxy') {
      if (!state.galaxy) {
        requestAnimationFrame(function () { initGalaxy(); });
      } else {
        requestAnimationFrame(function () {
          if (state.galaxy) {
            state.galaxy.resize();
            rebuildScene();
          }
        });
      }
    } else if (v === 'index') {
      renderIndexView();
    }
  }

  function initGalaxy() {
    if (state.galaxy) return;
    var canvas = $('#sky');
    if (!canvas) return;
    if (typeof Galaxy !== 'function') return;
    state.galaxy = new Galaxy(canvas, {
      onSelect: function (id) { selectStar(id); },
      onHover:  function (node, mx, my) { handleHover(node, mx, my); }
    });
    requestAnimationFrame(function () {
      state.galaxy.resize();
      rebuildScene();
    });
  }

  /* ---- 学习顺序 ---- */
  function buildStudyOrder() {
    var list = visibleCards();
    var now = Date.now();

    list.sort(function (a, b) {
      var ra = getRec(a.id);
      var rb = getRec(b.id);
      var da, db;
      if (ra.reps === 0) da = -1;
      else if (ra.due <= now) da = 0;
      else da = ra.due;
      if (rb.reps === 0) db = -1;
      else if (rb.due <= now) db = 0;
      else db = rb.due;
      if (da !== db) return da - db;
      return masteryOf(ra) - masteryOf(rb);
    });

    state.studyOrder = list.map(function (c) { return c.id; });
    state.studyIndex = 0;
  }

  function currentStudyCard() {
    var id = state.studyOrder[state.studyIndex];
    return id ? state.cardMap.get(id) || null : null;
  }

  function refreshAfterFilterChange() {
    if (state.editing) return;
    buildStudyOrder();
    renderStudy();
    renderDeckTree();
    if (state.view === 'galaxy') rebuildScene();
  }

  /* ==========================================================
   *  ★ 学习视图 —— 领域目录树（替换原「章节进度」+「标签筛选」）
   *
   *  · 分级展示领域树，可折叠/展开
   *  · 点击某项 → 筛选该领域（含全部子领域）的卡片
   *  · 再次点击同一项 / 点击「全部」 → 取消筛选
   *  · 只显示有卡片的领域
   * ========================================================== */
  function renderDeckTree() {
    var el = $('#deckTree');
    if (!el) return;

    var collapsed = state.deckTreeCollapsed || (state.deckTreeCollapsed = {});
    var activeId = state.filterDeck;

    /* 预计算每个领域的「含子领域」卡片总数 */
    var counts = {};
    state.decks.forEach(function (d) { counts[d.id] = (d.cards || []).length; });

    var depthList = state.decks.map(function (d) {
      var lv = 0, cur = d, guard = 0;
      while (cur.parentId && guard++ < 200) {
        cur = getDeckById(cur.parentId);
        if (!cur) break;
        lv++;
      }
      return { d: d, lv: lv };
    }).sort(function (a, b) { return b.lv - a.lv; });

    depthList.forEach(function (item) {
      var d = item.d;
      if (d.parentId && counts[d.parentId] != null) {
        counts[d.parentId] += counts[d.id];
      }
    });

    var html = '';

    /* 「全部」入口 */
    html += '<button type="button" class="dt-all' +
      (activeId === 'all' ? ' on' : '') + '" data-deck="all">' +
      '<span class="dt-dot dt-dot-all"></span>' +
      '<span class="dt-name">全部</span>' +
      '<span class="dt-count">' + state.cards.length + '</span>' +
    '</button>';

    var anyRendered = false;

    function walk(parentId, depth) {
      state.decks.forEach(function (d) {
        if ((d.parentId || null) !== parentId) return;

        var total = counts[d.id] || 0;
        if (!total) return;

        anyRendered = true;

        var hasChildren = state.decks.some(function (x) {
          return x.parentId === d.id && (counts[x.id] || 0) > 0;
        });
        var isCollapsed = !!collapsed[d.id];
        var isActive = activeId === d.id;
        var indent = Math.min(depth, 6) * 14;

        html += '<div class="dt-row' + (isActive ? ' on' : '') +
          '" style="padding-left:' + indent + 'px">' +
          '<button type="button" class="dt-fold' + (hasChildren ? '' : ' empty') +
            '" data-fold="' + esc(d.id) + '" tabindex="-1">' +
            (hasChildren ? (isCollapsed ? '▸' : '▾') : '') +
          '</button>' +
          '<button type="button" class="dt-item' + (isActive ? ' on' : '') +
            '" data-deck="' + esc(d.id) + '">' +
            '<span class="dt-dot" style="--c:' + esc(d.color) + '"></span>' +
            '<span class="dt-name">' + esc(d.name) + '</span>' +
            '<span class="dt-count">' + total + '</span>' +
          '</button>' +
        '</div>';

        if (!isCollapsed) walk(d.id, depth + 1);
      });
    }

    walk(null, 0);

    if (!anyRendered && !state.cards.length) {
      el.innerHTML = '<div class="dt-empty">还没有卡片<br/>先去管理页添加吧</div>';
      return;
    }

    el.innerHTML = html;
  }

  /* ---- 背面 Tab ---- */
  function applyBackTabs(card) {
    var tabsEl = $('#sBackTabs');
    var hasText = !!(card.back && card.back.trim());
    var hasFormula = !!(card.formula && card.formula.trim());

    if (!hasFormula) {
      if (tabsEl) tabsEl.hidden = true;
      state.backTab = 'answer';
    } else if (!hasText) {
      if (tabsEl) tabsEl.hidden = true;
      state.backTab = 'formula';
    } else {
      if (tabsEl) tabsEl.hidden = false;
      if (state.backTab !== 'answer' && state.backTab !== 'formula') {
        state.backTab = 'answer';
      }
    }

    if (tabsEl && !tabsEl.hidden) {
      $$('.sback-tab', tabsEl).forEach(function (b) {
        b.classList.toggle('active', b.dataset.btab === state.backTab);
      });
    }
    $$('#sBackContent .stab-panel').forEach(function (p) {
      p.hidden = p.dataset.bpanel !== state.backTab;
    });
  }

  /* ---- 主渲染 ---- */
  function renderStudy() {
    var main    = $('#studyMain');
    var foot    = $('#studyFoot');
    var empty   = $('#studyEmpty');
    var bar     = $('.study-bar');
    var scard   = $('#scard');
    var editWrap= $('#editWrap');

    var card = currentStudyCard();

    if (!card) {
      if (main)  main.hidden = true;
      if (foot)  foot.hidden = true;
      if (bar)   bar.hidden = true;
      if (empty) empty.hidden = false;
      renderStudySidebar(null);
      state._lastCardId = null;
      updateCollectionBadge();
      return;
    }

    if (main)  main.hidden = false;
    if (foot)  foot.hidden = false;
    if (bar)   bar.hidden = false;
    if (empty) empty.hidden = true;

    if (state._lastCardId !== card.id) {
      state._lastCardId = card.id;
      state.backTab = 'answer';
    }

    if (state.editing) {
      if (scard) scard.style.display = 'none';
      if (editWrap) editWrap.hidden = false;
      updateCollectionBadge();
      return;
    } else {
      if (scard) scard.style.display = '';
      if (editWrap) editWrap.hidden = true;
    }

    var deckEl = $('#sbDeck');
    if (deckEl) {
      deckEl.textContent = card.deckName || '';
      deckEl.style.setProperty('--c', card.deckColor || '#7d9bff');
    }

    var total = state.studyOrder.length;
    var pos = state.studyIndex + 1;
    var dueCount = state.studyOrder.filter(function (id) { return isDue(id); }).length;

    var progEl = $('#sbProgress');
    if (progEl) {
      progEl.innerHTML =
        '第 <b>' + pos + '</b> / ' + total + ' 张' +
        (dueCount ? ' · 待复习 <b class="due">' + dueCount + '</b>' : '');
    }

    var tagHtml = (card.tags || []).map(function (t) {
      return '<span class="ptag">' + esc(t) + '</span>';
    }).join('');
    var sTags = $('#sTags'); if (sTags) sTags.innerHTML = tagHtml;
    var sBackTags = $('#sBackTags'); if (sBackTags) sBackTags.innerHTML = tagHtml;

    var sFront = $('#sFront'); if (sFront) sFront.innerHTML = fmt(card.front || '');
    var sHint = $('#sHint');
    if (sHint) sHint.innerHTML = card.hint ? '<div class="hint">💡 ' + esc(card.hint) + '</div>' : '';
    var sBack = $('#sBack'); if (sBack) sBack.innerHTML = fmt(card.back || '');
    var sBackFormula = $('#sBackFormula');
    if (sBackFormula) sBackFormula.innerHTML = renderFormula(card.formula);

    applyBackTabs(card);

    var rec = getRec(card.id);
    var starChar = rec.starred ? '★' : '☆';
    ['#sStar', '#sStar2'].forEach(function (sel) {
      var el = $(sel);
      if (!el) return;
      el.textContent = starChar;
      el.classList.toggle('on', !!rec.starred);
    });

    if (scard) scard.classList.toggle('flipped', state.flipped);
    var flip = $('#sfFlip');
    if (flip) flip.textContent = state.flipped ? '收起答案 (Space)' : '显示答案 (Space)';
    var gr = $('#gradeRow');
    if (gr) gr.classList.toggle('show', state.flipped);

    var prev = $('#sfPrev');
    var next = $('#sfNext');
    if (prev) prev.disabled = total <= 1;
    if (next) next.disabled = total <= 1;

    renderStudySidebar(card);
    updateCollectionBadge();
  }

  function updateCollectionBadge() {
    var el = $('#sbCollection');
    if (!el) return;
    var show = state.studySource === 'custom' && state.customSet && state.customSet.size > 0;
    el.hidden = !show;
  }

  function renderStudySidebar(card) {
    updateRing();
    updateStatMini();
    renderDeckTree();
    updateGoalInput();

    if (card) {
      renderCardInfo(card);
      renderRelated(card);
    } else {
      var ci = $('#cardInfo');
      if (ci) ci.innerHTML = '<div class="ci-row"><span class="ci-label">未选择卡片</span></div>';
      var rl = $('#relatedList');
      if (rl) rl.innerHTML = '';
      var rc = $('#relatedCount');
      if (rc) rc.textContent = '0';
    }
  }

  function updateRing() {
    var ringFg = $('#ringFg');
    var todayEl = $('#todayCount');
    if (!ringFg || !todayEl) return;

    var days = state.progress.stats.days || {};
    var today = days[dateKey()] || { n: 0 };
    var goal = state.progress.settings.dailyGoal || 20;

    todayEl.textContent = today.n;
    var c = 2 * Math.PI * 50;
    var pct = goal > 0 ? Math.min(1, today.n / goal) : 0;
    ringFg.style.strokeDasharray = c;
    ringFg.style.strokeDashoffset = c * (1 - pct);
  }

  function updateGoalInput() {
    var input = $('#dailyGoal');
    var label = $('#goalLabel');
    var goal = state.progress.settings.dailyGoal || 20;
    if (input && input.value !== String(goal)) input.value = goal;
    if (label) label.textContent = goal;
  }

  function updateStatMini() {
    var due = state.cards.filter(function (c) { return isDue(c.id); }).length;
    var mastered = state.cards.filter(function (c) { return masteryOfCard(c.id) >= 0.7; }).length;
    var streak = computeStreak();

    var days = state.progress.stats.days || {};
    var allN = 0, allOk = 0;
    Object.keys(days).forEach(function (k) {
      allN += days[k].n || 0;
      allOk += days[k].ok || 0;
    });
    var acc = allN ? Math.round(allOk / allN * 100) : 0;

    var set = function (sel, val) {
      var el = $(sel);
      if (el) el.textContent = val;
    };
    set('#statDue', due);
    set('#statMastered', mastered);
    set('#statStreak', streak);
    set('#statAcc', acc + '%');
  }

  function renderCardInfo(card) {
    var el = $('#cardInfo');
    if (!el) return;
    var rec = getRec(card.id);
    var mastery = masteryOf(rec);

    var next;
    if (!rec.reps) next = '未开始';
    else {
      var diff = rec.due - Date.now();
      if (diff <= 0) next = '现在';
      else {
        var d = Math.ceil(diff / DAY);
        next = d <= 1 ? '今天稍后' : d + ' 天后';
      }
    }

    el.innerHTML =
      '<div class="ci-row"><span class="ci-label">复习次数</span><span class="ci-val">' + rec.reps + ' 次</span></div>' +
      '<div class="ci-row"><span class="ci-label">下次复习</span><span class="ci-val hl">' + next + '</span></div>' +
      '<div class="ci-row"><span class="ci-label">间隔</span><span class="ci-val">' + (rec.interval ? rec.interval + ' 天' : '—') + '</span></div>' +
      '<div class="ci-mastery">' +
        '<div class="ci-mastery-head"><span>掌握度</span><b>' + Math.round(mastery * 100) + '%</b></div>' +
        '<div class="ci-mastery-bar"><i style="width:' + (mastery * 100) + '%"></i></div>' +
      '</div>';
  }

  function renderRelated(card) {
    var el = $('#relatedList');
    var cnt = $('#relatedCount');
    if (!el) return;

    var related = [];
    (card.links || []).forEach(function (id) {
      var t = state.cardMap.get(id);
      if (t) related.push({ card: t, kind: '关联' });
    });

    var seen = new Set(related.map(function (r) { return r.card.id; }));
    seen.add(card.id);

    state.cards.forEach(function (c) {
      if (seen.has(c.id)) return;
      if (related.length >= 8) return;
      var shared = c.tags.some(function (t) { return card.tags.indexOf(t) >= 0; });
      if (shared) {
        seen.add(c.id);
        related.push({ card: c, kind: '同标签' });
      }
    });

    related = related.slice(0, 8);
    if (cnt) cnt.textContent = related.length;
    if (!related.length) {
      el.innerHTML = '<div class="rel-empty">暂无相关卡片</div>';
      return;
    }

    el.innerHTML = related.map(function (r) {
      return '<button type="button" class="rel-item" data-id="' + esc(r.card.id) + '">' +
        '<span class="rel-dot" style="--c:' + esc(r.card.deckColor) + '"></span>' +
        '<span class="rel-name">' + esc(truncate(r.card.front, 28)) + '</span>' +
        '<span class="rel-kind">' + esc(r.kind) + '</span>' +
      '</button>';
    }).join('');
  }

  /* ---- 学习操作 ---- */
  function grade(g) {
    var card = currentStudyCard();
    if (!card || !state.flipped) return;

    var rec = recOf(card.id);
    Object.assign(rec, schedule(rec, g));

    var days = state.progress.stats.days || (state.progress.stats.days = {});
    var k = dateKey();
    if (!days[k]) days[k] = { n: 0, ok: 0 };
    days[k].n++;
    if (g >= 2) days[k].ok++;

    saveProgress();
    renderChips();
    updateStatMini();
    updateRing();
    toast(g >= 2 ? '记住了 · 下一张' : '已记录 · 稍后会再见到');
    advanceStudy();
  }

  function advanceStudy() {
    state.flipped = false;
    var order = state.studyOrder;
    var n = order.length;
    if (!n) { renderStudy(); return; }

    var now = Date.now();
    var next = -1;
    for (var step = 1; step <= n; step++) {
      var idx = (state.studyIndex + step) % n;
      var c = state.cardMap.get(order[idx]);
      if (!c) continue;
      var rec = getRec(c.id);
      if (rec.reps === 0 || rec.due <= now) { next = idx; break; }
    }

    if (next < 0) {
      next = (state.studyIndex + 1) % n;
      toast('这一片星空已复习完毕 ✦');
    }
    state.studyIndex = next;
    renderStudy();
  }

  function prevStudy() {
    state.flipped = false;
    var n = state.studyOrder.length;
    if (!n) return;
    state.studyIndex = (state.studyIndex - 1 + n) % n;
    renderStudy();
  }

  function nextStudy() {
    state.flipped = false;
    var n = state.studyOrder.length;
    if (!n) return;
    state.studyIndex = (state.studyIndex + 1) % n;
    renderStudy();
  }

  function shuffleStudy() {
    if (!state.studyOrder.length) return;
    state.flipped = false;
    state.studyIndex = Math.floor(Math.random() * state.studyOrder.length);
    renderStudy();
    var c = currentStudyCard();
    if (c) toast('随机到了：' + truncate(c.front, 18));
  }

  function skipCard() {
    if (!state.studyOrder.length) return;
    state.flipped = false;
    nextStudy();
    toast('已跳过');
  }

  function markTooEasy() {
    var card = currentStudyCard();
    if (!card) return;
    state.flipped = true;
    grade(3);
    toast('已标记为太简单');
  }

  function toggleStar() {
    var card = currentStudyCard();
    if (!card) return;
    var rec = recOf(card.id);
    rec.starred = !rec.starred;
    saveProgress();
    renderStudy();
    toast(rec.starred ? '已收藏 ★' : '已取消收藏');
  }

  function selectStudyCard(id) {
    var idx = state.studyOrder.indexOf(id);
    if (idx < 0) {
      if (state.studySource === 'custom' && state.customSet && state.customSet.has(id)) {
        buildStudyOrder();
        idx = state.studyOrder.indexOf(id);
      }
      if (idx < 0) {
        buildStudyOrder();
        idx = state.studyOrder.indexOf(id);
      }
    }
    if (idx < 0) return;
    state.studyIndex = idx;
    state.flipped = false;
    state.editing = false;
    state.backTab = 'answer';
    switchView('study');
    renderStudy();
  }

  /* ---- 编辑模式 ---- */
  function enterEdit() {
    var card = currentStudyCard();
    if (!card) return;
    state.editing = true;
    var ef  = $('#editFront');   if (ef)  ef.value  = card.front   || '';
    var eb  = $('#editBack');    if (eb)  eb.value  = card.back    || '';
    var efo = $('#editFormula'); if (efo) efo.value = card.formula || '';
    var et  = $('#editTags');    if (et)  et.value  = (card.tags || []).join(', ');
    var eh  = $('#editHint');    if (eh)  eh.value  = card.hint    || '';
    renderStudy();
  }

  function exitEdit() {
    state.editing = false;
    renderStudy();
    buildStudyOrder();
    renderStudy();
  }

  function saveEdit() {
    var card = currentStudyCard();
    if (!card) return;

    var ef  = $('#editFront');
    var eb  = $('#editBack');
    var efo = $('#editFormula');
    var et  = $('#editTags');
    var eh  = $('#editHint');

    var newFront = ef ? ef.value.trim() : '';
    if (!newFront) { toast('正面不能为空'); return; }

    card.front   = newFront;
    card.back    = eb  ? eb.value.trim()  : '';
    card.formula = efo ? efo.value.trim() : '';
    card.hint    = eh  ? eh.value.trim()  : '';
    card.tags = et
      ? et.value.split(/[,，、]/).map(function (t) { return t.trim(); }).filter(Boolean)
      : [];

    var owner = state.data.decks.find(function (d) { return d.id === card.deckId; });
    if (owner) {
      var c = owner.cards.find(function (x) { return x.id === card.id; });
      if (c) {
        c.front = card.front; c.back = card.back;
        c.formula = card.formula; c.hint = card.hint; c.tags = card.tags;
      }
    }
    try { localStorage.setItem(STORE_DATA, JSON.stringify(state.data)); } catch (e) {}

    state.editing = false;
    renderStudy();
    renderChips();
    toast('已保存');
  }

  /* ---- 侧栏开关 ---- */
  function toggleSide() {
    var left = $('#studySideLeft');
    var right = $('#studySideRight');
    var backdrop = $('#sideBackdrop');
    var isMobile = window.innerWidth < 1024;
    if (isMobile) {
      var openLeft = left && left.classList.contains('open');
      var openRight = right && right.classList.contains('open');
      if (openLeft || openRight) {
        left && left.classList.remove('open');
        right && right.classList.remove('open');
        backdrop && (backdrop.hidden = true);
      } else {
        if (window.innerWidth < 768) left && left.classList.add('open');
        else right && right.classList.add('open');
        backdrop && (backdrop.hidden = false);
      }
    }
  }

  /* ==========================================================
   *  星空视图 —— 多层级网络
   * ========================================================== */

  var LEVEL_LABELS = ['宇宙', '银河', '星云', '星团', '星群', '星系'];

  function levelLabel(lv) {
    if (lv < 0) return '';
    if (lv < LEVEL_LABELS.length) return LEVEL_LABELS[lv];
    return '子领域';
  }

  function computeDeckPositions(decks) {
    var positions = {};

    var tops = decks.filter(function (d) { return !d.parentId; });
    if (!tops.length) return positions;

    tops.forEach(function (top, ti) {
      var uy = (ti - (tops.length - 1) / 2) * UNIVERSE_GAP;

      positions[top.id] = {
        x: 0, y: uy, z: 0,
        radius: UNIVERSE_RADIUS,
        level: 0,
        kind: 'universe',
        spinSpeed: 0,
        spinPhase: 0
      };

      var galaxies = decks.filter(function (d) { return d.parentId === top.id; });
      placeGalaxies(galaxies, positions[top.id], decks, positions);
    });

    return positions;
  }

  function placeGalaxies(galaxies, universe, decks, positions) {
    var n = galaxies.length;
    if (!n) return;

    var goldenAngle = Math.PI * (3 - Math.sqrt(5));

    galaxies.forEach(function (gal, gi) {
      var angle = gi * goldenAngle + hashStr(gal.id + '#oa') * TAU;
      var radiusFactor = 0.28 + 0.55 * hashStr(gal.id + '#rf');
      var gRadius = universe.radius * radiusFactor;

      var gx = universe.x + Math.cos(angle) * gRadius;
      var gz = universe.z + Math.sin(angle) * gRadius;
      var gy = universe.y + (hashStr(gal.id + '#y') - 0.5) * 100;

      var tiltA = (hashStr(gal.id + '#ta') - 0.5) * 2 * GALAXY_TILT_MAX;
      var tiltB = (hashStr(gal.id + '#tb') - 0.5) * 2 * GALAXY_TILT_MAX;

      var gRadiusActual = GALAXY_RADIUS * (0.85 + 0.35 * hashStr(gal.id + '#sz'));

      positions[gal.id] = {
        x: gx, y: gy, z: gz,
        radius: gRadiusActual,
        level: 1,
        kind: 'galaxy',
        id: gal.id,
        universeId: universe.id,
        tiltA: tiltA,
        tiltB: tiltB,
        spinSpeed: 0.14 + 0.12 * hashStr(gal.id + '#sp'),
        spinPhase: hashStr(gal.id + '#ph') * TAU
      };

      var nebulae = decks.filter(function (d) { return d.parentId === gal.id; });
      placeNebulae(nebulae, positions[gal.id], decks, positions);
    });
  }

  function placeNebulae(nebulae, galaxy, decks, positions) {
    var n = nebulae.length;
    if (!n) return;

    var perArm = Math.ceil(n / ARM_COUNT);

    nebulae.forEach(function (neb, ni) {
      var armIndex = ni % ARM_COUNT;
      var slotInArm = Math.floor(ni / ARM_COUNT);

      var armBase = (armIndex / ARM_COUNT) * TAU;
      var t = perArm <= 1 ? 0.5 : (slotInArm / Math.max(1, perArm - 1));

      var r = galaxy.radius * (0.28 + 0.66 * t);
      var spiralAngle = armBase + t * ARM_TWIST;
      var jitter = (hashStr(neb.id + '#j') - 0.5) * 0.42;
      var finalAngle = spiralAngle + jitter;

      var lx = Math.cos(finalAngle) * r;
      var lz = Math.sin(finalAngle) * r;
      var ly = (hashStr(neb.id + '#y') - 0.5) * galaxy.radius * 0.22;

      var cosA = Math.cos(galaxy.tiltA), sinA = Math.sin(galaxy.tiltA);
      var cosB = Math.cos(galaxy.tiltB), sinB = Math.sin(galaxy.tiltB);

      var y1 = ly * cosA - lz * sinA;
      var z1 = ly * sinA + lz * cosA;

      var x2 = lx * cosB - y1 * sinB;
      var y2 = lx * sinB + y1 * cosB;

      positions[neb.id] = {
        x: galaxy.x + x2,
        y: galaxy.y + y2,
        z: galaxy.z + z1,
        radius: NEBULA_RADIUS * (0.7 + 0.55 * hashStr(neb.id + '#sz')),
        level: 2,
        kind: 'nebula',
        id: neb.id,
        galaxyId: galaxy.id,
        spinSpeed: galaxy.spinSpeed,
        spinPhase: galaxy.spinPhase,
        armAngle: finalAngle,
        tiltA: galaxy.tiltA,
        tiltB: galaxy.tiltB
      };

      var children = decks.filter(function (d) { return d.parentId === neb.id; });
      placeDeepChildren(children, positions[neb.id], positions, decks, 3);
    });
  }

  function placeDeepChildren(children, parent, positions, decks, depth) {
    if (!children.length) return;

    children.forEach(function (child, ci) {
      var angle = (ci / children.length) * TAU + hashStr(child.id + '#a') * 0.5;
      var r = parent.radius * (0.35 + 0.3 * hashStr(child.id + '#r'));

      var lx = Math.cos(angle) * r;
      var lz = Math.sin(angle) * r;
      var ly = (hashStr(child.id + '#y') - 0.5) * parent.radius * 0.5;

      positions[child.id] = {
        x: parent.x + lx,
        y: parent.y + ly,
        z: parent.z + lz,
        radius: parent.radius * 0.55,
        level: depth,
        kind: 'deep',
        id: child.id,
        galaxyId: parent.galaxyId,
        spinSpeed: parent.spinSpeed,
        spinPhase: parent.spinPhase,
        tiltA: parent.tiltA,
        tiltB: parent.tiltB
      };

      var deeper = decks.filter(function (d) { return d.parentId === child.id; });
      placeDeepChildren(deeper, positions[child.id], positions, decks, depth + 1);
    });
  }

  /* ==========================================================
   *  卡片布局：四尺度混合流形
   * ========================================================== */

  function placeCardsInNebula(cards, nebula) {
    var n = cards.length;
    if (!n) return [];

    var cols = Math.ceil(Math.sqrt(n));
    var rows = Math.ceil(n / cols);
    var sizeFactor = 0.9 + Math.min(0.6, Math.sqrt(n) / 8 * 0.6);
    var gridSize = nebula.radius * sizeFactor;

    var seedSrc = (nebula.id || '') + '#' + (nebula.x | 0) + '#' + (nebula.z | 0);
    var seed = Math.floor(hashStr(seedSrc) * 99991);

    var nFactor = Math.min(1, Math.sqrt(n) / 7);

    var wSaddle = 0.55 * (1 - nFactor * 0.35);
    var wRipple = 0.35 - nFactor * 0.05;
    var wNoise  = 0.15 + nFactor * 0.55;
    var nBumps  = Math.min(6, Math.max(1, Math.floor(n / 6)));

    var bumps = [];
    for (var bi = 0; bi < nBumps; bi++) {
      var h1 = hashStr(seedSrc + '#bump1_' + bi);
      var h2 = hashStr(seedSrc + '#bump2_' + bi);
      var h3 = hashStr(seedSrc + '#bump3_' + bi);
      bumps.push({
        u: (h2 - 0.5) * 1.75,
        v: (h3 - 0.5) * 1.75,
        amp: (h1 - 0.5) * 1.8,
        sigma: 0.16 + h2 * 0.16
      });
    }

    var phaseU = seed * 0.0137;
    var phaseV = seed * 0.0209;
    var phaseDiag = seed * 0.0073;

    var ampBase = gridSize * WAVE_AMP;

    return cards.map(function (c, i) {
      var col = i % cols;
      var row = Math.floor(i / cols);

      var u = cols <= 1 ? 0 : (col / (cols - 1)) * 2 - 1;
      var v = rows <= 1 ? 0 : (row / (rows - 1)) * 2 - 1;

      var lx = u * gridSize;
      var lz = v * gridSize;

      var saddle = (u * u - v * v) * ampBase * wSaddle;
      var harmonic = u * v * ampBase * 0.35;

      var rippleMain =
        Math.sin(u * Math.PI * WAVE_FREQ + phaseU) *
        Math.cos(v * Math.PI * WAVE_FREQ * 0.8 + phaseV) *
        ampBase * wRipple * 0.95;

      var rippleDiag =
        Math.sin((u + v) * Math.PI * WAVE_FREQ * 1.4 + phaseDiag) *
        ampBase * wRipple * 0.42;

      var noise =
        fbm2D(u * 3.2 + seed * 0.01,
              v * 3.2 - seed * 0.01,
              4, seed) * ampBase * wNoise * 4.2;

      var bumpVal = 0;
      for (var k = 0; k < bumps.length; k++) {
        var bp = bumps[k];
        var du = u - bp.u;
        var dv = v - bp.v;
        var d2 = du * du + dv * dv;
        var g = Math.exp(-d2 / (2 * bp.sigma * bp.sigma));
        bumpVal += bp.amp * g * ampBase * 0.85;
      }

      var droop = (u * u + v * v) * gridSize * 0.045;

      var ly = saddle + harmonic + rippleMain + rippleDiag + noise + bumpVal - droop;

      var hx = hashStr(c.id + '#jx');
      var hy = hashStr(c.id + '#jy');
      var hz = hashStr(c.id + '#jz');

      lx += (hx - 0.5) * gridSize * 0.10;
      ly += (hy - 0.5) * gridSize * 0.10;
      lz += (hz - 0.5) * gridSize * 0.10;

      var cosA = Math.cos(nebula.tiltA || 0), sinA = Math.sin(nebula.tiltA || 0);
      var cosB = Math.cos(nebula.tiltB || 0), sinB = Math.sin(nebula.tiltB || 0);

      var y1 = ly * cosA - lz * sinA;
      var z1 = ly * sinA + lz * cosA;

      var x2 = lx * cosB - y1 * sinB;
      var y2 = lx * sinB + y1 * cosB;

      return {
        x: nebula.x + x2,
        y: nebula.y + y2,
        z: nebula.z + z1
      };
    });
  }

  function placeCardsInGalaxy(cards, galaxy) {
    var n = cards.length;
    if (!n) return [];

    return cards.map(function (c) {
      var h1 = hashStr(c.id + '#r');
      var h2 = hashStr(c.id + '#a');
      var h3 = hashStr(c.id + '#z');

      var angle = h2 * TAU;
      var r = galaxy.radius * (0.15 + 0.8 * Math.sqrt(h1));
      var ly = (h3 - 0.5) * galaxy.radius * 0.1;

      var lx = Math.cos(angle) * r;
      var lz = Math.sin(angle) * r;

      var cosA = Math.cos(galaxy.tiltA || 0), sinA = Math.sin(galaxy.tiltA || 0);
      var cosB = Math.cos(galaxy.tiltB || 0), sinB = Math.sin(galaxy.tiltB || 0);

      var y1 = ly * cosA - lz * sinA;
      var z1 = ly * sinA + lz * cosA;

      var x2 = lx * cosB - y1 * sinB;
      var y2 = lx * sinB + y1 * cosB;

      return {
        x: galaxy.x + x2,
        y: galaxy.y + y2,
        z: galaxy.z + z1
      };
    });
  }

  function placeCardsInUniverse(cards, universe) {
    var n = cards.length;
    if (!n) return [];

    return cards.map(function (c) {
      var h1 = hashStr(c.id + '#r');
      var h2 = hashStr(c.id + '#a');
      var h3 = hashStr(c.id + '#y');

      var angle = h2 * TAU;
      var r = universe.radius * (0.2 + 0.75 * Math.sqrt(h1));
      var ly = (h3 - 0.5) * 120;

      return {
        x: universe.x + Math.cos(angle) * r,
        y: universe.y + ly,
        z: universe.z + Math.sin(angle) * r
      };
    });
  }

  function computeInDegrees(cards, cardIdSet) {
    var inDeg = {};
    cards.forEach(function (c) {
      (c.links || []).forEach(function (t) {
        if (!cardIdSet.has(t)) return;
        if (t === c.id) return;
        inDeg[t] = (inDeg[t] || 0) + 1;
      });
    });
    var maxDeg = 0;
    cards.forEach(function (c) {
      var v = inDeg[c.id] || 0;
      if (v > maxDeg) maxDeg = v;
    });
    return { total: inDeg, max: maxDeg };
  }

  function inDegNorm(v, maxDeg) {
    if (maxDeg <= 0 || v <= 0) return 0;
    return Math.log(1 + v) / Math.log(1 + maxDeg);
  }

  function buildScene(cards, decks) {
    var nodes = [];
    var links = [];

    var positions = computeDeckPositions(decks);

    var cardIdSet = new Set();
    cards.forEach(function (c) { cardIdSet.add(c.id); });
    var indeg = computeInDegrees(cards, cardIdSet);

    var byDeck = new Map();
    cards.forEach(function (c) {
      if (!byDeck.has(c.deckId)) byDeck.set(c.deckId, []);
      byDeck.get(c.deckId).push(c);
    });

    byDeck.forEach(function (deckCards, deckId) {
      var pos = positions[deckId];

      if (!pos) {
        var hb = hashStr(deckId + '#fallback');
        pos = {
          x: Math.cos(hb * TAU) * (UNIVERSE_RADIUS * 1.6),
          y: (hb - 0.5) * UNIVERSE_GAP,
          z: Math.sin(hb * TAU) * (UNIVERSE_RADIUS * 1.6),
          radius: NEBULA_RADIUS * 2,
          level: 2,
          kind: 'nebula',
          id: deckId,
          tiltA: 0, tiltB: 0,
          spinSpeed: 0.1, spinPhase: 0
        };
      }

      var worldPositions;
      if (pos.kind === 'universe') {
        worldPositions = placeCardsInUniverse(deckCards, pos);
      } else if (pos.kind === 'galaxy') {
        worldPositions = placeCardsInGalaxy(deckCards, pos);
      } else {
        worldPositions = placeCardsInNebula(deckCards, pos);
      }

      deckCards.forEach(function (c, i) {
        var wp = worldPositions[i];
        var h1 = hashStr(c.id + '#a');

        var mastery = masteryOfCard(c.id);
        var dn = inDegNorm(indeg.total[c.id] || 0, indeg.max);
        var nodeSize =
          BASE_SIZE +
          mastery * MASTERY_SIZE_BONUS +
          dn * DEGREE_SIZE_BONUS;

        var galaxyId = null;
        var galaxy = null;
        if (pos.kind === 'galaxy') {
          galaxyId = pos.id;
          galaxy = pos;
        } else if (pos.galaxyId) {
          galaxyId = pos.galaxyId;
          galaxy = positions[pos.galaxyId];
        }

        var spinSpeed = galaxy ? galaxy.spinSpeed : 0;
        var spinPhase = galaxy ? galaxy.spinPhase : 0;
        var pivot = galaxy
          ? { x: galaxy.x, y: galaxy.y, z: galaxy.z }
          : { x: 0, y: 0, z: 0 };

        nodes.push({
          id: c.id,
          x: wp.x, y: wp.y, z: wp.z,
          size: nodeSize,
          color: c.deckColor,
          mastery: mastery,
          phase: h1 * TAU,
          deckId: c.deckId,
          level: pos.level,
          card: c,
          inDegree: indeg.total[c.id] || 0,
          group: galaxyId || ('none-' + c.deckId),
          pivot: pivot,
          spinSpeed: spinSpeed,
          spinPhase: spinPhase
        });
      });
    });

    var nodeIds = new Set(nodes.map(function (n) { return n.id; }));
    var linkSet = new Set();

    function addLink(a, b, w) {
      if (a === b) return;
      if (!nodeIds.has(a) || !nodeIds.has(b)) return;
      var key = a < b ? a + '|' + b : b + '|' + a;
      if (linkSet.has(key)) return;
      linkSet.add(key);
      links.push({ a: a, b: b, w: w });
    }

    cards.forEach(function (c) {
      (c.links || []).forEach(function (t) { addLink(c.id, t, 1); });
    });

    var byTag = new Map();
    cards.forEach(function (c) {
      (c.tags || []).forEach(function (t) {
        if (!byTag.has(t)) byTag.set(t, []);
        byTag.get(t).push(c.id);
      });
    });
    byTag.forEach(function (ids) {
      if (ids.length < 2) return;
      if (ids.length <= 5) {
        for (var i = 0; i < ids.length; i++)
          for (var j = i + 1; j < ids.length; j++)
            addLink(ids[i], ids[j], 0.42);
      } else {
        for (var k = 0; k < ids.length; k++)
          addLink(ids[k], ids[(k + 1) % ids.length], 0.36);
      }
    });

    return { nodes: nodes, links: links };
  }

  function rebuildScene() {
    if (!state.galaxy) return;
    var scene = buildScene(visibleCards(), state.decks);
    state.galaxy.setData(scene.nodes, scene.links);
  }

  function selectStar(id) {
    state.selected = id ? (state.cardMap.get(id) || null) : null;
    state.flipped = false;
    if (state.galaxy) {
      state.galaxy.selectedId = state.selected ? state.selected.id : null;
    }
    renderPanel();
  }

  function applyPanelBackTabs(card) {
    var tabsEl = $('#pBackTabs');
    var hasText = !!(card.back && card.back.trim());
    var hasFormula = !!(card.formula && card.formula.trim());

    if (!hasFormula) {
      if (tabsEl) tabsEl.hidden = true;
      state.panelTab = 'answer';
    } else if (!hasText) {
      if (tabsEl) tabsEl.hidden = true;
      state.panelTab = 'formula';
    } else {
      if (tabsEl) tabsEl.hidden = false;
      if (state.panelTab !== 'answer' && state.panelTab !== 'formula') {
        state.panelTab = 'answer';
      }
    }
    if (tabsEl && !tabsEl.hidden) {
      $$('.pback-tab', tabsEl).forEach(function (b) {
        b.classList.toggle('active', b.dataset.btab === state.panelTab);
      });
    }
    $$('#pBackContent .ptab-panel').forEach(function (p) {
      p.hidden = p.dataset.bpanel !== state.panelTab;
    });
  }

  function renderPanel() {
    var c = state.selected;
    var emptyEl = $('#panelEmpty');
    var bodyEl  = $('#panelBody');

    if (!c) {
      if (emptyEl) emptyEl.hidden = false;
      if (bodyEl)  bodyEl.hidden = true;
      state._lastPanelId = null;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    if (bodyEl)  bodyEl.hidden = false;

    if (state._lastPanelId !== c.id) {
      state._lastPanelId = c.id;
      state.panelTab = 'answer';
    }

    var rec = getRec(c.id);
    var mastery = masteryOf(rec);

    var deckEl = $('#pDeck');
    if (deckEl) {
      deckEl.textContent = c.deckName || '';
      deckEl.style.setProperty('--c', c.deckColor || '#7d9bff');
    }
    var starBtn = $('#pStar');
    if (starBtn) {
      starBtn.textContent = rec.starred ? '★' : '☆';
      starBtn.classList.toggle('on', !!rec.starred);
    }
    var mBox = $('#pMastery');
    if (mBox) {
      mBox.innerHTML =
        '<div class="mb-row"><span class="mb-label">掌握度</span><span class="mb-val">' +
        Math.round(mastery * 100) + '%</span></div>' +
        '<div class="mastery-bar"><i style="width:' + (mastery * 100) + '%"></i></div>';
    }
    var tagHtml = (c.tags || []).map(function (t) {
      return '<span class="ptag">' + esc(t) + '</span>';
    }).join('');
    var pTags = $('#pTags'); if (pTags) pTags.innerHTML = tagHtml;
    var pBackTags = $('#pBackTags'); if (pBackTags) pBackTags.innerHTML = tagHtml;

    var pFront = $('#pFront'); if (pFront) pFront.innerHTML = fmt(c.front || '');
    var pHint = $('#pHint');
    if (pHint) pHint.innerHTML = c.hint ? '<div class="hint">💡 ' + esc(c.hint) + '</div>' : '';
    var pBack = $('#pBack'); if (pBack) pBack.innerHTML = fmt(c.back || '');
    var pBackFormula = $('#pBackFormula');
    if (pBackFormula) pBackFormula.innerHTML = renderFormula(c.formula);

    applyPanelBackTabs(c);

    var pMeta = $('#pMeta');
    if (pMeta) pMeta.innerHTML = metaLine(rec);

    renderLinks(c);
    var pcard = $('#pcard');
    if (pcard) pcard.classList.toggle('flipped', state.flipped);
  }

  function metaLine(rec) {
    if (!rec.reps) return '<span class="hl">新卡片</span> · 尚未复习';
    var now = Date.now();
    var diff = rec.due - now;
    var next;
    if (diff <= 0) next = '现在';
    else {
      var d = Math.ceil(diff / DAY);
      next = d <= 1 ? '今天稍后' : d + ' 天后';
    }
    return '已复习 <span class="hl">' + rec.reps + '</span> 次 · ' +
           '下次复习：<span class="hl">' + next + '</span>';
  }

  function renderLinks(card) {
    var el = $('#pLinks');
    if (!el) return;
    var related = [];
    (card.links || []).forEach(function (id) {
      var t = state.cardMap.get(id);
      if (t) related.push({ card: t });
    });
    var seen = new Set(related.map(function (r) { return r.card.id; }));
    seen.add(card.id);

    state.cards.forEach(function (c) {
      if (seen.has(c.id)) return;
      if (related.length >= 6) return;
      var shared = c.tags.some(function (t) { return card.tags.indexOf(t) >= 0; });
      if (shared) { seen.add(c.id); related.push({ card: c }); }
    });
    related = related.slice(0, 5);
    if (!related.length) { el.innerHTML = ''; return; }

    el.innerHTML = '<div class="link-title">关联知识点</div>' +
      related.map(function (r) {
        return '<button type="button" class="link-item" data-id="' + esc(r.card.id) + '">' +
          '<span class="ldot" style="--c:' + esc(r.card.deckColor) + '"></span>' +
          '<span class="lname">' + esc(truncate(r.card.front, 26)) + '</span>' +
        '</button>';
      }).join('');
  }

  function handleHover(node, mx, my) {
    var el = $('#tooltip');
    if (!el) return;
    if (!node || !node.card) { el.classList.remove('show'); return; }

    var mastery = typeof node.mastery === 'number' ? node.mastery : 0;
    var lvLabel = levelLabel(node.level);
    var line1 = '<b>' + esc(truncate(node.card.front, 46)) + '</b>';
    var line2 = '<span>' +
      (lvLabel ? lvLabel + ' · ' : '') + esc(node.card.deckName) +
      ' · 掌握度 ' + Math.round(mastery * 100) + '%</span>';
    var line3 = '';
    var inDeg = node.inDegree || 0;
    if (inDeg > 0) line3 = '<span class="tt-deg">被引用 ' + inDeg + ' 次</span>';

    el.innerHTML = line1 + line2 + line3;
    var sky = $('#sky');
    if (!sky) return;
    var rect = sky.getBoundingClientRect();
    el.style.left = clamp(mx, 130, Math.max(130, rect.width - 130)) + 'px';
    el.style.top  = Math.max(60, my) + 'px';
    el.classList.add('show');
  }

  /* ---- Chips / Legend ---- */
  function renderChips() {
    var el = $('#chips');
    if (!el) return;
    var html = '';
    var allDue = state.studyOrder.filter(function (id) { return isDue(id); }).length;
    if (state.studyOrder.length === 0 && state.cards.length) {
      allDue = state.cards.filter(function (c) { return isDue(c.id); }).length;
    }
    html += '<button type="button" class="chip' + (state.filterDeck === 'all' ? ' active' : '') +
            '" data-deck="all">' +
            '<span class="cdot" style="--c:#7d9bff"></span>全部' +
            '<span class="cnum">' + allDue + '</span></button>';

    state.decks.forEach(function (d) {
      var ids = getDescendantIds(d.id);
      var cards = state.cards.filter(function (c) { return ids.has(c.deckId); });
      if (!cards.length) return;
      var due = cards.filter(function (c) { return isDue(c.id); }).length;
      html += '<button type="button" class="chip' + (state.filterDeck === d.id ? ' active' : '') +
              '" data-deck="' + esc(d.id) + '">' +
              '<span class="cdot" style="--c:' + esc(d.color) + '"></span>' +
              esc(d.name) + '<span class="cnum">' + due + '</span></button>';
    });
    el.innerHTML = html;
  }

  function renderLegend() {
    var el = $('#legend');
    if (!el) return;
    el.innerHTML = state.decks.map(function (d) {
      return '<span><i style="--c:' + esc(d.color) + '"></i>' + esc(d.name) + '</span>';
    }).join('');
  }

  /* ---- 统计 ---- */
  function computeStreak() {
    var days = state.progress.stats.days || {};
    var d = new Date();
    var streak = 0;
    if (!days[dateKey(d)]) d.setDate(d.getDate() - 1);
    for (var i = 0; i < 3650; i++) {
      if (days[dateKey(d)]) { streak++; d.setDate(d.getDate() - 1); }
      else break;
    }
    return streak;
  }

  function showStats() {
    var box = $('#modalBox');
    var modal = $('#modal');
    if (!box || !modal) return;

    var total = state.cards.length;
    var learned = state.cards.filter(function (c) { return getRec(c.id).reps > 0; }).length;
    var due = state.cards.filter(function (c) { return isDue(c.id); }).length;
    var starred = state.cards.filter(function (c) { return getRec(c.id).starred; }).length;
    var mastered = state.cards.filter(function (c) { return masteryOfCard(c.id) >= 0.7; }).length;
    var avgMastery = total ? Math.round(state.cards.reduce(function (s, c) {
      return s + masteryOfCard(c.id);
    }, 0) / total * 100) : 0;

    var days = state.progress.stats.days || {};
    var today = days[dateKey()] || { n: 0, ok: 0 };
    var allN = 0, allOk = 0;
    Object.keys(days).forEach(function (k) {
      allN += days[k].n || 0;
      allOk += days[k].ok || 0;
    });
    var acc = allN ? Math.round(allOk / allN * 100) : 0;

    box.innerHTML =
      '<h2>学习统计</h2>' +
      '<div class="stat-grid">' +
        '<div class="stat-cell"><b>' + total + '</b><span>知识点总数</span></div>' +
        '<div class="stat-cell"><b>' + learned + '</b><span>已学习</span></div>' +
        '<div class="stat-cell"><b>' + mastered + '</b><span>已掌握</span></div>' +
        '<div class="stat-cell"><b>' + avgMastery + '%</b><span>平均掌握度</span></div>' +
        '<div class="stat-cell"><b>' + due + '</b><span>待复习</span></div>' +
        '<div class="stat-cell"><b>' + starred + '</b><span>已收藏</span></div>' +
        '<div class="stat-cell"><b>' + today.n + '</b><span>今日复习</span></div>' +
        '<div class="stat-cell"><b>' + acc + '%</b><span>累计正确率</span></div>' +
        '<div class="stat-cell"><b>' + computeStreak() + '</b><span>连续天数</span></div>' +
      '</div>' +
      '<h2>快捷键</h2>' +
      '<div class="help-list">' +
        '<div><span>翻转卡片</span><span><kbd>Space</kbd></span></div>' +
        '<div><span>评分（忘记 → 熟练）</span><span><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd><kbd>4</kbd></span></div>' +
        '<div><span>上一张 / 下一张</span><span><kbd>←</kbd><kbd>→</kbd></span></div>' +
        '<div><span>随机一张</span><span><kbd>R</kbd></span></div>' +
        '<div><span>收藏</span><span><kbd>F</kbd></span></div>' +
        '<div><span>切换视图</span><span><kbd>G</kbd></span></div>' +
      '</div>' +
      '<div class="modal-actions">' +
        '<a class="btn" href="admin.html" style="text-decoration:none">卡片管理</a>' +
        '<button type="button" class="btn" id="mResetProg">重置进度</button>' +
        '<button type="button" class="btn btn-primary" id="mClose">关闭</button>' +
      '</div>';

    modal.hidden = false;
    var close = $('#mClose'); if (close) close.onclick = closeModal;
    var rp = $('#mResetProg'); if (rp) rp.onclick = function () {
      if (!confirm('确定要清空所有学习进度吗？此操作不可撤销。')) return;
      state.progress.cards = {};
      state.progress.stats = { days: {} };
      saveProgress();
      closeModal();
      renderChips();
      updateStatMini();
      updateRing();
      buildStudyOrder();
      renderStudy();
      renderPanel();
      renderIndexView();
      if (state.galaxy) rebuildScene();
      toast('学习进度已重置');
    };
  }

  function closeModal() {
    var m = $('#modal');
    if (m) m.hidden = true;
  }

  /* ---- Toast / 主题 ---- */
  var toastTimer = null;
  function toast(msg) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2200);
  }

  function applyTheme(theme) {
    document.body.dataset.theme = theme;
    state.progress.settings.theme = theme;
    saveProgress();
    var btn = $('#btnTheme');
    if (btn) btn.textContent = theme === 'dark' ? '☀' : '☾';
  }

  /* ==========================================================
   *  知识索引视图
   * ========================================================== */

  function collectIdxTags() {
    var f = state.idxFilters;
    var base = state.cards;

    if (f.decks.size > 0) {
      var allowed = new Set();
      f.decks.forEach(function (did) {
        var ids = getDescendantIds(did);
        ids.forEach(function (id) { allowed.add(id); });
      });
      base = base.filter(function (c) { return allowed.has(c.deckId); });
    }

    var q = f.search.trim().toLowerCase();
    if (q) {
      base = base.filter(function (c) {
        var hay = (c.front + ' ' + c.back + ' ' + (c.formula || '') + ' ' +
                   c.tags.join(' ') + ' ' + c.deckName).toLowerCase();
        return hay.indexOf(q) >= 0;
      });
    }

    if (f.states.size > 0) {
      base = base.filter(function (c) { return matchIdxStates(c, f.states); });
    }

    var counts = {};
    base.forEach(function (c) {
      (c.tags || []).forEach(function (t) {
        if (!t) return;
        counts[t] = (counts[t] || 0) + 1;
      });
    });

    return Object.keys(counts).map(function (t) {
      return { tag: t, count: counts[t] };
    }).sort(function (a, b) {
      if (b.count !== a.count) return b.count - a.count;
      return a.tag.localeCompare(b.tag);
    });
  }

  function matchIdxStates(c, stateSet) {
    if (stateSet.has('due') && !isDue(c.id)) return false;
    if (stateSet.has('new') && getRec(c.id).reps > 0) return false;
    if (stateSet.has('starred') && !getRec(c.id).starred) return false;
    if (stateSet.has('mastered') && masteryOfCard(c.id) < 0.7) return false;
    if (stateSet.has('has-formula') && !(c.formula && c.formula.trim())) return false;
    if (stateSet.has('has-links') && !(c.links && c.links.length)) return false;
    return true;
  }

  function filterIdxCards() {
    var f = state.idxFilters;
    var list = state.cards;

    if (f.decks.size > 0) {
      var allowed = new Set();
      f.decks.forEach(function (did) {
        var ids = getDescendantIds(did);
        ids.forEach(function (id) { allowed.add(id); });
      });
      list = list.filter(function (c) { return allowed.has(c.deckId); });
    }

    if (f.tags.size > 0) {
      list = list.filter(function (c) {
        return (c.tags || []).some(function (t) { return f.tags.has(t); });
      });
    }

    if (f.states.size > 0) {
      list = list.filter(function (c) { return matchIdxStates(c, f.states); });
    }

    var q = f.search.trim().toLowerCase();
    if (q) {
      list = list.filter(function (c) {
        var hay = (c.front + ' ' + c.back + ' ' + (c.formula || '') + ' ' +
                   c.tags.join(' ') + ' ' + c.deckName).toLowerCase();
        return hay.indexOf(q) >= 0;
      });
    }

    return list;
  }

  function renderIdxDeckFilter() {
    var el = $('#idxDeckFilter');
    if (!el) return;

    var tops = state.decks.filter(function (d) { return !d.parentId; });
    if (!tops.length) {
      el.innerHTML = '';
      return;
    }

    var f = state.idxFilters;
    if (!f.collapsedDecks) f.collapsedDecks = new Set();

    function subtreeCount(deckId) {
      var ids = getDescendantIds(deckId);
      var count = 0;
      state.decks.forEach(function (d) {
        if (ids.has(d.id)) count += d.cards.length;
      });
      return count;
    }

    var html = '';

    function walk(parentId, depth) {
      state.decks.forEach(function (d) {
        if ((d.parentId || null) !== parentId) return;

        var count = subtreeCount(d.id);
        if (!count) return;

        var on = f.decks.has(d.id) ? ' on' : '';
        var indent = depth * 14;
        var hasChildren = state.decks.some(function (x) {
          return x.parentId === d.id && subtreeCount(x.id) > 0;
        });
        var collapsed = hasChildren && f.collapsedDecks.has(d.id);
        var foldIcon = hasChildren ? (collapsed ? '▸' : '▾') : '';

        html +=
          '<div class="idx-deck-row' + on + '" style="padding-left:' + (4 + indent) + 'px">' +
            '<button type="button" class="idx-deck-fold' +
              (hasChildren ? '' : ' empty') + '" ' +
              'data-fold="' + esc(d.id) + '" title="展开/折叠">' +
              foldIcon +
            '</button>' +
            '<button type="button" class="idx-deck-item' + on + '" ' +
              'data-deck="' + esc(d.id) + '">' +
              '<span class="idx-deck-dot" style="--c:' + esc(d.color) + '"></span>' +
              '<span class="idx-deck-name">' + esc(d.name) + '</span>' +
              '<span class="idx-deck-count">' + count + '</span>' +
            '</button>' +
          '</div>';

        if (hasChildren && !collapsed) {
          walk(d.id, depth + 1);
        }
      });
    }

    walk(null, 0);
    el.innerHTML = html;
  }

  function renderIdxTagFilter() {
    var el = $('#idxTagFilter');
    if (!el) return;
    var tags = collectIdxTags();
    var f = state.idxFilters;

    var existing = new Set(tags.map(function (t) { return t.tag; }));
    var orphan = [];
    f.tags.forEach(function (t) {
      if (!existing.has(t)) orphan.push({ tag: t, count: 0 });
    });
    tags = orphan.concat(tags);

    if (!tags.length) { el.innerHTML = ''; return; }

    el.innerHTML = tags.map(function (t) {
      var on = f.tags.has(t.tag) ? ' on' : '';
      return '<button type="button" class="idx-tag-chip' + on + '" data-tag="' + esc(t.tag) + '">' +
        esc(t.tag) +
        (t.count > 0 ? '<span class="idx-tag-num">' + t.count + '</span>' : '') +
      '</button>';
    }).join('');
  }

  function renderIdxStates() {
    var el = $('#idxStateFilter');
    if (!el) return;
    var f = state.idxFilters;
    $$('.idx-state-chip', el).forEach(function (b) {
      b.classList.toggle('on', f.states.has(b.dataset.state));
    });
  }

  function renderIdxGrid() {
    var el = $('#idxGrid');
    var emptyEl = $('#idxEmpty');
    var countEl = $('#idxCount');
    var hintEl = $('#idxHint');
    var studyAllBtn = $('#btnIdxStudyAll');
    var studyOneBtn = $('#btnIdxStudyOne');

    var cards = filterIdxCards();
    if (countEl) countEl.textContent = cards.length;

    if (hintEl) {
      var f = state.idxFilters;
      var parts = [];
      if (f.decks.size) parts.push(f.decks.size + ' 个领域');
      if (f.tags.size) parts.push(f.tags.size + ' 个标签');
      if (f.states.size) parts.push(f.states.size + ' 个状态');
      if (f.search) parts.push('搜索');
      hintEl.textContent = parts.length ? '· ' + parts.join(' · ') : '';
    }

    if (studyAllBtn) studyAllBtn.disabled = cards.length === 0;
    if (studyOneBtn) studyOneBtn.disabled = state.idxSelected.size === 0;

    if (!cards.length) {
      el.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;

    el.innerHTML = cards.map(function (c) {
      var rec = getRec(c.id);
      var mastery = masteryOf(rec);
      var selected = state.idxSelected.has(c.id) ? ' selected' : '';

      var marks = '';
      if (rec.starred) marks += '<span class="idx-mark star">★</span>';
      if (c.formula && c.formula.trim()) marks += '<span class="idx-mark formula">∑</span>';
      if (isDue(c.id)) marks += '<span class="idx-mark due">待</span>';

      var tags = (c.tags || []).slice(0, 3).map(function (t) {
        return '<span class="ptag">' + esc(t) + '</span>';
      }).join('');

      return '<div class="idx-card' + selected + '" data-card="' + esc(c.id) + '">' +
        '<div class="idx-card-top">' +
          '<span class="idx-card-deck" style="--c:' + esc(c.deckColor) + '">' +
            esc(truncate(c.deckName, 16)) +
          '</span>' +
          '<div class="idx-card-marks">' + marks + '</div>' +
        '</div>' +
        '<div class="idx-card-front">' + esc(truncate(c.front || '（空正面）', 80)) + '</div>' +
        '<div class="idx-card-back">' + esc(truncate(c.back || '', 60)) + '</div>' +
        (tags ? '<div class="idx-card-marks" style="margin:0">' + tags + '</div>' : '') +
        '<div class="idx-card-foot">' +
          '<div class="idx-card-mastery"><i style="width:' + (mastery * 100) + '%"></i></div>' +
          '<span class="idx-card-mastery-num">' + Math.round(mastery * 100) + '%</span>' +
        '</div>' +
      '</div>';
    }).join('');
  }

  function renderIndexView() {
    renderIdxDeckFilter();
    renderIdxTagFilter();
    renderIdxStates();
    renderIdxGrid();
  }

  /* ---- 针对性学习 ---- */
  function startTargetedStudy(cardIds) {
    state.customSet = new Set(cardIds);
    state.studySource = 'custom';
    state.idxSelected.clear();

    buildStudyOrder();
    switchView('study');
    renderStudy();
    renderChips();
    toast('针对性学习：' + state.customSet.size + ' 张卡片');
  }

  function clearTargetedStudy() {
    if (state.studySource !== 'custom') return;
    state.customSet = null;
    state.studySource = 'all';
    buildStudyOrder();
    renderStudy();
    renderChips();
    toast('已退出针对性学习');
  }

  /* ---- 事件绑定 ---- */
  function on(el, ev, fn) {
    if (el && el.addEventListener) el.addEventListener(ev, fn);
  }

  function bindUI() {
    on($('#viewSwitch'), 'click', function (e) {
      var btn = e.target.closest('.vs-btn');
      if (!btn) return;
      switchView(btn.dataset.view);
    });

    on($('#chips'), 'click', function (e) {
      var btn = e.target.closest('.chip');
      if (!btn) return;
      if (state.studySource === 'custom') clearTargetedStudy();
      state.filterDeck = btn.dataset.deck;
      state.progress.settings.deckId = state.filterDeck;
      state.filterTags.clear();
      saveProgress();
      renderChips();
      buildStudyOrder();
      renderStudy();
      renderDeckTree();
      if (state.view === 'galaxy') rebuildScene();
    });

    /* ★ 学习视图左侧：领域目录树 */
    on($('#deckTree'), 'click', function (e) {
      var foldBtn = e.target.closest('.dt-fold');
      if (foldBtn && !foldBtn.classList.contains('empty')) {
        e.stopPropagation();
        var fid = foldBtn.dataset.fold;
        if (!fid) return;
        if (!state.deckTreeCollapsed) state.deckTreeCollapsed = {};
        if (state.deckTreeCollapsed[fid]) delete state.deckTreeCollapsed[fid];
        else state.deckTreeCollapsed[fid] = true;
        renderDeckTree();
        return;
      }

      var item = e.target.closest('.dt-item');
      if (!item) return;
      var id = item.dataset.deck;
      if (!id) return;

      if (state.studySource === 'custom') clearTargetedStudy();

      if (id === 'all') {
        if (state.filterDeck === 'all') return;
        state.filterDeck = 'all';
      } else {
        state.filterDeck = (state.filterDeck === id) ? 'all' : id;
      }

      state.progress.settings.deckId = state.filterDeck;
      state.filterTags.clear();
      saveProgress();
      renderChips();
      renderDeckTree();
      buildStudyOrder();
      renderStudy();
      if (state.view === 'galaxy') rebuildScene();
    });

    on($('#searchInput'), 'input', function () {
      if (state.studySource === 'custom') clearTargetedStudy();
      var v = this.value || '';
      state.search = v;
      var clr = $('#btnClearSearch');
      if (clr) clr.hidden = !v;
      refreshAfterFilterChange();
    });
    on($('#searchInput'), 'keydown', function (e) {
      if (e.key === 'Escape') {
        e.preventDefault();
        this.value = '';
        state.search = '';
        var clr = $('#btnClearSearch');
        if (clr) clr.hidden = true;
        refreshAfterFilterChange();
        this.blur();
      }
    });
    on($('#btnClearSearch'), 'click', function () {
      var inp = $('#searchInput');
      if (inp) inp.value = '';
      state.search = '';
      this.hidden = true;
      refreshAfterFilterChange();
      if (inp) inp.focus();
    });

    on($('#dailyGoal'), 'change', function () {
      var v = parseInt(this.value, 10);
      if (!v || v < 1) v = 20;
      v = Math.min(500, v);
      this.value = v;
      state.progress.settings.dailyGoal = v;
      saveProgress();
      updateGoalInput();
      updateRing();
      toast('每日目标：' + v + ' 张');
    });

    on($('#sBackTabs'), 'click', function (e) {
      e.stopPropagation();
      var btn = e.target.closest('.sback-tab');
      if (!btn) return;
      var tab = btn.dataset.btab;
      if (!tab || tab === state.backTab) return;
      state.backTab = tab;
      var card = currentStudyCard();
      if (card) applyBackTabs(card);
    });

    on($('#pBackTabs'), 'click', function (e) {
      e.stopPropagation();
      var btn = e.target.closest('.pback-tab');
      if (!btn) return;
      var tab = btn.dataset.btab;
      if (!tab || tab === state.panelTab) return;
      state.panelTab = tab;
      if (state.selected) applyPanelBackTabs(state.selected);
    });

    on($('#sfFlip'), 'click', function () {
      state.flipped = !state.flipped;
      renderStudy();
    });
    on($('#scard'), 'click', function () {
      state.flipped = !state.flipped;
      renderStudy();
    });
    on($('#sfPrev'), 'click', prevStudy);
    on($('#sfNext'), 'click', nextStudy);
    on($('#sbShuffle'), 'click', shuffleStudy);
    on($('#sfShuffle'), 'click', shuffleStudy);
    on($('#sfSkip'), 'click', skipCard);
    on($('#sfTooEasy'), 'click', markTooEasy);
    on($('#sfEdit'), 'click', enterEdit);
    on($('#editCancel'), 'click', exitEdit);
    on($('#editSave'), 'click', saveEdit);

    on($('#gradeRow'), 'click', function (e) {
      var btn = e.target.closest('.grade');
      if (!btn) return;
      grade(Number(btn.dataset.g));
    });

    on($('#sStar'), 'click', function (e) { e.stopPropagation(); toggleStar(); });
    on($('#sStar2'), 'click', function (e) { e.stopPropagation(); toggleStar(); });

    on($('#relatedList'), 'click', function (e) {
      var btn = e.target.closest('.rel-item');
      if (!btn) return;
      selectStudyCard(btn.dataset.id);
    });

    on($('#sbToggleSide'), 'click', toggleSide);
    on($('#sideBackdrop'), 'click', function () {
      var left = $('#studySideLeft');
      var right = $('#studySideRight');
      left && left.classList.remove('open');
      right && right.classList.remove('open');
      this.hidden = true;
    });

    on($('#btnClearCollection'), 'click', function (e) {
      e.stopPropagation();
      clearTargetedStudy();
    });

    on($('#pStar'), 'click', function (e) {
      e.stopPropagation();
      if (!state.selected) return;
      var rec = recOf(state.selected.id);
      rec.starred = !rec.starred;
      saveProgress();
      renderPanel();
      toast(rec.starred ? '已收藏 ★' : '已取消收藏');
    });
    on($('#pClose'), 'click', function (e) {
      e.stopPropagation();
      selectStar(null);
    });
    on($('#pcard'), 'click', function () {
      if (!state.selected) return;
      state.flipped = !state.flipped;
      var pc = $('#pcard');
      if (pc) pc.classList.toggle('flipped', state.flipped);
    });
    on($('#btnGoStudy'), 'click', function () {
      if (!state.selected) return;
      selectStudyCard(state.selected.id);
    });
    on($('#pLinks'), 'click', function (e) {
      var btn = e.target.closest('.link-item');
      if (!btn) return;
      selectStar(btn.dataset.id);
    });

    on($('#idxSearch'), 'input', function () {
      state.idxFilters.search = this.value || '';
      var clr = $('#btnIdxClearSearch');
      if (clr) clr.hidden = !state.idxFilters.search;
      renderIdxTagFilter();
      renderIdxGrid();
    });
    on($('#idxSearch'), 'keydown', function (e) {
      if (e.key === 'Escape') {
        e.preventDefault();
        this.value = '';
        state.idxFilters.search = '';
        var clr = $('#btnIdxClearSearch');
        if (clr) clr.hidden = true;
        renderIdxTagFilter();
        renderIdxGrid();
        this.blur();
      }
    });
    on($('#btnIdxClearSearch'), 'click', function () {
      var inp = $('#idxSearch');
      if (inp) inp.value = '';
      state.idxFilters.search = '';
      this.hidden = true;
      renderIdxTagFilter();
      renderIdxGrid();
      if (inp) inp.focus();
    });

    on($('#idxDeckFilter'), 'click', function (e) {
      var foldBtn = e.target.closest('.idx-deck-fold');
      if (foldBtn && !foldBtn.classList.contains('empty')) {
        var fid = foldBtn.dataset.fold;
        if (!fid) return;
        var f = state.idxFilters;
        if (!f.collapsedDecks) f.collapsedDecks = new Set();
        if (f.collapsedDecks.has(fid)) f.collapsedDecks.delete(fid);
        else f.collapsedDecks.add(fid);
        renderIdxDeckFilter();
        return;
      }

      var btn = e.target.closest('.idx-deck-item');
      if (!btn) return;
      var id = btn.dataset.deck;
      if (!id) return;
      if (state.idxFilters.decks.has(id)) state.idxFilters.decks.delete(id);
      else state.idxFilters.decks.add(id);
      renderIdxDeckFilter();
      renderIdxTagFilter();
      renderIdxGrid();
    });

    on($('#idxTagFilter'), 'click', function (e) {
      var btn = e.target.closest('.idx-tag-chip');
      if (!btn) return;
      var tag = btn.dataset.tag;
      if (!tag) return;
      if (state.idxFilters.tags.has(tag)) state.idxFilters.tags.delete(tag);
      else state.idxFilters.tags.add(tag);
      renderIdxTagFilter();
      renderIdxGrid();
    });

    on($('#idxStateFilter'), 'click', function (e) {
      var btn = e.target.closest('.idx-state-chip');
      if (!btn) return;
      var s = btn.dataset.state;
      if (!s) return;
      if (state.idxFilters.states.has(s)) state.idxFilters.states.delete(s);
      else state.idxFilters.states.add(s);
      renderIdxStates();
      renderIdxTagFilter();
      renderIdxGrid();
    });

    on($('#btnIdxClearAll'), 'click', function () {
      var f = state.idxFilters;
      f.search = '';
      f.decks.clear();
      f.tags.clear();
      f.states.clear();
      state.idxSelected.clear();
      var inp = $('#idxSearch');
      if (inp) inp.value = '';
      var clr = $('#btnIdxClearSearch');
      if (clr) clr.hidden = true;
      renderIndexView();
    });

    on($('#idxGrid'), 'click', function (e) {
      var card = e.target.closest('.idx-card');
      if (!card) return;
      var id = card.dataset.card;
      if (!id) return;

      if (e.shiftKey || e.ctrlKey || e.metaKey) {
        if (state.idxSelected.has(id)) state.idxSelected.delete(id);
        else state.idxSelected.add(id);
      } else {
        startTargetedStudy([id]);
        return;
      }
      renderIdxGrid();
    });

    on($('#btnIdxStudyOne'), 'click', function () {
      if (!state.idxSelected.size) return;
      startTargetedStudy(Array.from(state.idxSelected));
    });

    on($('#btnIdxStudyAll'), 'click', function () {
      var cards = filterIdxCards();
      if (!cards.length) return;
      startTargetedStudy(cards.map(function (c) { return c.id; }));
    });

    on($('#btnStats'), 'click', showStats);
    on($('#btnTheme'), 'click', function () {
      var cur = document.body.dataset.theme;
      applyTheme(cur === 'dark' ? 'light' : 'dark');
      if (state.galaxy) state.galaxy._bgStars = null;
    });
    on($('#modal'), 'click', function (e) {
      if (e.target.id === 'modal') closeModal();
    });

    document.addEventListener('keydown', function (e) {
      var tag = (e.target.tagName || '').toUpperCase();
      if (tag === 'INPUT' || tag === 'TEXTAREA') {
        if (e.key === 'Escape') e.target.blur();
        return;
      }

      if (e.key === 'Escape') {
        var modal = $('#modal');
        if (modal && !modal.hidden) { closeModal(); return; }
        if (state.editing) { exitEdit(); return; }
        if (state.view === 'galaxy' && state.selected) { selectStar(null); return; }
        return;
      }

      if (e.key === 'g' || e.key === 'G') {
        switchView(state.view === 'study' ? 'galaxy' : 'study');
        return;
      }

      if (state.view === 'study') {
        switch (e.key) {
          case ' ':
          case 'Enter':
            e.preventDefault();
            if (state.editing) return;
            state.flipped = !state.flipped;
            renderStudy();
            break;
          case '1': case '2': case '3': case '4':
            if (state.flipped && !state.editing) grade(Number(e.key) - 1);
            break;
          case 'ArrowLeft':  prevStudy(); break;
          case 'ArrowRight': nextStudy(); break;
          case 'r': case 'R': shuffleStudy(); break;
          case 'f': case 'F': toggleStar(); break;
        }
      }
    });
  }

  /* ---- 启动 ---- */
  function boot() {
    state.progress = loadProgress();
    applyTheme(state.progress.settings.theme || 'dark');

    loadData().then(function (json) {
      state.data = normalize(json);
      state.decks = state.data.decks;
      state.cards = flatten(state.data);
      state.cardMap = new Map(state.cards.map(function (c) { return [c.id, c]; }));

      var savedDeck = state.progress.settings.deckId || 'all';
      if (savedDeck !== 'all' &&
          !state.decks.some(function (d) { return d.id === savedDeck; })) {
        savedDeck = 'all';
      }
      state.filterDeck = savedDeck;

      renderChips();
      renderLegend();
      buildStudyOrder();
      renderStudy();
      bindUI();

      var savedView = 'study';
      try { savedView = localStorage.getItem(STORE_VIEW) || 'study'; } catch (e) {}
      if (savedView !== 'study' && savedView !== 'galaxy' && savedView !== 'index') {
        savedView = 'study';
      }
      if (savedView === 'galaxy' && !state.cards.length) savedView = 'study';

      state.view = savedView;
      applyViewUI(state.view);

      if (state.view === 'galaxy') {
        requestAnimationFrame(function () { initGalaxy(); });
      } else if (state.view === 'index') {
        renderIndexView();
      }
    }).catch(function (err) {
      console.error('[boot] 加载失败', err);
      state.data = normalize(EMPTY_DATA);
      state.decks = [];
      state.cards = [];
      state.cardMap = new Map();
      renderChips();
      renderLegend();
      buildStudyOrder();
      renderStudy();
      bindUI();
      applyViewUI('study');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

})();