/* ============================================================
 *  galaxy.js —— 三维知识星空可视化引擎 v3.3
 *
 *  v3.3 修复（右键拖拽）：
 *    · pointermove/pointerup 挂到 document 上
 *        └ 即使鼠标移出 canvas 也能继续拖拽，不会丢事件
 *    · 右键 pointerdown / mousedown 均 preventDefault
 *        └ 阻止浏览器右键菜单与默认行为
 *    · 拖拽期间禁用 userSelect，避免选中页面文本
 *
 *  v3.2 交互与自转：
 *    · 左键拖拽 → 3D 轨道旋转（水平绕 Y、垂直绕 X）
 *    · 右键拖拽 → 绕 Z 轴滚转（Roll）
 *    · 滚轮      → 缩放
 *    · 左键点击  → 选中节点
 *    · 分组自转  → 每个领域组围绕自身中心沿 Y 轴自转
 *
 *  v3.1 可见性：
 *    · 未复习卡片保留基础亮度、基础光晕、基础描边
 *    · 掌握度仅作为"增亮系数"，而非"可见性开关"
 * ============================================================ */
(function (global) {
  'use strict';

  var TAU = Math.PI * 2;

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }

  function hexToRgb(hex) {
    if (!hex) return [125, 155, 255];
    hex = String(hex).replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var n = parseInt(hex, 16);
    if (isNaN(n)) return [125, 155, 255];
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgba(c, a) {
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
  }

  /* ==========================================================
   *  构造函数
   * ========================================================== */
  function Galaxy(canvas, options) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');

    this.opts = Object.assign({
      fov: 980,
      minZoom: 0.35,
      maxZoom: 3.0,
      autoRotate: 0.000038,
      linkLimit: 1200,
      onSelect: null,
      onHover: null
    }, options || {});

    this.nodes = [];
    this.links = [];
    this.byId = new Map();
    this._adj = new Map();

    // 相机旋转：Y (yaw) · X (pitch) · Z (roll)
    this.rotY = -0.55;
    this.rotX = 0.58;         // 更斜的初始俯角，看到 Y 轴分层
    this.rotZ = 0.0;

    this.zoom = 0.42;         // 初始缩放更小，一屏看到全貌
    this.targetZoom = 0.42;

    this.velY = 0;
    this.velX = 0;
    this.velZ = 0;

    this.dragging = false;
    this.dragMode = null;   // 'orbit' | 'roll'
    this.moved = false;
    this.lastX = 0;
    this.lastY = 0;
    this.hoverId = null;
    this.selectedId = null;

    // 分组自转：每个领域组一份
    this.groupSpin = {};

    this.pulse = 0;
    this._lastT = 0;

    this.dpr = 1;
    this.W = 0;
    this.H = 0;
    this._proj = [];
    this._bgStars = null;
    this._retryCount = 0;
    this._ro = null;

    // 保存回调引用，方便解绑
    this._onDocMove = null;
    this._onDocUp = null;

    this._onResize = this.resize.bind(this);
    this._tick = this.tick.bind(this);

    window.addEventListener('resize', this._onResize);

    if (typeof ResizeObserver === 'function') {
      var self = this;
      this._ro = new ResizeObserver(function () { self.resize(); });
      this._ro.observe(this.canvas);
      if (this.canvas.parentElement) this._ro.observe(this.canvas.parentElement);
    }

    this._bindPointer();

    var g = this;
    this.resize();
    requestAnimationFrame(function () {
      g.resize();
      requestAnimationFrame(function () { g.resize(); });
    });

    this._raf = requestAnimationFrame(this._tick);
  }

  Galaxy.prototype.resize = function () {
    var el = this.canvas;
    var w = el.clientWidth;
    var h = el.clientHeight;

    if ((w < 1 || h < 1) && el.parentElement) {
      w = el.parentElement.clientWidth;
      h = el.parentElement.clientHeight;
    }

    if (w < 1 || h < 1) {
      if (this._retryCount < 30) {
        this._retryCount++;
        var self = this;
        setTimeout(function () { self.resize(); }, 50);
      }
      return;
    }
    this._retryCount = 0;

    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = w;
    this.H = h;

    var pw = Math.round(w * this.dpr);
    var ph = Math.round(h * this.dpr);

    if (el.width !== pw || el.height !== ph) {
      el.width = pw;
      el.height = ph;
      this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      this._bgStars = null;
    }
  };

  Galaxy.prototype.setData = function (nodes, links) {
    var self = this;

    this.nodes = nodes || [];
    this.links = [];
    this.byId = new Map();
    this._adj = new Map();
    this.groupSpin = {};

    this.nodes.forEach(function (n, i) {
      n.index = i;
      n.rgb = hexToRgb(n.color);
      if (n.size == null) n.size = 3.6;
      if (n.phase == null) n.phase = (i * 1.618) % TAU;
      if (typeof n.mastery !== 'number') n.mastery = 0;
      self.byId.set(n.id, n);
      self._adj.set(n.id, new Set());

      if (n.group && !self.groupSpin[n.group]) {
        self.groupSpin[n.group] = {
          angle: (typeof n.spinPhase === 'number') ? n.spinPhase : 0,
          speed: (typeof n.spinSpeed === 'number') ? n.spinSpeed : 0
        };
      }
    });

    (links || []).forEach(function (L) {
      var a = self.byId.get(L.a);
      var b = self.byId.get(L.b);
      if (!a || !b || a === b) return;
      L.ai = a.index;
      L.bi = b.index;
      self.links.push(L);
      self._adj.get(L.a).add(L.b);
      self._adj.get(L.b).add(L.a);
    });

    if (this.selectedId && !this.byId.has(this.selectedId)) this.selectedId = null;
    if (this.hoverId && !this.byId.has(this.hoverId)) this.hoverId = null;
  };

  Galaxy.prototype.isLinked = function (a, b) {
    var s = this._adj.get(a);
    return !!(s && s.has(b));
  };

  Galaxy.prototype.select = function (id) {
    this.selectedId = id;
    if (this.opts.onSelect) this.opts.onSelect(id);
  };

  Galaxy.prototype.resetView = function () {
    this.rotY = -0.55;
    this.rotX = 0.58;
    this.rotZ = 0.0;
    this.velX = this.velY = this.velZ = 0;
    this.targetZoom = 0.42;
  };

  /* ==========================================================
   *  指针交互 —— 关键修复：document 级监听 + 右键严格阻止默认
   * ========================================================== */
  Galaxy.prototype._bindPointer = function () {
    var self = this;
    var c = this.canvas;

    c.style.cursor = 'grab';

    /* ---- 双保险：阻止右键菜单 ---- */
    c.addEventListener('contextmenu', function (e) {
      e.preventDefault();
    });
    c.addEventListener('mousedown', function (e) {
      if (e.button === 2) e.preventDefault();
    });

    /* ---- 拖拽中的移动处理（document 级） ---- */
    function onMove(e) {
      if (!self.dragging) return;

      var dx = e.clientX - self.lastX;
      var dy = e.clientY - self.lastY;

      if (Math.abs(dx) + Math.abs(dy) > 2) self.moved = true;

      if (self.dragMode === 'roll') {
        // 右键 → 绕 Z 轴滚转（水平+垂直合成）
        var rz = (dx + dy) * 0.005;
        self.rotZ += rz;
        self.velZ = rz;
      } else {
        // 左键 → 3D 轨道旋转
        self.rotY += dx * 0.0062;
        self.rotX += dy * 0.0052;
        self.velY = dx * 0.0062;
        self.velX = dy * 0.0052;
      }

      self.lastX = e.clientX;
      self.lastY = e.clientY;

      e.preventDefault();
    }

    /* ---- 拖拽结束（document 级） ---- */
    function onUp(e) {
      if (!self.dragging) return;

      var wasMode = self.dragMode;
      self.dragging = false;
      self.dragMode = null;
      c.style.cursor = 'grab';
      document.body.style.userSelect = '';

      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      document.removeEventListener('pointercancel', onUp);

      // 仅左键短按（未移动）才视为"点击选中"
      if (!self.moved && wasMode === 'orbit') {
        var rect = c.getBoundingClientRect();
        var hit = self._hitTest(e.clientX - rect.left, e.clientY - rect.top);
        self.select(hit ? hit.id : null);
      }
    }

    self._onDocMove = onMove;
    self._onDocUp = onUp;

    /* ---- 按下 ---- */
    c.addEventListener('pointerdown', function (e) {
      var mode;
      if (e.pointerType === 'mouse') {
        if (e.button === 0)      mode = 'orbit';
        else if (e.button === 2) { mode = 'roll'; e.preventDefault(); }
        else return; // 中键等其他按键忽略
      } else {
        mode = 'orbit';
      }

      self.dragMode = mode;
      self.dragging = true;
      self.moved = false;
      self.lastX = e.clientX;
      self.lastY = e.clientY;
      self.velY = 0;
      self.velX = 0;
      self.velZ = 0;

      document.body.style.userSelect = 'none';
      c.style.cursor = (mode === 'roll') ? 'crosshair' : 'grabbing';

      // 关键：挂到 document 上，鼠标移出 canvas 也不丢事件
      document.addEventListener('pointermove', onMove);
      document.addEventListener('pointerup', onUp);
      document.addEventListener('pointercancel', onUp);

      // 同时保留 canvas 上的 mousemove，以便非拖拽时做悬停
      e.preventDefault();
    });

    /* ---- 悬停（非拖拽状态） ---- */
    c.addEventListener('pointermove', function (e) {
      if (self.dragging) return;
      var rect = c.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;

      var hit = self._hitTest(mx, my);
      var id = hit ? hit.id : null;

      if (id !== self.hoverId) {
        self.hoverId = id;
        c.style.cursor = id ? 'pointer' : 'grab';
      }
      if (self.opts.onHover) self.opts.onHover(hit, mx, my);
    });

    c.addEventListener('pointerleave', function () {
      if (self.dragging) return;
      if (self.hoverId) {
        self.hoverId = null;
        if (self.opts.onHover) self.opts.onHover(null);
      }
    });

    /* ---- 滚轮缩放 ---- */
    c.addEventListener('wheel', function (e) {
      e.preventDefault();
      var k = Math.exp(-e.deltaY * 0.0011);
      self.targetZoom = clamp(self.targetZoom * k, self.opts.minZoom, self.opts.maxZoom);
    }, { passive: false });
  };

  Galaxy.prototype._hitTest = function (mx, my) {
    var best = null;
    var bestScore = Infinity;

    for (var i = 0; i < this._proj.length; i++) {
      var p = this._proj[i];
      var dx = p.sx - mx;
      var dy = p.sy - my;
      var d2 = dx * dx + dy * dy;

      var hitR = Math.max(14, p.r * 2.6);
      if (d2 > hitR * hitR) continue;

      var score = d2 + Math.max(0, p.z) * 1.6;
      if (score < bestScore) {
        bestScore = score;
        best = p.n;
      }
    }
    return best;
  };

  /* ==========================================================
   *  主循环
   * ========================================================== */
  Galaxy.prototype.tick = function (t) {
    var dt = this._lastT ? Math.min(48, t - this._lastT) : 16;
    this._lastT = t;
    this.pulse += dt * 0.001;

    // 分组自转（始终运行）
    var dtSec = dt * 0.001;
    var gs = this.groupSpin;
    for (var k in gs) {
      if (gs.hasOwnProperty(k)) {
        gs[k].angle += (gs[k].speed || 0) * dtSec;
      }
    }

    if (this.canvas.offsetParent !== null) {
      if (!this.dragging) {
        // 惯性
        this.rotY += this.velY;
        this.rotX += this.velX;
        this.rotZ += this.velZ;
        this.velY *= 0.935;
        this.velX *= 0.935;
        this.velZ *= 0.935;
        if (Math.abs(this.velY) < 1e-5) this.velY = 0;
        if (Math.abs(this.velX) < 1e-5) this.velX = 0;
        if (Math.abs(this.velZ) < 1e-5) this.velZ = 0;

        // 空闲时相机水平环绕
        if (!this.hoverId && !this.selectedId) {
          this.rotY += this.opts.autoRotate * dt;
        }
      }

      this.rotX = clamp(this.rotX, -1.36, 1.36);
      this.rotZ = this.rotZ % TAU;

      this.zoom = lerp(this.zoom, this.targetZoom, 0.13);

      this.render();
    }

    this._raf = requestAnimationFrame(this._tick);
  };

  /* ==========================================================
   *  背景星
   * ========================================================== */
  Galaxy.prototype._getBgStars = function () {
    if (this._bgStars) return this._bgStars;

    var count = clamp(Math.round((this.W * this.H) / 9000), 50, 220);
    var arr = [];
    for (var i = 0; i < count; i++) {
      arr.push({
        x: Math.random(),
        y: Math.random(),
        r: Math.random() * 0.9 + 0.2,
        a: Math.random() * 0.22 + 0.04,
        p: Math.random() * TAU,
        sp: 0.35 + Math.random() * 1.1
      });
    }
    this._bgStars = arr;
    return arr;
  };

  Galaxy.prototype._drawBackdrop = function (ctx) {
    var stars = this._getBgStars();
    var light = document.body.dataset.theme === 'light';

    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var tw = 0.62 + Math.sin(this.pulse * s.sp + s.p) * 0.38;
      ctx.fillStyle = light
        ? 'rgba(60,80,140,' + (s.a * tw * 0.75) + ')'
        : 'rgba(200,215,255,' + (s.a * tw) + ')';
      ctx.beginPath();
      ctx.arc(s.x * this.W, s.y * this.H, s.r, 0, TAU);
      ctx.fill();
    }
  };

  /* ==========================================================
   *  渲染
   * ========================================================== */
  Galaxy.prototype.render = function () {
    var ctx = this.ctx;
    var W = this.W;
    var H = this.H;

    if (W < 1 || H < 1) return;

    ctx.clearRect(0, 0, W, H);
    this._drawBackdrop(ctx);

    if (!this.nodes.length) return;

    var cx = W / 2;
    var cy = H / 2;
    var fov = this.opts.fov;
    var zoom = this.zoom;

    var cosY = Math.cos(this.rotY), sinY = Math.sin(this.rotY);
    var cosX = Math.cos(this.rotX), sinX = Math.sin(this.rotX);
    var cosZ = Math.cos(this.rotZ), sinZ = Math.sin(this.rotZ);

    var groupSpin = this.groupSpin;
    var proj = this._proj;
    proj.length = 0;

    /* ---------- 投影 ---------- */
    for (var i = 0; i < this.nodes.length; i++) {
      var n = this.nodes[i];

      // ---- 1) 分组自转（围绕所属领域中心，沿 Y 轴）----
      var wx = n.x, wy = n.y, wz = n.z;
      if (n.group && n.pivot) {
        var g = groupSpin[n.group];
        if (g && g.speed !== 0) {
          var cosS = Math.cos(g.angle), sinS = Math.sin(g.angle);
          var dx0 = n.x - n.pivot.x;
          var dz0 = n.z - n.pivot.z;
          wx = n.pivot.x + dx0 * cosS + dz0 * sinS;
          wz = n.pivot.z - dx0 * sinS + dz0 * cosS;
        }
      }

      // ---- 2) 相机 3D 旋转：先 Y，再 X，最后 Z ----
      var x1 =  wx * cosY + wz * sinY;
      var z1 = -wx * sinY + wz * cosY;

      var y2 = wy * cosX - z1 * sinX;
      var z2 = wy * sinX + z1 * cosX;

      var x3 = x1 * cosZ - y2 * sinZ;
      var y3 = x1 * sinZ + y2 * cosZ;

      // ---- 3) 透视投影 ----
      var depth = fov + z2;
      if (depth < 80) depth = 80;

      var s = (fov / depth) * zoom;

      proj.push({
        n: n,
        sx: cx + x3 * s,
        sy: cy - y3 * s,
        s: s,
        z: z2,
        r: Math.max(1.2, n.size * s)
      });
    }

    var active = this.hoverId || this.selectedId;
    var self = this;

    /* ---------- 连线 ---------- */
    if (this.links.length && this.links.length <= this.opts.linkLimit) {
      ctx.lineCap = 'round';

      for (var k = 0; k < this.links.length; k++) {
        var L = this.links[k];
        var a = proj[L.ai];
        var b = proj[L.bi];
        if (!a || !b) continue;

        if ((a.sx < -80 && b.sx < -80) || (a.sx > W + 80 && b.sx > W + 80)) continue;
        if ((a.sy < -80 && b.sy < -80) || (a.sy > H + 80 && b.sy > H + 80)) continue;

        var isAct = active && (L.a === active || L.b === active);
        var ma = a.n.mastery || 0;
        var mb = b.n.mastery || 0;
        var linkM = Math.min(ma, mb);

        var alpha;
        if (active) {
          alpha = isAct ? 0.85 : 0.10;
        } else {
          alpha = (0.12 + linkM * 0.5) * (L.w || 0.5) + 0.06;
        }

        var dep = clamp(1.2 - ((a.z + b.z) * 0.5) / 900, 0.35, 1.2);
        alpha *= dep;
        if (alpha < 0.025) continue;

        ctx.strokeStyle = isAct
          ? 'rgba(180,205,255,' + alpha.toFixed(3) + ')'
          : 'rgba(130,158,215,' + alpha.toFixed(3) + ')';
        ctx.lineWidth = isAct ? 1.8 : 0.9;

        ctx.beginPath();
        ctx.moveTo(a.sx, a.sy);
        ctx.lineTo(b.sx, b.sy);
        ctx.stroke();
      }
    }

    /* ---------- 节点（按 z 排序，远 → 近） ---------- */
    var order = proj.slice().sort(function (p, q) { return q.z - p.z; });

    for (var j = 0; j < order.length; j++) {
      var p = order[j];
      var node = p.n;
      var mastery = typeof node.mastery === 'number' ? node.mastery : 0;

      if (p.sx < -60 || p.sx > W + 60 || p.sy < -60 || p.sy > H + 60) continue;

      var isHover = node.id === this.hoverId;
      var isSel   = node.id === this.selectedId;
      var isAct   = isHover || isSel;

      var alphaN = 0.55 + mastery * 0.45;

      if (active) {
        if (isAct) {
          alphaN = 1;
        } else if (self.isLinked(active, node.id)) {
          alphaN = Math.max(alphaN, 0.78);
        } else {
          alphaN = Math.min(alphaN, 0.30);
        }
      }

      alphaN *= clamp(0.75 + p.s * 0.35, 0.70, 1.10);

      var breathe = 1 + Math.sin(this.pulse * 1.7 + node.phase) * 0.085;
      var R = p.r * (isAct ? 1.7 : 1) * breathe;

      var glowStrength = isAct ? 1 : (0.35 + mastery * 0.65);

      if (R * 4.2 > 2.5) {
        var glowR = R * 4.2 * (0.75 + glowStrength * 0.55);
        var g2 = ctx.createRadialGradient(p.sx, p.sy, 0, p.sx, p.sy, glowR);
        g2.addColorStop(0,    rgba(node.rgb, 0.45 * alphaN * glowStrength));
        g2.addColorStop(0.32, rgba(node.rgb, 0.15 * alphaN * glowStrength));
        g2.addColorStop(1,    rgba(node.rgb, 0));
        ctx.fillStyle = g2;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, glowR, 0, TAU);
        ctx.fill();
      }

      ctx.fillStyle = 'rgba(255,255,255,' + Math.min(1, 0.95 * alphaN).toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(p.sx, p.sy, Math.max(0.7, R * 0.50), 0, TAU);
      ctx.fill();

      ctx.strokeStyle = rgba(node.rgb, (0.60 + mastery * 0.40) * alphaN);
      ctx.lineWidth = Math.max(0.9, R * 0.24);
      ctx.beginPath();
      ctx.arc(p.sx, p.sy, R, 0, TAU);
      ctx.stroke();

      if (isSel) {
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.60 * alphaN).toFixed(3) + ')';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, R * 2.2, 0, TAU);
        ctx.stroke();
      }
    }
  };

  Galaxy.prototype.destroy = function () {
    cancelAnimationFrame(this._raf);
    window.removeEventListener('resize', this._onResize);
    if (this._ro) {
      this._ro.disconnect();
      this._ro = null;
    }
    if (this._onDocMove) document.removeEventListener('pointermove', this._onDocMove);
    if (this._onDocUp) {
      document.removeEventListener('pointerup', this._onDocUp);
      document.removeEventListener('pointercancel', this._onDocUp);
    }
  };

  global.Galaxy = Galaxy;

})(window);