/* ============================================================
 *  datastore.js —— 文件系统持久层
 *  使用 File System Access API
 *  · 保存/恢复目录句柄（IndexedDB）
 *  · 读写 JSON 文件
 *  · 列出子目录与文件
 * ============================================================ */
(function (global) {
  'use strict';

  var DB_NAME = 'kstar-fs';
  var DB_VERSION = 1;
  var STORE = 'handles';
  var KEY = 'dataDir';

  function openDB() {
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error); };
    });
  }

  function idbGet(key) {
    return openDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readonly');
        var req = tx.objectStore(STORE).get(key);
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function idbSet(key, value) {
    return openDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readwrite');
        var req = tx.objectStore(STORE).put(value, key);
        req.onsuccess = function () { resolve(); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function idbDel(key) {
    return openDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readwrite');
        var req = tx.objectStore(STORE).delete(key);
        req.onsuccess = function () { resolve(); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function isSupported() {
    return typeof window.showDirectoryPicker === 'function';
  }

  function pickDirectory() {
    if (!isSupported()) {
      return Promise.reject(new Error('当前浏览器不支持 File System Access API，请用 Chrome / Edge'));
    }
    return window.showDirectoryPicker({ mode: 'readwrite' });
  }

  function verifyPermission(handle, readWrite) {
    var opts = { mode: readWrite ? 'readwrite' : 'read' };
    return handle.queryPermission(opts).then(function (state) {
      if (state === 'granted') return true;
      return handle.requestPermission(opts).then(function (s) {
        return s === 'granted';
      });
    });
  }

  function getSavedHandle()    { return idbGet(KEY); }
  function saveHandle(h)       { return idbSet(KEY, h); }
  function clearSavedHandle()  { return idbDel(KEY); }

  /* ---------- 文件读写 ---------- */

  function readJSON(dir, name) {
    return dir.getFileHandle(name, { create: false })
      .then(function (fh) { return fh.getFile(); })
      .then(function (f) { return f.text(); })
      .then(function (text) {
        if (!text.trim()) return null;
        try { return JSON.parse(text); }
        catch (e) { throw new Error('JSON 解析失败：' + name); }
      })
      .catch(function (e) {
        if (e && e.name === 'NotFoundError') return null;
        throw e;
      });
  }

  function writeJSON(dir, name, data) {
    return dir.getFileHandle(name, { create: true })
      .then(function (fh) { return fh.createWritable(); })
      .then(function (w) {
        return w.write(JSON.stringify(data, null, 2)).then(function () {
          return w.close();
        });
      });
  }

  function deleteEntry(dir, name) {
    return dir.removeEntry(name).catch(function (e) {
      if (e && e.name === 'NotFoundError') return;
      throw e;
    });
  }

  function getSubdir(parent, name, create) {
    return parent.getDirectoryHandle(name, { create: !!create });
  }

  function listJSONFiles(dir) {
    var out = [];
    if (!dir || typeof dir.values !== 'function') return Promise.resolve(out);
    var iter = dir.values();
    function next() {
      return iter.next().then(function (res) {
        if (res.done) return out;
        var e = res.value;
        if (e.kind === 'file' && /\.json$/i.test(e.name)) out.push(e.name);
        return next();
      });
    }
    return next();
  }

  global.DataStore = {
    isSupported: isSupported,
    pickDirectory: pickDirectory,
    verifyPermission: verifyPermission,
    getSavedHandle: getSavedHandle,
    saveHandle: saveHandle,
    clearSavedHandle: clearSavedHandle,
    readJSON: readJSON,
    writeJSON: writeJSON,
    deleteEntry: deleteEntry,
    getSubdir: getSubdir,
    listJSONFiles: listJSONFiles
  };

})(window);