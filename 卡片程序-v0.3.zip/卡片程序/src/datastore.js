/* ============================================================
 *  datastore.js —— 文件系统持久层（容错版）
 *  · IndexedDB 不可用时降级到内存存储
 *  · 所有 IDB 操作静默失败，不阻断应用
 * ============================================================ */
(function (global) {
  'use strict';

  var DB_NAME = 'kstar-fs';
  var DB_VERSION = 1;
  var STORE = 'handles';
  var KEY = 'dataDir';

  // ★ 内存兜底：IDB 全挂时，本次会话仍可用文件夹（刷新后需重选）
  var _memHandles = {};

  function openDB() {
    return new Promise(function (resolve, reject) {
      if (typeof indexedDB === 'undefined') {
        return reject(new Error('IndexedDB unavailable'));
      }
      var req;
      try {
        req = indexedDB.open(DB_NAME, DB_VERSION);
      } catch (e) {
        return reject(e);
      }
      req.onupgradeneeded = function () {
        try {
          var db = req.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
        } catch (e) { /* ignore */ }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror   = function () { reject(req.error || new Error('IndexedDB open failed')); };
      req.onblocked = function () { reject(new Error('IndexedDB blocked')); };
    });
  }

  function idbGet(key) {
    return openDB().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readonly');
          var req = tx.objectStore(STORE).get(key);
          req.onsuccess = function () { resolve(req.result); };
          req.onerror   = function () { resolve(_memHandles[key]); };
        } catch (e) {
          resolve(_memHandles[key]);
        }
      });
    }).catch(function () {
      // ★ 打不开 DB 也返回内存兜底，而不是抛错
      return _memHandles[key];
    });
  }

  function idbSet(key, value) {
    // 先写内存，保证本次会话一定可用
    _memHandles[key] = value;
    return openDB().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          var req = tx.objectStore(STORE).put(value, key);
          req.onsuccess = function () { resolve(); };
          req.onerror   = function () { resolve(); };
        } catch (e) {
          resolve();
        }
      });
    }).catch(function () {
      // ★ 配额满 / 磁盘满 / 隐私模式，静默吞掉
      return undefined;
    });
  }

  function idbDel(key) {
    delete _memHandles[key];
    return openDB().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          var req = tx.objectStore(STORE).delete(key);
          req.onsuccess = function () { resolve(); };
          req.onerror   = function () { resolve(); };
        } catch (e) {
          resolve();
        }
      });
    }).catch(function () {
      return undefined;
    });
  }

  function isSupported() {
    return typeof window.showDirectoryPicker === 'function';
  }

  function pickDirectory() {
    if (!isSupported()) {
      return Promise.reject(new Error('当前浏览器不支持 File System Access API，请用 Chrome / Edge'));
    }
    return window.showDirectoryPicker({ mode: 'readwrite' });
  }

  function verifyPermission(handle, readWrite) {
    var opts = { mode: readWrite ? 'readwrite' : 'read' };
    return handle.queryPermission(opts).then(function (state) {
      if (state === 'granted') return true;
      return handle.requestPermission(opts).then(function (s) {
        return s === 'granted';
      });
    });
  }

  function getSavedHandle()   { return idbGet(KEY); }
  function saveHandle(h)      { return idbSet(KEY, h); }
  function clearSavedHandle() { return idbDel(KEY); }

  /* ---------- 文件读写 ---------- */

  function readJSON(dir, name) {
    return dir.getFileHandle(name, { create: false })
      .then(function (fh) { return fh.getFile(); })
      .then(function (f)  { return f.text(); })
      .then(function (text) {
        if (!text.trim()) return null;
        try { return JSON.parse(text); }
        catch (e) { throw new Error('JSON 解析失败：' + name); }
      })
      .catch(function (e) {
        if (e && e.name === 'NotFoundError') return null;
        throw e;
      });
  }

  function writeJSON(dir, name, data) {
    return dir.getFileHandle(name, { create: true })
      .then(function (fh) { return fh.createWritable(); })
      .then(function (w) {
        return w.write(JSON.stringify(data, null, 2)).then(function () {
          return w.close();
        });
      });
  }

  function deleteEntry(dir, name) {
    return dir.removeEntry(name).catch(function (e) {
      if (e && e.name === 'NotFoundError') return;
      throw e;
    });
  }

  /* ---------- 子目录 ---------- */

  function getSubdir(parent, name, create) {
    if (!parent || typeof parent.getDirectoryHandle !== 'function') {
      return Promise.reject(new Error('无效的目录句柄'));
    }
    return parent.getDirectoryHandle(name, { create: !!create });
  }

  function listJSONFiles(dir) {
    if (!dir || typeof dir.values !== 'function') return Promise.resolve([]);
    var out = [];
    var it = dir.values();
    function step() {
      return it.next().then(function (r) {
        if (r.done) return out;
        var entry = r.value;
        if (entry.kind === 'file' && /\.json$/i.test(entry.name)) {
          out.push(entry.name);
        }
        return step();
      });
    }
    return step().catch(function () { return out; });
  }

  global.DataStore = {
    isSupported: isSupported,
    pickDirectory: pickDirectory,
    verifyPermission: verifyPermission,
    getSavedHandle: getSavedHandle,
    saveHandle: saveHandle,
    clearSavedHandle: clearSavedHandle,
    readJSON: readJSON,
    writeJSON: writeJSON,
    deleteEntry: deleteEntry,
    getSubdir: getSubdir,
    listJSONFiles: listJSONFiles
  };

})(window);