@echo off
setlocal
cd /d "%~dp0"
title KStar Local Server

if not exist "data" mkdir "data"
if not exist "data\decks" mkdir "data\decks"
if not exist "data\_snapshot.json" (
  echo {"version":"4.6","kind":"snapshot","meta":{"title":"知识星空"},"decks":[]} > "data\_snapshot.json"
)

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 server.py
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python server.py
  goto :end
)
echo Python 3 not found. Install from https://www.python.org/downloads/
pause
:end