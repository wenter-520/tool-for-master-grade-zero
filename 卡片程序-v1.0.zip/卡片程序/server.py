#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KStar local server —— 静态文件 + data 目录读写 API
零依赖，仅用 Python 标准库。
"""

import http.server
import socketserver
import json
import os
import socket
import threading
import webbrowser
from urllib.parse import urlparse, unquote

ROOT       = os.path.dirname(os.path.abspath(__file__))
DATA_DIR   = os.path.join(ROOT, 'data')
DECKS_DIR  = os.path.join(DATA_DIR, 'decks')
SNAPSHOT   = os.path.join(DATA_DIR, '_snapshot.json')

os.makedirs(DECKS_DIR, exist_ok=True)


def json_response(handler, obj, status=200):
    body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(body)))
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('Access-Control-Allow-Origin', '*')
    handler.send_header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    handler.send_header('Access-Control-Allow-Headers', 'Content-Type')
    handler.end_headers()
    handler.wfile.write(body)


class Handler(http.server.SimpleHTTPRequestHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        if not self.path.startswith('/api/'):
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
            self.send_header('Pragma', 'no-cache')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    # ---------------- GET ----------------
    def do_GET(self):
        path = urlparse(self.path).path

        if path == '/api/ping':
            return json_response(self, {'ok': True, 'mode': 'server'})

        if path == '/api/snapshot':
            if os.path.exists(SNAPSHOT):
                try:
                    with open(SNAPSHOT, 'r', encoding='utf-8') as f:
                        return json_response(self, json.load(f))
                except Exception:
                    pass
            return json_response(self, {})

        if path == '/api/decks-list':
            files = []
            try:
                for name in os.listdir(DECKS_DIR):
                    if name.endswith('.json'):
                        files.append(name)
            except Exception:
                pass
            return json_response(self, {'files': files})

        if path.startswith('/api/deck/'):
            deck_id = unquote(path[len('/api/deck/'):])
            if not self._safe_id(deck_id):
                return json_response(self, {'ok': False, 'error': 'bad id'}, 400)
            fp = os.path.join(DECKS_DIR, deck_id + '.json')
            if os.path.exists(fp):
                try:
                    with open(fp, 'r', encoding='utf-8') as f:
                        return json_response(self, json.load(f))
                except Exception:
                    pass
            return json_response(self, None, 404)

        return super().do_GET()

    # ---------------- PUT ----------------
    def do_PUT(self):
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length) if length else b''
            data = json.loads(body.decode('utf-8')) if body else None
        except Exception as e:
            return json_response(self, {'ok': False, 'error': str(e)}, 400)

        if path == '/api/snapshot':
            try:
                with open(SNAPSHOT, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                return json_response(self, {'ok': True})
            except Exception as e:
                return json_response(self, {'ok': False, 'error': str(e)}, 500)

        if path.startswith('/api/deck/'):
            deck_id = unquote(path[len('/api/deck/'):])
            if not self._safe_id(deck_id):
                return json_response(self, {'ok': False, 'error': 'bad id'}, 400)
            fp = os.path.join(DECKS_DIR, deck_id + '.json')
            try:
                with open(fp, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                return json_response(self, {'ok': True})
            except Exception as e:
                return json_response(self, {'ok': False, 'error': str(e)}, 500)

        return json_response(self, {'ok': False, 'error': 'not found'}, 404)

    # ---------------- DELETE ----------------
    def do_DELETE(self):
        path = urlparse(self.path).path
        if path.startswith('/api/deck/'):
            deck_id = unquote(path[len('/api/deck/'):])
            if not self._safe_id(deck_id):
                return json_response(self, {'ok': False, 'error': 'bad id'}, 400)
            fp = os.path.join(DECKS_DIR, deck_id + '.json')
            try:
                if os.path.exists(fp):
                    os.remove(fp)
                return json_response(self, {'ok': True})
            except Exception as e:
                return json_response(self, {'ok': False, 'error': str(e)}, 500)
        return json_response(self, {'ok': False, 'error': 'not found'}, 404)

    @staticmethod
    def _safe_id(s):
        if not s:
            return False
        if '/' in s or '\\' in s or '..' in s:
            return False
        return True

    def log_message(self, fmt, *args):
        try:
            msg = fmt % args
        except Exception:
            msg = fmt
        if '/api/' in msg:
            return
        super().log_message(fmt, *args)


def find_port(start=8000, end=8020):
    for p in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('127.0.0.1', p))
                return p
            except OSError:
                continue
    return None


def main():
    port = find_port()
    if not port:
        print('No free port in 8000-8020')
        return

    url = 'http://localhost:%d/admin.html' % port
    print('=' * 56)
    print('  KStar local server')
    print('  URL:  %s' % url)
    print('  Data: %s' % DATA_DIR)
    print('  Stop: Ctrl+C')
    print('=' * 56)

    threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    with socketserver.TCPServer(('127.0.0.1', port), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print('\nStopped.')


if __name__ == '__main__':
    main()