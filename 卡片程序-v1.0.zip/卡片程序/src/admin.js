/* ============================================================
 *  admin.js —— 卡片管理页 v4.9.0
 *  关联卡片选择器：多分组完整列表
 *    · 分组1：标签匹配（所有领域，按命中标签数排序）
 *    · 分组2：同第三分级（与当前卡片属同一 L3 领域）
 *    · 分组3+：第三分级下的各分级（L4、L5、L6...逐层）
 *    · 分组N：其他层级（兜底）
 *  每组完整展示，不截断。
 *
 *  v4.9.0 修复：
 *    · 领域树卡片计数向上聚合（含全部子领域）
 *    · 空状态智能提示子领域卡片数量
 *    · 切换按钮文案更明确
 * ============================================================ */
(function () {
  'use strict';

  var STORE_DATA = 'kstar.data.v1';
  var DECKS_DIR  = 'decks';

  var PALETTE = ['#7d9bff', '#5ec8f5', '#6ee7b7', '#f0d264',
                 '#f0a07d', '#c99bff', '#7dd3fc', '#fca5a5'];

  var EMPTY_DATA = {
    meta: { title: '知识星空', version: '4.6', updatedAt: '' },
    decks: []
  };

  // 关联分组中「第三分级」对应的深度（顶层为 0）
  var TARGET_LEVEL = 3;

  var $  = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }
  function fmt(s) {
    var out = esc(s);
    out = out.replace(/`([^`]+)`/g, '<code>$1</code>');
    out = out.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
    out = out.replace(/\n/g, '<br>');
    return out;
  }
  function truncate(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n) + '…' : s;
  }
  function uid(p) { return (p || '') + Math.random().toString(36).slice(2, 8); }

  function renderKatex(src, display) {
    if (typeof katex === 'undefined') {
      return '<span class="formula-raw">' + esc(src) + '</span>';
    }
    try {
      return katex.renderToString(src, {
        throwOnError: false, displayMode: !!display, output: 'html'
      });
    } catch (e) {
      return '<span class="formula-error">' + esc(src) + '</span>';
    }
  }

  function renderMixedLatex(src) {
    var out = '', buf = '', i = 0;
    while (i < src.length) {
      if (src[i] === '$') {
        if (buf) { out += esc(buf).replace(/\n/g, '<br>'); buf = ''; }
        var isBlock = src[i + 1] === '$';
        var start = i + (isBlock ? 2 : 1);
        var closeTag = isBlock ? '$$' : '$';
        var end = src.indexOf(closeTag, start);
        if (end < 0) { buf += src.slice(i); break; }
        out += renderKatex(src.slice(start, end), isBlock);
        i = end + closeTag.length;
      } else { buf += src[i]; i++; }
    }
    if (buf) out += esc(buf).replace(/\n/g, '<br>');
    return out;
  }

  function renderFormula(latex) {
    if (!latex || !String(latex).trim()) return '';
    var src = String(latex).trim();
    if (src.indexOf('$') >= 0) return renderMixedLatex(src);
    return renderKatex(src, true);
  }

  var toastTimer = null;
  function toast(msg) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2200);
  }

  function download(text, filename) {
    var blob = new Blob([text], { type: 'application/json;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  /* ---------------- 状态 ---------------- */
  var state = {
    data: JSON.parse(JSON.stringify(EMPTY_DATA)),
    deckId: null,
    cardId: null,
    collapsed: {},
    includeSubDecks: false,

    mode: 'manage',

    libFilters: {
      search: '',
      decks: new Set(),
      tags: new Set(),
      states: new Set()
    }
  };

  var fs = { supported: false, dir: null, name: '', connected: false };

  /* ==========================================================
   *  文件系统
   * ========================================================== */
function updateFSState() {
  var label = $('#fsLabel');
  var btn = $('#btnConnect');
  if (!label || !btn) return;

  // ★ 服务器模式：直接显示"已连接"
  if (DataStore.isServerMode()) {
    label.textContent = '已连接：data（本地服务）';
    btn.classList.add('connected');
    btn.disabled = false;
    btn.title = '本地服务器自动读写 data/ 目录，无需手动操作';
    return;
  }

  if (!fs.supported) {
    label.textContent = '浏览器不支持自动保存';
    btn.disabled = true;
    btn.title = '请使用 Chrome / Edge 浏览器';
    return;
  }
  if (fs.connected) {
    label.textContent = '已连接：' + fs.name;
    btn.classList.add('connected');
    btn.title = '当前数据目录：' + fs.name + '\n点击可重新选择或断开';
  } else {
    label.textContent = '连接数据目录';
    btn.classList.remove('connected');
    btn.title = '选择项目根目录即可，程序会自动进入其下的 data 子目录';
  }
}

function restoreDir() {
  if (!fs.supported) return Promise.resolve(false);
  return DataStore.getSavedHandle().then(function (h) {
    if (!h) return false;
    return DataStore.verifyPermission(h, true).then(function (ok) {
      if (!ok) return false;
      // ★ 关键：把保存的句柄规整到 data 目录
      return resolveDataDir(h).then(function (dataDir) {
        fs.dir = dataDir;
        fs.name = dataDir.name;
        fs.connected = true;
        return loadFromDir().then(function () { return true; });
      });
    });
  }).catch(function () { return false; });
}

function chooseDir() {
  // ★ 服务器模式：不做任何选择，直接（重新）连接
  if (DataStore.isServerMode()) {
    return DataStore.pickDirectory().then(function (h) {
      fs.dir = h; fs.name = h.name; fs.connected = true;
      updateFSState();
      return loadFromDir();
    }).then(function () {
      renderAll();
      toast('已连接本地数据目录：' + fs.name);
    });
  }

  // 原逻辑保持不动
  if (!fs.supported) {
    toast('当前浏览器不支持，请用 Chrome / Edge');
    return;
  }
  DataStore.pickDirectory()
    .then(function (h) {
      return DataStore.verifyPermission(h, true).then(function (ok) {
        if (!ok) throw new Error('未授权读写');
        return DataStore.saveHandle(h).then(function () { return h; });
      });
    })
    .then(function (h) {
      return resolveDataDir(h).then(function (dataDir) {
        fs.dir = dataDir;
        fs.name = dataDir.name;
        fs.connected = true;
        updateFSState();
        return loadFromDir();
      });
    })
    .then(function () {
      toast('已连接：' + fs.name);
      var hasLocal = state.data.decks.length > 0;
      if (hasLocal) {
        var list = state.data.decks.filter(function (d) { return !d.parentId; });
        if (list.length) {
          if (confirm('检测到浏览器中已有 ' + list.length + ' 个顶层领域。\n是否把当前数据写入该文件夹？')) {
            return Promise.all(list.map(function (d) { return saveTopDeckFile(d.id); }));
          }
        }
      }
    })
    .then(function () { renderAll(); })
    .catch(function (e) {
      if (e && e.name === 'AbortError') return;
      toast('连接失败：' + (e.message || e));
    });
}
function disconnectDir() {
  if (DataStore.isServerMode()) {
    toast('本地服务模式下无法断开，请直接关闭服务窗口');
    return;
  }
  if (!confirm('断开后，数据将仅保存在浏览器中，不再写入文件夹。\n继续？')) return;
  fs.dir = null; fs.name = ''; fs.connected = false;
  DataStore.clearSavedHandle();
  updateFSState();
  toast('已断开数据目录');
}

  function loadFromDir() {
    if (!fs.connected || !fs.dir) return Promise.resolve();
    var decksDir;
    return DataStore.getSubdir(fs.dir, DECKS_DIR, true)
      .then(function (d) { decksDir = d; return DataStore.listJSONFiles(d); })
      .then(function (files) {
        return Promise.all(files.map(function (name) {
          return DataStore.readJSON(decksDir, name).catch(function () { return null; });
        }));
      })
      .then(function (parts) {
        var merged = { meta: { title: '知识星空', version: '4.6' }, decks: [] };
        parts.forEach(function (p) {
          if (!p || !Array.isArray(p.decks)) return;
          p.decks.forEach(function (d) { merged.decks.push(d); });
        });
        state.data = normalize(merged);
        state.deckId = state.data.decks[0] ? state.data.decks[0].id : null;
        state.cardId = null;
        mirrorToLocal();
      });
  }

  function mirrorToLocal() {
    try { localStorage.setItem(STORE_DATA, JSON.stringify(state.data)); } catch (e) {}
  }

  function getTopAncestorId(deckId) {
    var cur = getDeck(deckId);
    var guard = 0;
    while (cur && cur.parentId && guard++ < 100) cur = getDeck(cur.parentId);
    return cur ? cur.id : null;
  }

/**
 * ★ 新增：把用户选择的目录句柄规整到真正的 data 目录
 *
 * 支持三种情况：
 *   A. 选中的就是 data 目录（内部含 decks 子目录）  → 直接用
 *   B. 选中的是项目根目录（内含 data 子目录）        → 自动进入 data
 *   C. 其他目录（无明显 data / decks 结构）         → 原样返回
 *
 * 这样用户只需选一次项目根目录，之后程序会自动定位到 data。
 */
function resolveDataDir(handle) {
  if (!handle || typeof handle.getDirectoryHandle !== 'function') {
    return Promise.resolve(handle);
  }

  // A. 自身是否已经是一个 data 目录（含 decks 子目录）
  return handle.getDirectoryHandle('decks', { create: false })
    .then(function () {
      return handle;
    })
    .catch(function () {
      // B. 尝试向下进入 data 子目录
      return handle.getDirectoryHandle('data', { create: false })
        .then(function (dataDir) { return dataDir; })
        .catch(function () {
          // C. 都不匹配，原样返回
          return handle;
        });
    });
}

  function saveTopDeckFile(topId) {
    if (!fs.connected || !fs.dir) return Promise.resolve();
    var top = getDeck(topId);
    if (!top) return Promise.resolve();
    var ids = getDescendantIds(topId);
    var list = state.data.decks.filter(function (d) { return ids.has(d.id); });
    if (!list.length) return Promise.resolve();

    return DataStore.getSubdir(fs.dir, DECKS_DIR, true)
      .then(function (decksDir) {
        return DataStore.writeJSON(decksDir, topId + '.json', {
          version: '4.6',
          updatedAt: new Date().toISOString(),
          decks: list
        });
      })
      .catch(function (e) {
        console.error('[saveTopDeckFile]', e);
        setSaveState('文件写入失败', true);
      });
  }

  function saveFor(deckId) {
    if (!fs.connected || !fs.dir) return Promise.resolve();
    var topId = getTopAncestorId(deckId || state.deckId);
    if (!topId) return Promise.resolve();
    return saveTopDeckFile(topId).then(function () {
      setSaveState('已同步到文件 ✓', false);
    });
  }

  function deleteTopDeckFile(topId) {
    if (!fs.connected || !fs.dir) return Promise.resolve();
    return DataStore.getSubdir(fs.dir, DECKS_DIR, true)
      .then(function (decksDir) { return DataStore.deleteEntry(decksDir, topId + '.json'); })
      .catch(function () {});
  }

  /* ==========================================================
   *  数据规范化
   * ========================================================== */
  function normalize(json) {
    if (!json || typeof json !== 'object') json = JSON.parse(JSON.stringify(EMPTY_DATA));
    if (!json.meta || typeof json.meta !== 'object') json.meta = { title: '知识星空', version: '4.6' };
    if (!Array.isArray(json.decks)) json.decks = [];

    var seen = {};
    json.decks.forEach(function (d, di) {
      if (!d.id || seen[d.id]) d.id = 'deck-' + uid();
      seen[d.id] = true;
      if (!d.name)  d.name = '未命名领域';
      if (!d.color) d.color = PALETTE[di % PALETTE.length];
      if (d.parentId === undefined || d.parentId === '') d.parentId = null;
      if (!Array.isArray(d.cards)) d.cards = [];

      d.cards.forEach(function (c) {
        if (!c.id) c.id = d.id + '-' + uid();
        if (!Array.isArray(c.tags))  c.tags = [];
        if (!Array.isArray(c.links)) c.links = [];
        c.front   = c.front   == null ? '' : String(c.front);
        c.back    = c.back    == null ? '' : String(c.back);
        c.formula = c.formula == null ? '' : String(c.formula);
        c.hint    = c.hint    == null ? '' : String(c.hint);
      });
    });

    var idSet = {};
    json.decks.forEach(function (d) { idSet[d.id] = true; });
    json.decks.forEach(function (d) {
      if (d.parentId && (!idSet[d.parentId] || d.parentId === d.id)) d.parentId = null;
    });
    return json;
  }

  /* ==========================================================
   *  写入钩子
   * ========================================================== */
  function touch(msg, opts) {
    opts = opts || {};
    state.data.meta = state.data.meta || {};
    state.data.meta.updatedAt = new Date().toISOString();

    try {
      localStorage.setItem(STORE_DATA, JSON.stringify(state.data));
      setSaveState(fs.connected ? '已同步到文件' : '已同步到浏览器', false);
    } catch (e) {
      setSaveState('本地存储失败', true);
    }

    if (fs.connected && fs.dir) {
      if (opts.deletedTopId) {
        deleteTopDeckFile(opts.deletedTopId).then(function () {
          setSaveState('已从文件删除 ✓', false);
        });
      } else if (Array.isArray(opts.deckIds) && opts.deckIds.length) {
        var tops = {};
        opts.deckIds.forEach(function (id) {
          var topId = getTopAncestorId(id);
          if (topId) tops[topId] = true;
        });
        var topIds = Object.keys(tops);
        Promise.all(topIds.map(function (id) { return saveTopDeckFile(id); }))
          .then(function () { setSaveState('已同步到文件 ✓', false); });
      } else {
        var deckId = opts.deckId || state.deckId;
        if (deckId) saveFor(deckId);
      }
    }

    if (msg) toast(msg);
  }

  function setSaveState(text, dirty) {
    var el = $('#saveState');
    if (!el) return;
    el.textContent = text;
    el.classList.toggle('dirty', !!dirty);
  }

  /* ==========================================================
   *  领域辅助
   * ========================================================== */
  function getDeck(id) {
    if (!id) return null;
    for (var i = 0; i < state.data.decks.length; i++) {
      if (state.data.decks[i].id === id) return state.data.decks[i];
    }
    return null;
  }
  function currentDeck() { return state.deckId ? getDeck(state.deckId) : null; }

  function getChildren(deckId) {
    return state.data.decks.filter(function (d) {
      return (d.parentId || null) === deckId;
    });
  }

  function getDescendantIds(deckId) {
    var set = new Set([deckId]);
    var queue = [deckId];
    var guard = 0;
    while (queue.length && guard++ < 5000) {
      var id = queue.shift();
      state.data.decks.forEach(function (d) {
        if (d.parentId === id && !set.has(d.id)) { set.add(d.id); queue.push(d.id); }
      });
    }
    return set;
  }

  function getPath(deckId) {
    var parts = [];
    var cur = getDeck(deckId);
    var guard = 0;
    while (cur && guard++ < 50) {
      parts.unshift(cur.name);
      cur = cur.parentId ? getDeck(cur.parentId) : null;
    }
    return parts.join(' / ');
  }

  /**
   * 计算领域深度：顶层（无 parentId）= 0
   */
  function getDeckLevel(deckId) {
    var cur = getDeck(deckId);
    if (!cur) return -1;
    var level = 0;
    var guard = 0;
    while (cur.parentId && guard++ < 200) {
      cur = getDeck(cur.parentId);
      if (!cur) break;
      level++;
    }
    return level;
  }

  /**
   * 找到 deckId 的第 targetLevel 级祖先（含自身）
   * 若自身深度小于 targetLevel，返回 null
   */
  function getAncestorAtLevel(deckId, targetLevel) {
    var cur = getDeck(deckId);
    if (!cur) return null;
    var level = getDeckLevel(deckId);
    if (level < targetLevel) return null;
    var guard = 0;
    while (cur && level > targetLevel && guard++ < 200) {
      if (!cur.parentId) return null;
      cur = getDeck(cur.parentId);
      if (!cur) return null;
      level--;
    }
    return cur;
  }

  /**
   * ★ 关键修复：计算每个领域的卡片计数（含全部子领域）
   *
   * 返回 { [deckId]: { own, total, decks } }
   *   own   —— 该领域【直接】挂载的卡片数
   *   total —— 该领域【含全部后代】的卡片总数
   *   decks —— 该领域【含自身】的领域数量
   *
   * 实现：按深度从深到浅排序，逐层向上累加，保证子领域先于父领域处理。
   */
  function computeDeckCounts() {
    var map = {};
    var withDepth = [];

    state.data.decks.forEach(function (d) {
      var n = (d.cards || []).length;
      map[d.id] = { own: n, total: n, decks: 1 };
      withDepth.push({ d: d, lv: getDeckLevel(d.id) });
    });

    // 深度降序：叶子先处理
    withDepth.sort(function (a, b) { return b.lv - a.lv; });

    withDepth.forEach(function (item) {
      var d = item.d;
      if (!d.parentId) return;
      var p = map[d.parentId];
      var c = map[d.id];
      if (!p || !c) return;
      p.total += c.total;
      p.decks += c.decks;
    });

    return map;
  }

  /* ==========================================================
   *  领域 CRUD
   * ========================================================== */
  function newDeck(parentId) {
    parentId = parentId || null;
    var color;
    if (parentId) {
      var p = getDeck(parentId);
      color = p ? p.color : PALETTE[state.data.decks.length % PALETTE.length];
    } else {
      color = PALETTE[state.data.decks.length % PALETTE.length];
    }
    var d = {
      id: 'deck-' + uid(),
      name: parentId ? '新子领域' : ('新领域 ' + (state.data.decks.length + 1)),
      color: color, description: '', parentId: parentId, cards: []
    };
    state.data.decks.push(d);
    state.deckId = d.id;
    state.cardId = null;
    if (parentId) delete state.collapsed[parentId];

    touch(parentId ? '子领域已创建' : '顶层领域已创建', { deckId: d.id });
    renderAll();

    setTimeout(function () {
      var el = $('.deck-item.active .name');
      if (el) startRename(el, d);
    }, 60);
  }

  function deleteDeck(deckId) {
    var d = getDeck(deckId);
    if (!d) return;

    var ids = getDescendantIds(deckId);
    var subCount = ids.size - 1;
    var cardCount = 0;
    state.data.decks.forEach(function (dk) {
      if (ids.has(dk.id)) cardCount += dk.cards.length;
    });

    var msg = '确定删除「' + d.name + '」？\n';
    if (subCount > 0) msg += '包含 ' + subCount + ' 个子领域。\n';
    msg += '共 ' + cardCount + ' 张卡片会被一并删除。';
    if (!confirm(msg)) return;

    var removedCardIds = new Set();
    state.data.decks.forEach(function (dk) {
      if (!ids.has(dk.id)) return;
      dk.cards.forEach(function (c) { removedCardIds.add(c.id); });
    });

    var isTop = !d.parentId;
    var topId = getTopAncestorId(deckId);

    state.data.decks = state.data.decks.filter(function (dk) { return !ids.has(dk.id); });

    state.data.decks.forEach(function (dk) {
      dk.cards.forEach(function (c) {
        c.links = (c.links || []).filter(function (id) { return !removedCardIds.has(id); });
      });
    });

    if (ids.has(state.deckId)) {
      state.deckId = state.data.decks[0] ? state.data.decks[0].id : null;
      state.cardId = null;
    }

    if (isTop) touch('顶层领域已删除', { deletedTopId: deckId });
    else touch('领域已删除', { deckId: topId });
    renderAll();
  }

  function startRename(el, deck) {
    el.contentEditable = 'true';
    el.focus();
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    var finished = false;
    function finish(save) {
      if (finished) return;
      finished = true;
      el.contentEditable = 'false';
      var newName = (el.textContent || '').trim();
      if (save && newName && newName !== deck.name) {
        deck.name = newName;
        touch('名称已更新', { deckId: deck.id });
      } else el.textContent = deck.name;
      renderAll();
    }

    el.addEventListener('blur', function () { finish(true); }, { once: true });
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); el.blur(); }
      if (e.key === 'Escape') { e.preventDefault(); el.textContent = deck.name; el.blur(); }
    });
  }

  function renameDeck(deck) {
    var item = $('.deck-item[data-deck="' + deck.id + '"]');
    if (!item) return;
    var nameEl = item.querySelector('.name');
    if (nameEl) startRename(nameEl, deck);
  }

  function changeDeckColor(deck) {
    var html = '<h2>选择领域颜色</h2>' +
      '<p class="hint">当前：<code>' + esc(getPath(deck.id)) + '</code></p>' +
      '<div class="color-grid">' +
      PALETTE.map(function (c) {
        return '<button type="button" class="color-swatch' +
          (c === deck.color ? ' active' : '') +
          '" data-c="' + c + '" style="background:' + c + '"></button>';
      }).join('') + '</div>';
    openModal(html);
    var handler = function (e) {
      var sw = e.target.closest('.color-swatch');
      if (!sw) return;
      deck.color = sw.dataset.c;
      touch('颜色已更新', { deckId: deck.id });
      closeModal();
      renderAll();
    };
    $('#modalBox').addEventListener('click', handler, { once: true });
  }

  function moveDeck(deckId, newParentId) {
    var deck = getDeck(deckId);
    if (!deck) return;
    newParentId = newParentId || null;

    if (newParentId === deckId) { toast('不能移动到自身下'); return; }
    if (newParentId) {
      if (!getDeck(newParentId)) { toast('目标领域不存在'); return; }
      var ids = getDescendantIds(deckId);
      if (ids.has(newParentId)) { toast('不能移动到自己或子领域下'); return; }
    }
    if ((deck.parentId || null) === newParentId) { toast('已经是该父领域'); return; }

    var oldTopId = getTopAncestorId(deckId);
    deck.parentId = newParentId;
    if (newParentId) delete state.collapsed[newParentId];
    var newTopId = getTopAncestorId(deckId);

    if (oldTopId !== newTopId && fs.connected) {
      state.data.meta.updatedAt = new Date().toISOString();
      mirrorToLocal();
      deleteTopDeckFile(oldTopId).then(function () {
        return saveTopDeckFile(newTopId);
      }).then(function () { setSaveState('已移动并同步 ✓', false); });
      toast('已更改父领域');
      renderAll();
      return;
    }

    touch('已更改父领域', { deckId: newTopId });
    renderAll();
  }

  function moveUpDown(deckId, direction) {
    var deck = getDeck(deckId);
    if (!deck) return;
    var siblings = state.data.decks.filter(function (d) {
      return (d.parentId || null) === (deck.parentId || null);
    });
    var idx = siblings.indexOf(deck);
    var target = idx + direction;
    if (target < 0 || target >= siblings.length) return;
    var a = siblings[idx], b = siblings[target];
    var ia = state.data.decks.indexOf(a);
    var ib = state.data.decks.indexOf(b);
    state.data.decks[ia] = b;
    state.data.decks[ib] = a;
    touch(null, { deckId: deck.id });
    renderAll();
  }

  function toggleFold(deckId) {
    if (state.collapsed[deckId]) delete state.collapsed[deckId];
    else state.collapsed[deckId] = true;
    renderDecks();
  }

  function expandAll() { state.collapsed = {}; renderDecks(); }
  function collapseAll() {
    state.collapsed = {};
    state.data.decks.forEach(function (d) {
      if (getChildren(d.id).length) state.collapsed[d.id] = true;
    });
    renderDecks();
  }

  /* ==========================================================
   *  领域菜单
   * ========================================================== */
  function showDeckMenu(deckId, anchorEl) {
    var menu = $('#deckMenu');
    var deck = getDeck(deckId);
    if (!deck) return;

    var siblings = state.data.decks.filter(function (d) {
      return (d.parentId || null) === (deck.parentId || null);
    });
    var idx = siblings.indexOf(deck);
    var canUp = idx > 0;
    var canDown = idx < siblings.length - 1;

    menu.innerHTML =
      '<button data-act="rename">✎ 重命名</button>' +
      '<button data-act="add-sub">＋ 新建子领域</button>' +
      '<button data-act="color">◐ 修改颜色</button>' +
      '<button data-act="move">↗ 更改父领域</button>' +
      '<div class="sep"></div>' +
      '<button data-act="up"' + (canUp ? '' : ' disabled') + '>↑ 上移</button>' +
      '<button data-act="down"' + (canDown ? '' : ' disabled') + '>↓ 下移</button>' +
      '<div class="sep"></div>' +
      '<button data-act="delete" class="danger">✕ 删除领域</button>';

    menu.hidden = false;

    var rect = anchorEl.getBoundingClientRect();
    var mw = menu.offsetWidth;
    var mh = menu.offsetHeight;
    var left = rect.right - mw;
    left = Math.max(8, Math.min(left, window.innerWidth - mw - 8));
    var top = rect.bottom + 4;
    if (top + mh > window.innerHeight - 8) top = rect.top - mh - 4;
    if (top < 8) top = 8;
    menu.style.left = left + 'px';
    menu.style.top  = top  + 'px';

    menu.onclick = function (e) {
      var btn = e.target.closest('button[data-act]');
      if (!btn || btn.disabled) return;
      var act = btn.dataset.act;
      hideDeckMenu();
      if (act === 'rename') renameDeck(deck);
      else if (act === 'add-sub') newDeck(deck.id);
      else if (act === 'color') changeDeckColor(deck);
      else if (act === 'move') showMoveModal(deck);
      else if (act === 'up') moveUpDown(deck.id, -1);
      else if (act === 'down') moveUpDown(deck.id, 1);
      else if (act === 'delete') deleteDeck(deck.id);
    };
  }
  function hideDeckMenu() {
    var m = $('#deckMenu');
    if (m) m.hidden = true;
  }

  function showMoveModal(deck) {
    var exclude = getDescendantIds(deck.id);
    var options = [{ id: '', name: '（顶层）', depth: -1, isTop: true }];

    function walk(parentId, depth) {
      state.data.decks.forEach(function (d) {
        if ((d.parentId || null) !== parentId) return;
        if (exclude.has(d.id)) return;
        options.push({ id: d.id, name: d.name, depth: depth });
        walk(d.id, depth + 1);
      });
    }
    walk(null, 0);

    var curParent = deck.parentId || '';
    var html = '<h2>更改父领域</h2>' +
      '<p class="hint">当前：<code>' + esc(getPath(deck.id)) + '</code></p>' +
      '<div class="move-tree">' +
      options.map(function (o) {
        var ind = Math.max(0, o.depth) * 16;
        var active = curParent === o.id;
        var icon = o.isTop ? '🏠 ' : (o.depth > 0 ? '↳ ' : '📁 ');
        return '<button type="button" class="move-opt' + (active ? ' active' : '') +
          '" data-parent="' + esc(o.id) + '" style="padding-left:' + (10 + ind) + 'px">' +
          icon + esc(o.name) +
          (active ? ' <span class="tag-mini">当前</span>' : '') +
        '</button>';
      }).join('') + '</div>' +
      '<div class="modal-actions"><button class="btn" id="mvCancel">取消</button></div>';

    openModal(html);
    $('#mvCancel').onclick = closeModal;
    $('#modalBox').addEventListener('click', function (e) {
      var btn = e.target.closest('.move-opt');
      if (!btn) return;
      moveDeck(deck.id, btn.dataset.parent || null);
      closeModal();
    });
  }

  /* ==========================================================
   *  卡片
   * ========================================================== */
  function findCard(id) {
    for (var i = 0; i < state.data.decks.length; i++) {
      var d = state.data.decks[i];
      for (var j = 0; j < d.cards.length; j++) {
        if (d.cards[j].id === id) return d.cards[j];
      }
    }
    return null;
  }
  function cardOwnerDeck(cardId) {
    for (var i = 0; i < state.data.decks.length; i++) {
      var d = state.data.decks[i];
      for (var j = 0; j < d.cards.length; j++) {
        if (d.cards[j].id === cardId) return d;
      }
    }
    return null;
  }
  function currentCard() { return state.cardId ? findCard(state.cardId) : null; }

  function deleteCard() {
    var card = currentCard();
    if (!card) return;
    var deck = cardOwnerDeck(card.id);
    if (!deck) return;
    if (!confirm('确定删除这张卡片？')) return;

    deck.cards = deck.cards.filter(function (c) { return c.id !== card.id; });
    state.data.decks.forEach(function (dk) {
      dk.cards.forEach(function (c) {
        c.links = (c.links || []).filter(function (id) { return id !== card.id; });
      });
    });

    state.cardId = null;
    touch('卡片已删除', { deckId: deck.id });
    renderAll();
  }

  function moveCardToDeck(cardId, targetDeckId) {
    var card = findCard(cardId);
    if (!card) { toast('卡片不存在'); return; }

    var srcDeck = cardOwnerDeck(cardId);
    var dstDeck = getDeck(targetDeckId);
    if (!srcDeck || !dstDeck) { toast('目标领域不存在'); return; }
    if (srcDeck.id === dstDeck.id) { toast('已是该领域'); return; }

    var srcTopId = getTopAncestorId(srcDeck.id);
    var dstTopId = getTopAncestorId(dstDeck.id);

    srcDeck.cards = srcDeck.cards.filter(function (c) { return c.id !== cardId; });
    dstDeck.cards.push(card);

    state.deckId = dstDeck.id;
    state.cardId = card.id;

    var cur = dstDeck;
    var guard = 0;
    while (cur && cur.parentId && guard++ < 100) {
      delete state.collapsed[cur.parentId];
      cur = getDeck(cur.parentId);
    }

    if (srcTopId && dstTopId && srcTopId !== dstTopId) {
      touch('卡片已移动到「' + dstDeck.name + '」', { deckIds: [srcTopId, dstTopId] });
    } else {
      touch('卡片已移动到「' + dstDeck.name + '」', {
        deckId: dstTopId || srcTopId || dstDeck.id
      });
    }
    renderAll();
  }

  function showCardMoveModal(card) {
    if (!card) return;
    var srcDeck = cardOwnerDeck(card.id);
    if (!srcDeck) return;

    var options = [];
    function walk(parentId, depth) {
      state.data.decks.forEach(function (d) {
        if ((d.parentId || null) !== parentId) return;
        options.push({ id: d.id, name: d.name, depth: depth, color: d.color });
        walk(d.id, depth + 1);
      });
    }
    walk(null, 0);
    if (!options.length) { toast('还没有领域'); return; }

    var html = '<h2>移动卡片到</h2>' +
      '<p class="hint">当前：<code>' + esc(getPath(srcDeck.id)) + '</code><br/>' +
      '卡片正面：<code>' + esc(truncate(card.front || '（空）', 30)) + '</code></p>' +
      '<div class="move-tree">' +
      options.map(function (o) {
        var ind = Math.max(0, o.depth) * 16;
        var isCurrent = o.id === srcDeck.id;
        return '<button type="button" class="move-opt' + (isCurrent ? ' active' : '') +
          '" data-target="' + esc(o.id) + '"' + (isCurrent ? ' disabled' : '') +
          ' style="padding-left:' + (10 + ind) + 'px">' +
          '<span class="move-dot" style="--c:' + esc(o.color) + '"></span>' +
          '<span>' + esc(o.name) + '</span>' +
          (isCurrent ? ' <span class="tag-mini">当前</span>' : '') +
        '</button>';
      }).join('') + '</div>' +
      '<div class="modal-actions">' +
        '<button type="button" class="btn" id="cmCancel">取消</button>' +
      '</div>';

    openModal(html);
    var cancel = $('#cmCancel');
    if (cancel) cancel.onclick = closeModal;

    function onClick(e) {
      var btn = e.target.closest('.move-opt');
      if (!btn || btn.disabled) return;
      var targetId = btn.dataset.target;
      if (!targetId) return;
      $('#modalBox').removeEventListener('click', onClick);
      closeModal();
      moveCardToDeck(card.id, targetId);
    }
    $('#modalBox').addEventListener('click', onClick);

    var modalEl = $('#modal');
    var onClose = function () {
      $('#modalBox').removeEventListener('click', onClick);
      modalEl.removeEventListener('click', onClose);
    };
    modalEl.addEventListener('click', onClose);
  }

  /* ==========================================================
   *  关联卡片选择器：多分组完整列表
   *
   *  分组规则（按优先级）：
   *    ① 标签匹配          —— 与当前卡片有共同标签（跨所有领域）
   *    ② 同第三分级        —— 与当前卡片属同一 L3 领域
   *    ③ 第三分级下各分级  —— L3 祖先下的 L4、L5、L6... 各为一组
   *    ④ 其他层级          —— 兜底
   *
   *  不展示「同第二分级」等中间层级的分组。
   *  每组完整展示，不截断。
   * ========================================================== */

  function computeLinkGroups(card) {
    var owner = cardOwnerDeck(card.id);
    var used = new Set(card.links || []);
    used.add(card.id);

    var cardTags = new Set((card.tags || []).filter(Boolean));

    // 找到当前卡片所在领域的第三分级祖先
    var l3Ancestor = null;
    if (owner) {
      l3Ancestor = getAncestorAtLevel(owner.id, TARGET_LEVEL);
    }

    // 收集所有候选
    var tagItems   = [];
    var l3Items    = [];   // L3 领域本身的卡片
    var belowMap   = {};   // key: level（相对 L3 的绝对深度）, value: items[]
    var otherItems = [];

    state.data.decks.forEach(function (d) {
      (d.cards || []).forEach(function (c) {
        if (used.has(c.id)) return;

        var hitTags = [];
        (c.tags || []).forEach(function (t) {
          if (t && cardTags.has(t)) hitTags.push(t);
        });

        var item = { card: c, deck: d, hitTags: hitTags };

        // ① 标签匹配（优先级最高，独立成组）
        if (hitTags.length > 0) {
          tagItems.push(item);
          return;
        }

        // 没有 L3 祖先，全部进「其他」
        if (!l3Ancestor) {
          otherItems.push(item);
          return;
        }

        // 判断候选卡片所属领域与 L3 祖先的关系
        var dL3 = getAncestorAtLevel(d.id, TARGET_LEVEL);
        if (!dL3 || dL3.id !== l3Ancestor.id) {
          otherItems.push(item);
          return;
        }

        var dLevel = getDeckLevel(d.id);

        if (dLevel === TARGET_LEVEL) {
          // ② 同第三分级
          l3Items.push(item);
        } else if (dLevel > TARGET_LEVEL) {
          // ③ 第三分级下的各分级
          if (!belowMap[dLevel]) belowMap[dLevel] = [];
          belowMap[dLevel].push(item);
        } else {
          // 低于 L3（理论上不该发生，因为 l3Ancestor 已限定），归入其他
          otherItems.push(item);
        }
      });
    });

    // 组装分组数组
    var groups = [];

    if (tagItems.length) {
      tagItems.sort(function (a, b) {
        if (b.hitTags.length !== a.hitTags.length) return b.hitTags.length - a.hitTags.length;
        return (a.card.front || '').localeCompare(b.card.front || '');
      });
      groups.push({
        cls: 'tag',
        title: '标签匹配',
        items: tagItems
      });
    }

    if (l3Ancestor && l3Items.length) {
      l3Items.sort(function (a, b) {
        return (a.card.front || '').localeCompare(b.card.front || '');
      });
      groups.push({
        cls: 'l3',
        title: '同第三分级 · ' + l3Ancestor.name,
        items: l3Items
      });
    }

    // 第三分级下的各分级：按绝对深度从小到大（L4 → L5 → L6 ...）
    var belowLevels = Object.keys(belowMap).map(Number).sort(function (a, b) { return a - b; });
    belowLevels.forEach(function (lv) {
      var items = belowMap[lv];
      items.sort(function (a, b) {
        return (a.card.front || '').localeCompare(b.card.front || '');
      });
      // 该层具体是第几分级（第三分级之后）
      var nth = lv - TARGET_LEVEL + 3;  // L4 → 第四分级
      var nthCn = ['零','一','二','三','四','五','六','七','八','九','十'][nth] || nth;
      groups.push({
        cls: 'below',
        title: '第三分级下 · 第' + nthCn + '分级',
        items: items
      });
    });

    if (otherItems.length) {
      otherItems.sort(function (a, b) {
        return (a.card.front || '').localeCompare(b.card.front || '');
      });
      groups.push({
        cls: 'other',
        title: '其他层级',
        items: otherItems
      });
    }

    // 搜索过滤
    var q = (state._linkSearch || '').trim().toLowerCase();
    if (q) {
      groups = groups.map(function (g) {
        var filtered = g.items.filter(function (it) {
          var c = it.card;
          var hay = ((c.front || '') + ' ' + (c.back || '') + ' ' +
                     (c.tags || []).join(' ') + ' ' + (it.deck.name || '')).toLowerCase();
          return hay.indexOf(q) >= 0;
        });
        return { cls: g.cls, title: g.title, items: filtered };
      }).filter(function (g) { return g.items.length > 0; });
    }

    return groups;
  }

  function renderLinkPicker(card) {
    var listEl = $('#edLinkList');
    if (!listEl || !card) return;

    var groups = computeLinkGroups(card);

    if (!groups.length) {
      listEl.innerHTML = '<div class="lp-empty">' +
        (state._linkSearch ? '没有匹配的卡片' : '没有可关联的卡片') +
      '</div>';
      return;
    }

    var html = groups.map(function (g) {
      var itemsHtml = g.items.map(renderLinkOption).join('');
      return '<div class="lp-section">' +
        '<div class="lp-section-head">' +
          '<span class="lp-dot ' + g.cls + '"></span>' +
          '<span class="lp-section-title">' + esc(g.title) + '</span>' +
          '<span class="lp-section-num">' + g.items.length + '</span>' +
        '</div>' +
        '<div class="lp-section-list">' + itemsHtml + '</div>' +
      '</div>';
    }).join('');

    listEl.innerHTML = html;

    // 直接绑定每一项的点击处理器（避免事件委托在重渲染后失效）
    var items = listEl.querySelectorAll('.lp-item');
    for (var i = 0; i < items.length; i++) {
      (function (item) {
        item.addEventListener('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          var id = item.dataset.linkId;
          if (!id) return;
          if (addLinkFromPicker(id)) toast('已添加关联');
        });
      })(items[i]);
    }
  }

  function renderLinkOption(it) {
    var c = it.card;
    var tagsHtml = '';
    if (it.hitTags && it.hitTags.length) {
      tagsHtml = it.hitTags.slice(0, 3).map(function (t) {
        return '<span class="lp-tag-hit">' + esc(t) + '</span>';
      }).join('');
    } else if ((c.tags || []).length) {
      tagsHtml = (c.tags || []).slice(0, 3).map(function (t) {
        return '<span class="lp-tag">' + esc(t) + '</span>';
      }).join('');
    }

    var deckPath = getPath(it.deck.id);

    return '<button type="button" class="lp-item" data-link-id="' + esc(c.id) + '">' +
      '<span class="lp-item-dot" style="--c:' + esc(it.deck.color) + '"></span>' +
      '<span class="lp-item-main">' +
        '<span class="lp-item-front">' + esc(truncate(c.front || '（空正面）', 48)) + '</span>' +
        '<span class="lp-item-meta">' +
          '<span class="lp-item-deck" title="' + esc(deckPath) + '">' +
            esc(truncate(it.deck.name, 16)) +
          '</span>' +
          tagsHtml +
        '</span>' +
      '</span>' +
    '</button>';
  }

  /**
   * 添加一张卡片为关联
   */
  function addLinkFromPicker(linkId) {
    var card = currentCard();
    if (!card) return false;
    if (!linkId) return false;

    card.links = card.links || [];
    if (card.links.indexOf(linkId) >= 0) return false;
    card.links.push(linkId);

    var owner = cardOwnerDeck(card.id);
    touch(null, { deckId: owner ? owner.id : state.deckId });
    renderLinksEditor(card);
    renderLinkPicker(card);
    return true;
  }

  function resetLinkPicker() {
    var panel = $('#edLinkPanel');
    var btn = $('#edLinkBtn');
    var search = $('#edLinkSearch');
    var clear = $('#edLinkClear');
    if (panel) panel.hidden = true;
    if (btn) btn.classList.remove('open');
    if (search) search.value = '';
    if (clear) clear.hidden = true;
    state._linkSearch = '';
    var list = $('#edLinkList');
    if (list) list.innerHTML = '';
  }

  function isLinkPickerOpen() {
    var panel = $('#edLinkPanel');
    return panel && !panel.hidden;
  }

  function closeLinkPicker() {
    var panel = $('#edLinkPanel');
    var btn = $('#edLinkBtn');
    if (panel) panel.hidden = true;
    if (btn) btn.classList.remove('open');
  }

  /* ==========================================================
   *  模式切换
   * ========================================================== */
  function applyModeUI() {
    var mode = state.mode;
    var mainEl = $('#mainEl');
    if (mainEl) mainEl.dataset.mode = mode;

    var sideManage = $('#sideManage');
    var sideLibrary = $('#sideLibrary');
    var cardsManage = $('#cardsManage');
    var cardsLibrary = $('#cardsLibrary');

    if (mode === 'library') {
      if (sideManage) sideManage.hidden = true;
      if (sideLibrary) sideLibrary.hidden = false;
      if (cardsManage) cardsManage.hidden = true;
      if (cardsLibrary) cardsLibrary.hidden = false;
    } else {
      if (sideManage) sideManage.hidden = false;
      if (sideLibrary) sideLibrary.hidden = true;
      if (cardsManage) cardsManage.hidden = false;
      if (cardsLibrary) cardsLibrary.hidden = true;
    }

    $$('.mode-btn').forEach(function (b) {
      b.classList.toggle('active', b.dataset.mode === mode);
    });
  }

  function switchMode(mode) {
    if (state.mode === mode) return;
    state.mode = mode;
    applyModeUI();
    if (mode === 'library') {
      renderLibFilter();
      renderLibGrid();
      renderEditor();
    } else {
      renderAll();
    }
  }

  /* ==========================================================
   *  总库：筛选 + 网格
   * ========================================================== */
  function collectLibTags() {
    var f = state.libFilters;
    var base = [];

    state.data.decks.forEach(function (d) {
      (d.cards || []).forEach(function (c) { base.push({ c: c, d: d }); });
    });

    if (f.decks.size > 0) {
      var allowed = new Set();
      f.decks.forEach(function (did) {
        var ids = getDescendantIds(did);
        ids.forEach(function (id) { allowed.add(id); });
      });
      base = base.filter(function (it) { return allowed.has(it.d.id); });
    }

    var q = f.search.trim().toLowerCase();
    if (q) {
      base = base.filter(function (it) {
        var c = it.c;
        var hay = (c.front + ' ' + c.back + ' ' + (c.formula || '') + ' ' +
                   (c.tags || []).join(' ') + ' ' + (c.hint || '')).toLowerCase();
        return hay.indexOf(q) >= 0;
      });
    }

    if (f.states.size > 0) {
      base = base.filter(function (it) { return matchLibStates(it.c, f.states); });
    }

    var counts = {};
    base.forEach(function (it) {
      (it.c.tags || []).forEach(function (t) {
        if (!t) return;
        counts[t] = (counts[t] || 0) + 1;
      });
    });

    return Object.keys(counts).map(function (t) {
      return { tag: t, count: counts[t] };
    }).sort(function (a, b) {
      if (b.count !== a.count) return b.count - a.count;
      return a.tag.localeCompare(b.tag);
    });
  }

  function matchLibStates(c, stateSet) {
    if (stateSet.has('has-formula') && !(c.formula && c.formula.trim())) return false;
    if (stateSet.has('has-links') && !(c.links && c.links.length)) return false;
    if (stateSet.has('orphan') && (c.links && c.links.length)) return false;
    if (stateSet.has('no-tags') && (c.tags && c.tags.length)) return false;
    return true;
  }

  function filterLibCards() {
    var f = state.libFilters;
    var items = [];

    state.data.decks.forEach(function (d) {
      (d.cards || []).forEach(function (c) { items.push({ c: c, d: d }); });
    });

    if (f.decks.size > 0) {
      var allowed = new Set();
      f.decks.forEach(function (did) {
        var ids = getDescendantIds(did);
        ids.forEach(function (id) { allowed.add(id); });
      });
      items = items.filter(function (it) { return allowed.has(it.d.id); });
    }

    if (f.tags.size > 0) {
      items = items.filter(function (it) {
        return (it.c.tags || []).some(function (t) { return f.tags.has(t); });
      });
    }

    if (f.states.size > 0) {
      items = items.filter(function (it) { return matchLibStates(it.c, f.states); });
    }

    var q = f.search.trim().toLowerCase();
    if (q) {
      items = items.filter(function (it) {
        var c = it.c;
        var hay = (c.front + ' ' + c.back + ' ' + (c.formula || '') + ' ' +
                   (c.tags || []).join(' ') + ' ' + (c.hint || '')).toLowerCase();
        return hay.indexOf(q) >= 0;
      });
    }

    return items;
  }

  function renderLibDeckFilter() {
    var el = $('#libDeckFilter');
    if (!el) return;
    var tops = state.data.decks.filter(function (d) { return !d.parentId; });
    if (!tops.length) { el.innerHTML = ''; return; }

    var counts = computeDeckCounts();

    var html = '';
    tops.forEach(function (d) {
      var c = counts[d.id] || { own: 0, total: 0, decks: 1 };
      if (!c.total) return;
      var on = state.libFilters.decks.has(d.id) ? ' on' : '';
      var title = c.own === c.total
        ? c.total + ' 张卡片'
        : '含子领域共 ' + c.total + ' 张 · 本领域直接 ' + c.own + ' 张';
      html += '<button type="button" class="lib-deck-item' + on + '" data-deck="' + esc(d.id) + '" title="' + esc(title) + '">' +
        '<span class="lib-deck-dot" style="--c:' + esc(d.color) + '"></span>' +
        '<span class="lib-deck-name">' + esc(d.name) + '</span>' +
        '<span class="lib-deck-count">' + c.total + '</span>' +
      '</button>';
    });
    el.innerHTML = html;
  }

  function renderLibTagFilter() {
    var el = $('#libTagFilter');
    if (!el) return;
    var tags = collectLibTags();
    var f = state.libFilters;

    var existing = new Set(tags.map(function (t) { return t.tag; }));
    var orphan = [];
    f.tags.forEach(function (t) {
      if (!existing.has(t)) orphan.push({ tag: t, count: 0 });
    });
    tags = orphan.concat(tags);

    if (!tags.length) { el.innerHTML = ''; return; }

    el.innerHTML = tags.map(function (t) {
      var on = f.tags.has(t.tag) ? ' on' : '';
      return '<button type="button" class="lib-tag-chip' + on + '" data-tag="' + esc(t.tag) + '">' +
        esc(t.tag) +
        (t.count > 0 ? '<span class="lib-tag-num">' + t.count + '</span>' : '') +
      '</button>';
    }).join('');
  }

  function renderLibStates() {
    var el = $('#libStateFilter');
    if (!el) return;
    $$('.lib-state-chip', el).forEach(function (b) {
      b.classList.toggle('on', state.libFilters.states.has(b.dataset.state));
    });
  }

  function renderLibGrid() {
    var el = $('#libGrid');
    var emptyEl = $('#libEmpty');
    var countEl = $('#libCount');

    var items = filterLibCards();
    if (countEl) countEl.textContent = items.length;

    if (!items.length) {
      el.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;

    el.innerHTML = items.map(function (it) {
      var c = it.c, d = it.d;
      var active = c.id === state.cardId ? ' active' : '';
      var marks = '';
      if (c.formula && c.formula.trim()) marks += '<span class="lib-mark formula">∑</span>';
      var linkCount = (c.links || []).length;
      if (linkCount) marks += '<span class="lib-mark links">↔' + linkCount + '</span>';

      var tags = (c.tags || []).slice(0, 4).map(function (t) {
        return '<span class="ptag">' + esc(t) + '</span>';
      }).join('');

      return '<button type="button" class="lib-card' + active + '" data-card="' + esc(c.id) + '">' +
        '<div class="lib-card-top">' +
          '<span class="lib-card-deck" style="--c:' + esc(d.color) + '">' +
            esc(truncate(d.name, 18)) +
          '</span>' +
          '<div class="lib-card-marks">' + marks + '</div>' +
        '</div>' +
        '<div class="lib-card-front">' + esc(truncate(c.front || '（空正面）', 60)) + '</div>' +
        '<div class="lib-card-back">' + esc(truncate(c.back || '（无背面）', 60)) + '</div>' +
        (tags ? '<div class="lib-card-tags">' + tags + '</div>' : '') +
      '</button>';
    }).join('');
  }

  function renderLibFilter() {
    renderLibDeckFilter();
    renderLibTagFilter();
    renderLibStates();
  }

  /* ==========================================================
   *  渲染
   * ========================================================== */
  function renderAll() {
    if (state.mode === 'library') {
      renderLibFilter();
      renderLibGrid();
      renderEditor();
    } else {
      renderDecks();
      renderCardsList();
      renderEditor();
    }
  }

  function renderDecks() {
    var list = $('#deckList');
    if (!list) return;
    var decks = state.data.decks;
    $('#deckCount').textContent = decks.length;
    $('#deckEmpty').hidden = decks.length > 0;

    // ★ 聚合计数：含所有子领域
    var counts = computeDeckCounts();

    var html = '';
    function walk(parentId, depth) {
      state.data.decks.forEach(function (d) {
        if ((d.parentId || null) !== parentId) return;
        html += renderDeckNode(d, depth, counts);
        if (!state.collapsed[d.id]) walk(d.id, depth + 1);
      });
    }
    walk(null, 0);
    list.innerHTML = html;
  }

  function renderDeckNode(d, depth, counts) {
    var active = d.id === state.deckId ? ' active' : '';
    var hasChildren = getChildren(d.id).length > 0;
    var collapsed = !!state.collapsed[d.id];
    var foldChar = collapsed ? '▶' : '▼';
    var foldHidden = hasChildren ? '' : ' hidden';

    var c = (counts && counts[d.id]) || {
      own: (d.cards || []).length,
      total: (d.cards || []).length,
      decks: 1
    };

    // 数字样式：总数为 0 / 有子领域聚合 / 仅本级
    var numCls = 'num';
    var numTitle;
    if (c.total === 0) {
      numCls += ' zero';
      numTitle = '暂无卡片';
    } else if (c.own !== c.total) {
      numCls += ' agg';
      numTitle = '含子领域共 ' + c.total + ' 张 · 本领域直接 ' + c.own + ' 张';
    } else {
      numTitle = c.total + ' 张卡片';
    }

    return '<div class="deck-item' + active + '" data-deck="' + esc(d.id) + '" ' +
      'style="--depth:' + depth + '" title="' + esc(getPath(d.id)) + '">' +
      '<button type="button" class="fold' + foldHidden + '" data-fold="' + esc(d.id) + '">' + foldChar + '</button>' +
      '<span class="dot" style="--c:' + esc(d.color) + '" data-color="' + esc(d.id) + '" title="修改颜色"></span>' +
      '<span class="name">' + esc(d.name) + '</span>' +
      '<span class="' + numCls + '" title="' + esc(numTitle) + '">' + c.total + '</span>' +
      '<span class="ops">' +
        '<button type="button" class="op" data-add-sub="' + esc(d.id) + '" title="新建子领域">＋</button>' +
        '<button type="button" class="op" data-more="' + esc(d.id) + '" title="更多操作">⋯</button>' +
      '</span>' +
    '</div>';
  }

  function renderCardsList() {
    var list = $('#cardList');
    if (!list) return;
    var deck = currentDeck();
    var counts = computeDeckCounts();

    if (deck) {
      var full = getPath(deck.id);
      $('#cardsTitle').textContent = truncate(full, 26);
      $('#cardsTitle').title = full;
    } else {
      $('#cardsTitle').textContent = '卡片';
      $('#cardsTitle').title = '';
    }

    var subBtn = $('#btnToggleSub');
    if (subBtn) {
      subBtn.classList.toggle('on', state.includeSubDecks);
      subBtn.title = state.includeSubDecks
        ? '当前：含子领域（点击切换为仅当前领域）'
        : '当前：仅当前领域（点击切换为含子领域）';
    }

    if (!deck) {
      list.innerHTML = '';
      $('#cardCount').textContent = 0;
      $('#cardsEmpty').hidden = false;
      $('#cardsEmpty').innerHTML = '选择左侧领域后<br/>点击右上角「＋」新建卡片';
      return;
    }

    var ids = state.includeSubDecks ? getDescendantIds(deck.id) : new Set([deck.id]);
    var items = [];
    state.data.decks.forEach(function (d) {
      if (!ids.has(d.id)) return;
      d.cards.forEach(function (c) { items.push({ c: c, d: d }); });
    });

    $('#cardCount').textContent = items.length;

    if (!items.length) {
      list.innerHTML = '';
      $('#cardsEmpty').hidden = false;

      var agg = counts[deck.id] || { own: 0, total: 0 };
      var subOnly = Math.max(0, agg.total - agg.own);

      if (!state.includeSubDecks && subOnly > 0) {
        // ★ 关键修复：本领域无卡片但子领域有 → 智能引导
        $('#cardsEmpty').innerHTML =
          '当前领域没有卡片<br/>' +
          '子领域中共有 <b>' + subOnly + '</b> 张<br/>' +
          '<button type="button" class="empty-btn" id="btnEmptyIncludeSub">包含子领域</button>';
        var b = $('#btnEmptyIncludeSub');
        if (b) {
          b.onclick = function () {
            state.includeSubDecks = true;
            renderCardsList();
            toast('已包含所有子领域');
          };
        }
      } else if (state.includeSubDecks) {
        $('#cardsEmpty').innerHTML = '当前领域及其子领域下<br/>还没有卡片';
      } else {
        $('#cardsEmpty').innerHTML = '还没有卡片<br/>点击右上角「＋」新建一张';
      }
      return;
    }
    $('#cardsEmpty').hidden = true;

    var html = '';
    items.forEach(function (item) {
      var c = item.c, d = item.d;
      var active = c.id === state.cardId ? ' active' : '';
      var tags = (c.tags || []).slice(0, 3).map(function (t) {
        return '<span>' + esc(t) + '</span>';
      }).join('');
      var linkCount = (c.links || []).length;
      if (linkCount) tags += '<span>↔ ' + linkCount + '</span>';
      if (c.formula && c.formula.trim()) tags += '<span>∑ 公式</span>';

      var deckMark = '';
      if (state.includeSubDecks && d.id !== deck.id) {
        deckMark = '<span class="deck-mark" style="--c:' + esc(d.color) + '">' +
          esc(truncate(d.name, 12)) + '</span>';
      }

      html += '<button type="button" class="card-item' + active +
        '" data-card="' + esc(c.id) + '">' +
        '<div class="ct">' + esc(truncate(c.front || '（空正面）', 40)) + '</div>' +
        '<div class="cm">' + deckMark + tags + '</div>' +
      '</button>';
    });
    list.innerHTML = html;
  }

  function renderEditor() {
    var card = currentCard();
    var editorEmpty = $('#editorEmpty');
    var editorEl = $('#editor');
    if (editorEmpty) editorEmpty.hidden = !!card;
    if (editorEl) editorEl.hidden = !card;
    if (!card) return;

    var owner = cardOwnerDeck(card.id);
    var path = owner ? getPath(owner.id) : '';
    $('#edTitle').textContent = path ? '编辑 · ' + truncate(path, 30) : '编辑卡片';
    $('#edTitle').title = path;

    $('#edFront').value   = card.front || '';
    $('#edBack').value    = card.back  || '';
    $('#edFormula').value = card.formula || '';
    $('#edTags').value    = (card.tags || []).join(', ');
    $('#edHint').value    = card.hint  || '';

    renderLinksEditor(card);
    resetLinkPicker();
    renderLinkPicker(card);
    renderPreview(card);
  }

  function renderLinksEditor(card) {
    var box = $('#edLinks');
    if (!box) return;
    var links = card.links || [];
    if (!links.length) { box.innerHTML = ''; return; }
    box.innerHTML = links.map(function (id) {
      var target = findCard(id);
      var label = target ? truncate(target.front || '（空）', 24) : '（已失效）';
      return '<span class="link-chip">' +
        '<span>' + esc(label) + '</span>' +
        '<i data-remove-link="' + esc(id) + '" title="移除">×</i>' +
      '</span>';
    }).join('');
  }

  function renderPreview(card) {
    var q = card.front || '（未填写正面）';
    var a = card.back  || '（未填写背面）';
    var f = renderFormula(card.formula);

    var html = '<div class="pv-q">' + fmt(q) + '</div>';
    if (f) html += '<div class="fmula">' + f + '</div>';
    html += '<div>' + fmt(a) + '</div>';
    $('#edPreview').innerHTML = html;
  }

  /* ==========================================================
   *  弹窗
   * ========================================================== */
  function openModal(html, wide) {
    var box = $('#modalBox');
    box.innerHTML = html;
    box.classList.toggle('wide', !!wide);
    $('#modal').hidden = false;
  }
  function closeModal() {
    $('#modal').hidden = true;
    $('#modalBox').classList.remove('wide');
  }

  /* ==========================================================
   *  文本结构解析
   * ========================================================== */
  var FIELD_ALIAS = {
    '正面': 'front', '问题': 'front', 'q': 'front',
    '背面': 'back',  '答案': 'back',  'a': 'back',
    '标签': 'tags',  'tag': 'tags',   'tags': 'tags',
    '提示': 'hint',  'hint': 'hint',
    '公式': 'formula', 'formula': 'formula', 'latex': 'formula', 'tex': 'formula',
    '关联': 'links', 'links': 'links'
  };

  function parseCardText(text) {
    var lines = String(text || '').split(/\r?\n/);
    var cards = [];
    var cur = null;
    var field = null;

    function ensure() {
      if (!cur) cur = { front:'', back:'', formula:'', tags:[], hint:'', links:[] };
      return cur;
    }
    function push() {
      if (cur && (cur.front.trim() || cur.back.trim())) cards.push(cur);
      cur = null; field = null;
    }

    var reBracket = /^[【\[]\s*([^】\]]+?)\s*[】\]]\s*(.*)$/;
    var reColon = /^(Q|A|正面|背面|问题|答案|标签|提示|公式|关联|tags?|hint|formula|latex|tex|links?)\s*[:：]\s*(.*)$/i;

    lines.forEach(function (raw) {
      var line = raw.replace(/\s+$/, '');
      if (/^\s*---+\s*$/.test(line)) { push(); return; }

      var m = line.match(reBracket) || line.match(reColon);
      if (m) {
        var rawKey = String(m[1]);
        var key = rawKey.toLowerCase();
        var val = m[2] || '';
        var f = FIELD_ALIAS[rawKey] || FIELD_ALIAS[key];
        if (!f) {
          if (cur && field) cur[field] += (cur[field] ? '\n' : '') + line;
          return;
        }
        if (f === 'front') {
          if (cur && (cur.front.trim() || cur.back.trim())) push();
          ensure();
          cur.front = val;
          field = 'front';
          return;
        }
        ensure();
        if (f === 'tags') {
          cur.tags = val.split(/[,，、;；]/).map(function (t) { return t.trim(); }).filter(Boolean);
          field = null;
        } else if (f === 'links') {
          cur.links = val.split(/[,，、;；]/).map(function (t) { return t.trim(); }).filter(Boolean);
          field = null;
        } else {
          cur[f] = val;
          field = f;
        }
        return;
      }

      if (!cur) {
        if (line.trim()) { ensure(); cur.front = line; field = 'front'; }
        return;
      }
      if (field) cur[field] += (cur[field] ? '\n' : '') + line;
      else if (line.trim()) { cur.back += (cur.back ? '\n' : '') + line; field = 'back'; }
    });
    push();

    cards.forEach(function (c) {
      c.front   = (c.front   || '').trim();
      c.back    = (c.back    || '').trim();
      c.formula = (c.formula || '').trim();
      c.hint    = (c.hint    || '').trim();
      c.tags    = c.tags  || [];
      c.links   = c.links || [];
    });

    return cards.filter(function (c) { return c.front || c.back; });
  }

  /* ============================================================
   *  文本转换弹窗
   * ============================================================ */
  var TT_SAMPLE =
    '【正面】什么是过拟合？\n' +
    '【背面】训练误差低，验证误差高。\n本质是方差高，模型把噪声也学进去了。\n' +
    '【标签】泛化, 过拟合\n' +
    '【提示】训练好、验证差\n' +
    '\n' +
    '【正面】写出偏差-方差分解。\n' +
    '【背面】泛化误差可以分解为三部分：偏差、方差与噪声。\n' +
    '【公式】E[(y - \\hat{f}(x))^2] = \\text{Bias}^2 + \\text{Var} + \\sigma^2\n' +
    '【标签】推导, 偏差方差\n' +
    '【提示】从 y = f(x) + ε 出发\n';

  function showTextImportModal() {
    var deck = currentDeck();
    if (!deck) { toast('请先创建或选择一个领域'); return; }
    var deckPath = getPath(deck.id);

    openModal(
      '<h2>文本转换 · 自动生成卡片</h2>' +
      '<p class="hint">目标领域：<code>' + esc(deckPath) + '</code></p>' +
      '<p class="hint">只有 <code>【正面】</code> 是必填项，其余可省略。</p>' +
      '<div class="fmt-box">' +
        '<div class="fmt-row"><b>【正面】</b><span>问题 / 概念名（必填，出现即开一张新卡）</span></div>' +
        '<div class="fmt-row"><b>【背面】</b><span>答案 / 解释，支持多行、`代码`、**加粗**</span></div>' +
        '<div class="fmt-row"><b>【公式】</b><span>LaTeX 数学公式（可选，KaTeX 渲染）</span></div>' +
        '<div class="fmt-row"><b>【标签】</b><span>逗号分隔</span></div>' +
        '<div class="fmt-row"><b>【提示】</b><span>思考方向</span></div>' +
        '<div class="fmt-row"><b>---</b><span>卡片分隔符</span></div>' +
      '</div>' +
      '<label class="field">' +
        '<span class="field-label">粘贴内容</span>' +
        '<textarea id="ttText" rows="12"></textarea>' +
      '</label>' +
      '<div class="tt-tools">' +
        '<button type="button" class="mini-btn" id="ttSample">示例</button>' +
        '<button type="button" class="mini-btn" id="ttClear">清空</button>' +
        '<button type="button" class="btn" id="ttPreviewBtn">解析预览</button>' +
      '</div>' +
      '<div class="tt-preview" id="ttPreviewBox"></div>' +
      '<div class="modal-actions">' +
        '<button class="btn" id="ttCancel">取消</button>' +
        '<button class="btn btn-primary" id="ttOk" disabled>添加到「' + esc(truncate(deck.name, 20)) + '」</button>' +
      '</div>',
      true
    );

    var parsed = [];

    function renderTTPreview() {
      var box = $('#ttPreviewBox');
      var okBtn = $('#ttOk');
      if (!parsed.length) {
        box.innerHTML = '';
        okBtn.disabled = true;
        okBtn.textContent = '添加到「' + truncate(deck.name, 20) + '」';
        return;
      }
      okBtn.disabled = false;
      okBtn.textContent = '添加 ' + parsed.length + ' 张到「' + truncate(deck.name, 20) + '」';

      box.innerHTML = '<div class="tt-count">解析到 <b>' + parsed.length + '</b> 张卡片</div>' +
        parsed.map(function (c) {
          var tags = c.tags.slice(0, 4).map(function (t) {
            return '<span>' + esc(t) + '</span>';
          }).join('');
          var f = c.formula ? renderFormula(c.formula) : '';
          return '<div class="tt-item">' +
            '<div class="tt-q">' + esc(truncate(c.front || '（无正面）', 60)) + '</div>' +
            '<div class="tt-a">' + esc(truncate(c.back || '（无背面）', 90)) + '</div>' +
            (f ? '<div class="fmula">' + f + '</div>' : '') +
            (tags ? '<div class="tt-t">' + tags + '</div>' : '') +
          '</div>';
        }).join('');
    }

    $('#ttSample').onclick = function () {
      $('#ttText').value = TT_SAMPLE;
      parsed = parseCardText(TT_SAMPLE);
      renderTTPreview();
    };
    $('#ttClear').onclick = function () {
      $('#ttText').value = '';
      parsed = [];
      renderTTPreview();
    };
    $('#ttPreviewBtn').onclick = function () {
      parsed = parseCardText($('#ttText').value);
      if (!parsed.length) toast('没有解析出有效卡片');
      renderTTPreview();
    };
    $('#ttCancel').onclick = closeModal;

    $('#ttOk').onclick = function () {
      if (!parsed.length) { toast('请先解析预览'); return; }

      var byFront = new Map();
      state.data.decks.forEach(function (d) {
        d.cards.forEach(function (c) {
          var key = (c.front || '').trim();
          if (key && !byFront.has(key)) byFront.set(key, c.id);
        });
      });

      parsed.forEach(function (c) {
        var links = (c.links || []).map(function (kw) {
          kw = String(kw).trim();
          if (!kw) return null;
          if (byFront.has(kw)) return byFront.get(kw);
          var hit = null;
          byFront.forEach(function (id, front) {
            if (!hit && front && (front.indexOf(kw) >= 0 || kw.indexOf(front) >= 0)) hit = id;
          });
          return hit;
        }).filter(Boolean);

        deck.cards.push({
          id: deck.id + '-' + uid(),
          front: c.front, back: c.back,
          formula: c.formula || '',
          tags: c.tags,
          links: links, hint: c.hint
        });
      });

      closeModal();
      touch('已添加 ' + parsed.length + ' 张卡片', { deckId: deck.id });
      renderAll();
    };
  }

  /* ============================================================
   *  新建卡片弹窗
   * ============================================================ */
  function openNewCardModal(preferredDeckId) {
    var deck = preferredDeckId ? getDeck(preferredDeckId) : currentDeck();
    if (!deck) { toast('请先创建或选择一个领域'); return; }
    var deckPath = getPath(deck.id);

    openModal(
      '<h2>新建卡片</h2>' +
      '<p class="hint">归属领域：<code>' + esc(deckPath) + '</code></p>' +
      '<div class="nc-wrap">' +
        '<div class="nc-form">' +
          '<label class="nc-region">' +
            '<span class="nc-label">正面 · 问题 <b>*</b></span>' +
            '<textarea id="ncFront" rows="3"></textarea>' +
          '</label>' +
          '<label class="nc-region">' +
            '<span class="nc-label">背面 · 答案</span>' +
            '<textarea id="ncBack" rows="5"></textarea>' +
          '</label>' +
          '<label class="nc-region">' +
            '<span class="nc-label">数学公式 · LaTeX（可选）</span>' +
            '<textarea id="ncFormula" rows="2" placeholder="E = mc^2"></textarea>' +
          '</label>' +
          '<div class="nc-row">' +
            '<label class="nc-region"><span class="nc-label">标签</span><input id="ncTags" /></label>' +
            '<label class="nc-region"><span class="nc-label">提示</span><input id="ncHint" /></label>' +
          '</div>' +
        '</div>' +
        '<div class="nc-preview">' +
          '<div class="nc-preview-label">实时预览</div>' +
          '<div class="nc-card">' +
            '<div class="nc-card-tags" id="ncPvTags"></div>' +
            '<div class="nc-card-front empty" id="ncPvFront">（正面）</div>' +
            '<div class="nc-card-hint" id="ncPvHint"></div>' +
            '<div class="nc-card-sep"></div>' +
            '<div class="nc-card-back empty" id="ncPvBack">（背面）</div>' +
            '<div class="nc-card-formula" id="ncPvFormula" hidden></div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="modal-actions">' +
        '<button class="btn" id="ncCancel">取消</button>' +
        '<button class="btn" id="ncSaveMore">保存并继续</button>' +
        '<button class="btn btn-primary" id="ncSave">保存</button>' +
      '</div>',
      true
    );

    var $front = $('#ncFront'), $back = $('#ncBack');
    var $formula = $('#ncFormula');
    var $tags = $('#ncTags'), $hint = $('#ncHint');

    function readForm() {
      return {
        front: $front.value.trim(),
        back:  $back.value.trim(),
        formula: $formula.value.trim(),
        tags:  $tags.value.split(/[,，、]/).map(function (t) { return t.trim(); }).filter(Boolean),
        hint:  $hint.value.trim()
      };
    }

    function updatePreview() {
      var c = readForm();
      var pvFront = $('#ncPvFront');
      if (c.front) { pvFront.innerHTML = fmt(c.front); pvFront.classList.remove('empty'); }
      else { pvFront.textContent = '（正面）'; pvFront.classList.add('empty'); }

      var pvBack = $('#ncPvBack');
      if (c.back) { pvBack.innerHTML = fmt(c.back); pvBack.classList.remove('empty'); }
      else { pvBack.textContent = '（背面）'; pvBack.classList.add('empty'); }

      $('#ncPvTags').innerHTML = c.tags.map(function (t) {
        return '<span class="ptag">' + esc(t) + '</span>';
      }).join('');
      $('#ncPvHint').innerHTML = c.hint ? '💡 ' + esc(c.hint) : '';

      var pvFormula = $('#ncPvFormula');
      var f = renderFormula(c.formula);
      pvFormula.innerHTML = f;
      pvFormula.hidden = !f;

      $('#ncSave').disabled = !c.front;
      $('#ncSaveMore').disabled = !c.front;
    }

    ['input', 'change'].forEach(function (ev) {
      $front.addEventListener(ev, updatePreview);
      $back.addEventListener(ev, updatePreview);
      $formula.addEventListener(ev, updatePreview);
      $tags.addEventListener(ev, updatePreview);
      $hint.addEventListener(ev, updatePreview);
    });

    function resetForm() {
      $front.value = ''; $back.value = ''; $formula.value = '';
      $tags.value = ''; $hint.value = '';
      updatePreview(); $front.focus();
    }

    function commit() {
      var c = readForm();
      if (!c.front) { toast('正面不能为空'); return null; }
      var card = {
        id: deck.id + '-' + uid(),
        front: c.front, back: c.back,
        formula: c.formula, tags: c.tags,
        links: [], hint: c.hint
      };
      deck.cards.push(card);
      touch(null, { deckId: deck.id });
      renderAll();
      return card;
    }

    $('#ncCancel').onclick = closeModal;
    $('#ncSave').onclick = function () {
      var card = commit();
      if (!card) return;
      state.cardId = card.id;
      closeModal();
      renderAll();
      toast('卡片已创建');
    };
    $('#ncSaveMore').onclick = function () {
      var card = commit();
      if (!card) return;
      state.cardId = card.id;
      toast('已添加，继续下一张');
      resetForm();
    };

    updatePreview();
    setTimeout(function () { $front.focus(); }, 60);
  }

  /* ==========================================================
   *  导出 / 导入
   * ========================================================== */
  function exportJSON() {
    if (!fs.connected || !fs.dir) {
      if (!fs.supported) {
        var text = JSON.stringify(state.data, null, 2);
        download(text, 'kstar-backup.json');
        toast('浏览器不支持目录写入，已下载备份文件');
        return;
      }

      if (!confirm('尚未连接数据文件夹。\n\n是否选择一个文件夹来导出数据？\n（选择后会自动连接）')) {
        var t2 = JSON.stringify(state.data, null, 2);
        download(t2, 'kstar-backup.json');
        toast('已下载备份文件（未连接文件夹）');
        return;
      }

      DataStore.pickDirectory()
        .then(function (h) {
          return DataStore.verifyPermission(h, true).then(function (ok) {
            if (!ok) throw new Error('未授权读写');
            return DataStore.saveHandle(h).then(function () { return h; });
          });
        })
        .then(function (h) {
          fs.dir = h; fs.name = h.name; fs.connected = true;
          updateFSState();
          return doExportToDir();
        })
        .then(function () { renderAll(); })
        .catch(function (e) {
          if (e && e.name === 'AbortError') return;
          toast('导出失败：' + (e.message || e));
        });
      return;
    }
    doExportToDir();
  }

  function doExportToDir() {
    if (!fs.connected || !fs.dir) return Promise.resolve();
    var tops = state.data.decks.filter(function (d) { return !d.parentId; });
    if (!tops.length) { toast('没有可导出的领域'); return Promise.resolve(); }

    setSaveState('正在导出…', false);
    return Promise.all(tops.map(function (d) { return saveTopDeckFile(d.id); }))
      .then(function () {
        return DataStore.writeJSON(fs.dir, '_snapshot.json', {
          version: '4.6', kind: 'snapshot',
          exportedAt: new Date().toISOString(),
          meta: state.data.meta,
          decks: state.data.decks
        });
      })
      .then(function () {
        setSaveState('已导出 ' + tops.length + ' 个领域 ✓', false);
        toast('已导出 ' + tops.length + ' 个领域到「' + fs.name + '」');
      })
      .catch(function (err) {
        console.error('[export]', err);
        setSaveState('导出失败', true);
        toast('导出失败：' + (err.message || err));
      });
  }

  function importJSON(file) {
    var reader = new FileReader();
    reader.onload = function (ev) {
      try {
        var j = JSON.parse(ev.target.result);
        if (!j || !Array.isArray(j.decks)) throw new Error('缺少 decks 数组');

        state.data = normalize(j);
        state.deckId = state.data.decks[0] ? state.data.decks[0].id : null;
        state.cardId = null;
        state.collapsed = {};
        state.libFilters.decks.clear();
        state.libFilters.tags.clear();
        state.libFilters.states.clear();
        state.libFilters.search = '';

        touch('导入成功', { deckId: state.deckId });

        if (fs.connected && fs.dir) {
          var newTops = state.data.decks.filter(function (d) { return !d.parentId; });
          DataStore.getSubdir(fs.dir, DECKS_DIR, true)
            .then(function (decksDir) {
              return DataStore.listJSONFiles(decksDir).then(function (files) {
                return Promise.all(files.map(function (name) {
                  return DataStore.deleteEntry(decksDir, name);
                }));
              });
            })
            .then(function () {
              return Promise.all(newTops.map(function (d) { return saveTopDeckFile(d.id); }));
            })
            .then(function () { setSaveState('已覆盖写入文件 ✓', false); })
            .catch(function (e) {
              console.error('[import]', e);
              setSaveState('写入失败', true);
            });
        }

        var si = $('#libSearch');
        if (si) si.value = '';
        var sc = $('#btnLibClearSearch');
        if (sc) sc.hidden = true;

        renderAll();
      } catch (err) {
        toast('导入失败：' + err.message);
      }
    };
    reader.readAsText(file);
  }

  function clearAll() {
    if (!confirm('确定清空所有领域和卡片吗？此操作不可撤销。')) return;
    if (!confirm('再次确认：真的要清空全部数据吗？')) return;

    var oldTops = state.data.decks.filter(function (d) { return !d.parentId; }).map(function (d) { return d.id; });

    state.data = JSON.parse(JSON.stringify(EMPTY_DATA));
    state.deckId = null;
    state.cardId = null;
    state.collapsed = {};
    state.libFilters.decks.clear();
    state.libFilters.tags.clear();
    state.libFilters.states.clear();
    state.libFilters.search = '';

    try { localStorage.removeItem(STORE_DATA); } catch (e) {}

    if (fs.connected && fs.dir) {
      Promise.all(oldTops.map(function (id) { return deleteTopDeckFile(id); }))
        .then(function () { setSaveState('已清空文件 ✓', false); });
    }

    var si = $('#libSearch');
    if (si) si.value = '';
    var sc = $('#btnLibClearSearch');
    if (sc) sc.hidden = true;

    toast('已清空全部数据');
    renderAll();
  }

  /* ==========================================================
   *  事件绑定
   * ========================================================== */
  function bindUI() {

    /* ---- 模式切换 ---- */
    var modeSwitch = $('#modeSwitch');
    if (modeSwitch) {
      modeSwitch.addEventListener('click', function (e) {
        var btn = e.target.closest('.mode-btn');
        if (!btn) return;
        switchMode(btn.dataset.mode);
      });
    }

    /* ---- 数据目录 ---- */
    var btnConnect = $('#btnConnect');
    if (btnConnect) {
      btnConnect.onclick = function () {
        if (fs.connected) {
          if (confirm('已连接「' + fs.name + '」。\n\n确定要断开吗？')) disconnectDir();
          else chooseDir();
        } else chooseDir();
      };
    }

    /* ---- 顶栏按钮 ---- */
    var btnNewDeck = $('#btnNewDeck');
    if (btnNewDeck) btnNewDeck.onclick = function () { newDeck(null); };
    var btnTextImport = $('#btnTextImport');
    if (btnTextImport) btnTextImport.onclick = showTextImportModal;
    var btnClearAll = $('#btnClearAll');
    if (btnClearAll) btnClearAll.onclick = clearAll;
    var btnExport = $('#btnExport');
    if (btnExport) btnExport.onclick = exportJSON;

    var btnImport = $('#btnImport');
    if (btnImport) btnImport.onclick = function () { $('#fileInput').click(); };
    var fileInput = $('#fileInput');
    if (fileInput) {
      fileInput.onchange = function (e) {
        var f = e.target.files && e.target.files[0];
        if (f) importJSON(f);
        e.target.value = '';
      };
    }

    var btnExpandAll = $('#btnExpandAll');
    if (btnExpandAll) btnExpandAll.onclick = expandAll;
    var btnCollapseAll = $('#btnCollapseAll');
    if (btnCollapseAll) btnCollapseAll.onclick = collapseAll;

    /* ---- 领域树 ---- */
    var deckList = $('#deckList');
    if (deckList) {
      deckList.addEventListener('click', function (e) {
        var foldBtn = e.target.closest('[data-fold]');
        if (foldBtn) { e.stopPropagation(); toggleFold(foldBtn.dataset.fold); return; }

        var colorDot = e.target.closest('[data-color]');
        if (colorDot) {
          e.stopPropagation();
          var d1 = getDeck(colorDot.dataset.color);
          if (d1) changeDeckColor(d1);
          return;
        }
        var addSubBtn = e.target.closest('[data-add-sub]');
        if (addSubBtn) { e.stopPropagation(); newDeck(addSubBtn.dataset.addSub); return; }

        var moreBtn = e.target.closest('[data-more]');
        if (moreBtn) { e.stopPropagation(); showDeckMenu(moreBtn.dataset.more, moreBtn); return; }

        var item = e.target.closest('.deck-item');
        if (!item) return;
        if (item.dataset.deck === state.deckId) return;
        state.deckId = item.dataset.deck;
        state.cardId = null;
        renderAll();
      });

      deckList.addEventListener('dblclick', function (e) {
        var nameEl = e.target.closest('.name');
        if (!nameEl) return;
        var item = nameEl.closest('.deck-item');
        var deck = getDeck(item.dataset.deck);
        if (deck) startRename(nameEl, deck);
      });
    }

    /* ---- 卡片列表 ---- */
    var btnNewCard = $('#btnNewCard');
    if (btnNewCard) btnNewCard.onclick = function () { openNewCardModal(); };
    var btnToggleSub = $('#btnToggleSub');
    if (btnToggleSub) {
      btnToggleSub.onclick = function () {
        if (!currentDeck()) { toast('请先选择一个领域'); return; }
        state.includeSubDecks = !state.includeSubDecks;
        renderCardsList();
        toast(state.includeSubDecks ? '现在包含所有子领域' : '现在仅显示当前领域');
      };
    }

    var cardList = $('#cardList');
    if (cardList) {
      cardList.addEventListener('click', function (e) {
        var item = e.target.closest('.card-item');
        if (!item) return;
        if (item.dataset.card === state.cardId) return;
        state.cardId = item.dataset.card;
        renderCardsList();
        renderEditor();
      });
    }

    /* ---- 总库：搜索 ---- */
    var libSearch = $('#libSearch');
    if (libSearch) {
      libSearch.addEventListener('input', function () {
        state.libFilters.search = this.value || '';
        var clr = $('#btnLibClearSearch');
        if (clr) clr.hidden = !state.libFilters.search;
        renderLibTagFilter();
        renderLibGrid();
      });
      libSearch.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          this.value = '';
          state.libFilters.search = '';
          var clr = $('#btnLibClearSearch');
          if (clr) clr.hidden = true;
          renderLibTagFilter();
          renderLibGrid();
          this.blur();
        }
      });
    }
    var btnLibClearSearch = $('#btnLibClearSearch');
    if (btnLibClearSearch) {
      btnLibClearSearch.onclick = function () {
        var inp = $('#libSearch');
        if (inp) inp.value = '';
        state.libFilters.search = '';
        this.hidden = true;
        renderLibTagFilter();
        renderLibGrid();
        if (inp) inp.focus();
      };
    }

    /* ---- 总库：领域筛选 ---- */
    var libDeckFilter = $('#libDeckFilter');
    if (libDeckFilter) {
      libDeckFilter.addEventListener('click', function (e) {
        var btn = e.target.closest('.lib-deck-item');
        if (!btn) return;
        var id = btn.dataset.deck;
        if (!id) return;
        if (state.libFilters.decks.has(id)) state.libFilters.decks.delete(id);
        else state.libFilters.decks.add(id);
        renderLibDeckFilter();
        renderLibTagFilter();
        renderLibGrid();
      });
    }

    /* ---- 总库：标签筛选 ---- */
    var libTagFilter = $('#libTagFilter');
    if (libTagFilter) {
      libTagFilter.addEventListener('click', function (e) {
        var btn = e.target.closest('.lib-tag-chip');
        if (!btn) return;
        var tag = btn.dataset.tag;
        if (!tag) return;
        if (state.libFilters.tags.has(tag)) state.libFilters.tags.delete(tag);
        else state.libFilters.tags.add(tag);
        renderLibTagFilter();
        renderLibGrid();
      });
    }

    /* ---- 总库：状态筛选 ---- */
    var libStateFilter = $('#libStateFilter');
    if (libStateFilter) {
      libStateFilter.addEventListener('click', function (e) {
        var btn = e.target.closest('.lib-state-chip');
        if (!btn) return;
        var s = btn.dataset.state;
        if (!s) return;
        if (state.libFilters.states.has(s)) state.libFilters.states.delete(s);
        else state.libFilters.states.add(s);
        renderLibStates();
        renderLibTagFilter();
        renderLibGrid();
      });
    }

    /* ---- 总库：清空全部 ---- */
    var btnLibClearAll = $('#btnLibClearAll');
    if (btnLibClearAll) {
      btnLibClearAll.onclick = function () {
        var f = state.libFilters;
        f.search = ''; f.decks.clear(); f.tags.clear(); f.states.clear();
        var inp = $('#libSearch');
        if (inp) inp.value = '';
        var clr = $('#btnLibClearSearch');
        if (clr) clr.hidden = true;
        renderLibFilter();
        renderLibGrid();
      };
    }

    /* ---- 总库：点击卡片编辑 ---- */
    var libGrid = $('#libGrid');
    if (libGrid) {
      libGrid.addEventListener('click', function (e) {
        var card = e.target.closest('.lib-card');
        if (!card) return;
        var id = card.dataset.card;
        if (!id) return;
        state.cardId = id;
        renderLibGrid();
        renderEditor();
      });
    }

    /* ---- 总库：新建卡片 ---- */
    var btnLibNewCard = $('#btnLibNewCard');
    if (btnLibNewCard) {
      btnLibNewCard.onclick = function () {
        var tops = state.data.decks.filter(function (d) { return !d.parentId; });
        if (!tops.length) { toast('请先在卡片管理里创建领域'); return; }
        var target = state.deckId || tops[0].id;
        openNewCardModal(target);
      };
    }

    /* ---- 编辑器 ---- */
    function syncCard() { return currentCard(); }

    function onEdit(updater) {
      var c = syncCard();
      if (!c) return;
      updater(c);
      var owner = cardOwnerDeck(c.id);
      touch(null, { deckId: owner ? owner.id : state.deckId });
      if (state.mode === 'library') {
        renderLibGrid();
      } else {
        renderCardsList();
      }
      renderPreview(c);
    }

    var edFront = $('#edFront');
    if (edFront) edFront.addEventListener('input', function () {
      var v = this.value; onEdit(function (c) { c.front = v; });
    });
    var edBack = $('#edBack');
    if (edBack) edBack.addEventListener('input', function () {
      var v = this.value; onEdit(function (c) { c.back = v; });
    });
    var edFormula = $('#edFormula');
    if (edFormula) edFormula.addEventListener('input', function () {
      var v = this.value; onEdit(function (c) { c.formula = v; });
    });
    var edTags = $('#edTags');
    if (edTags) edTags.addEventListener('input', function () {
      var v = this.value;
      onEdit(function (c) {
        c.tags = v.split(/[,，、]/).map(function (t) { return t.trim(); }).filter(Boolean);
      });
      if (state.mode === 'library') renderLibTagFilter();
      var c = syncCard();
      if (c) renderLinkPicker(c);
    });
    var edHint = $('#edHint');
    if (edHint) edHint.addEventListener('input', function () {
      var v = this.value; onEdit(function (c) { c.hint = v; });
    });

    /* ---- 关联卡片：移除已有 ---- */
    var edLinks = $('#edLinks');
    if (edLinks) {
      edLinks.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-remove-link]');
        if (!btn) return;
        e.stopPropagation();
        var c = syncCard();
        if (!c) return;
        var id = btn.dataset.removeLink;
        c.links = (c.links || []).filter(function (x) { return x !== id; });
        var owner = cardOwnerDeck(c.id);
        touch(null, { deckId: owner ? owner.id : state.deckId });
        renderLinksEditor(c);
        renderLinkPicker(c);
      });
    }

    /* ---- 关联卡片：开关按钮 ---- */
    var edLinkBtn = $('#edLinkBtn');
    if (edLinkBtn) {
      edLinkBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var panel = $('#edLinkPanel');
        var card = currentCard();
        if (!card || !panel) return;

        if (panel.hidden) {
          renderLinkPicker(card);
          panel.hidden = false;
          edLinkBtn.classList.add('open');
          var inp = $('#edLinkSearch');
          if (inp) setTimeout(function () { inp.focus(); }, 50);
        } else {
          panel.hidden = true;
          edLinkBtn.classList.remove('open');
        }
      });
    }

    /* ---- 关联卡片：搜索 ---- */
    var edLinkSearch = $('#edLinkSearch');
    if (edLinkSearch) {
      edLinkSearch.addEventListener('input', function () {
        var card = currentCard();
        if (!card) return;
        var clr = $('#edLinkClear');
        if (clr) clr.hidden = !this.value;
        state._linkSearch = this.value || '';
        renderLinkPicker(card);
      });
      edLinkSearch.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          this.value = '';
          state._linkSearch = '';
          var clr = $('#edLinkClear');
          if (clr) clr.hidden = true;
          var card = currentCard();
          if (card) renderLinkPicker(card);
          this.blur();
        }
      });
    }

    var edLinkClear = $('#edLinkClear');
    if (edLinkClear) {
      edLinkClear.addEventListener('click', function (e) {
        e.stopPropagation();
        var inp = $('#edLinkSearch');
        if (inp) inp.value = '';
        state._linkSearch = '';
        this.hidden = true;
        var card = currentCard();
        if (card) renderLinkPicker(card);
        if (inp) inp.focus();
      });
    }

    var edDelete = $('#edDelete');
    if (edDelete) edDelete.onclick = deleteCard;

    var edMove = $('#edMove');
    if (edMove) {
      edMove.onclick = function () {
        var card = currentCard();
        if (!card) { toast('请先选择卡片'); return; }
        showCardMoveModal(card);
      };
    }

    /* ---- 弹窗遮罩 ---- */
    var modal = $('#modal');
    if (modal) {
      modal.addEventListener('click', function (e) {
        if (e.target.id === 'modal') closeModal();
      });
    }

    /* ---- document 级关闭逻辑 ---- */
    document.addEventListener('click', function (e) {
      // 关闭领域菜单
      var menu = $('#deckMenu');
      if (menu && !menu.hidden) {
        if (!e.target.closest('#deckMenu') && !e.target.closest('[data-more]')) {
          hideDeckMenu();
        }
      }
      // 关闭关联选择器（仅在开启状态下）
      if (isLinkPickerOpen()) {
        if (!e.target.closest('#edLinkPicker')) {
          closeLinkPicker();
        }
      }
    });
    window.addEventListener('resize', hideDeckMenu);
    window.addEventListener('scroll', hideDeckMenu, true);

    /* ---- 快捷键 ---- */
    document.addEventListener('keydown', function (e) {
      var tag = (e.target.tagName || '').toUpperCase();
      if (tag === 'INPUT' || tag === 'TEXTAREA') {
        if (e.key === 'Escape') e.target.blur();
        return;
      }
      if (e.key === 'Escape') {
        if (!$('#deckMenu').hidden) { hideDeckMenu(); return; }
        if (!$('#modal').hidden) { closeModal(); return; }
        if (isLinkPickerOpen()) { closeLinkPicker(); return; }
      }
    });

    /* ---- 拖拽导入 ---- */
    document.addEventListener('dragover', function (e) { e.preventDefault(); });
    document.addEventListener('drop', function (e) {
      e.preventDefault();
      var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (f) importJSON(f);
    });
  }

  /* ==========================================================
   *  启动
   * ========================================================== */
  function boot() {
    fs.supported = DataStore.isSupported();
    updateFSState();

    var local = null;
    try {
      var raw = localStorage.getItem(STORE_DATA);
      if (raw) {
        var j = JSON.parse(raw);
        if (j && Array.isArray(j.decks)) local = j;
      }
    } catch (e) {}

    state.data = normalize(local || JSON.parse(JSON.stringify(EMPTY_DATA)));
    state.deckId = state.data.decks[0] ? state.data.decks[0].id : null;
    state._linkSearch = '';

    applyModeUI();
    renderAll();
    bindUI();
    setSaveState('就绪', false);

    // ★ 关键修复：先异步探测服务器，再自动连接
    /* =========================================================
     * ★ 关键：等服务器探测完成，再自动连接 data 目录（零点击）
     * ========================================================= */
    DataStore.detectServer().then(function (isServer) {
      if (isServer) {
        // ---------- 服务器模式：直接连接 data ----------
        fs.supported = true;
        fs.connected = true;
        fs.name = 'data';
        fs.dir = { __virtual: true, path: 'data', name: 'data' };
        updateFSState();
        return loadFromDir().then(function () {
          renderAll();
          var n = (state.data && state.data.decks) ? state.data.decks.length : 0;
          toast('✅ 已自动连接 data 目录 · ' + n + ' 个领域');
        });
      }

      // ---------- FS 模式：走原来的恢复流程 ----------
      if (!fs.supported) return;
      return restoreDir().then(function (ok) {
        if (ok) {
          updateFSState();
          renderAll();
          toast('已恢复上次的数据目录：' + fs.name);
        }
      });
    }).catch(function (e) {
      console.error('[boot] 自动连接失败', e);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

})();