/* ============================================================
 *  datastore.js v4 —— 异步服务器探测 + 双通道持久层
 *
 *  关键修复：把同步 XHR 改成异步（Chrome 会静默丢弃加载期间的同步 XHR，
 *  导致 SERVER_MODE 永远为 false）。
 *
 *  设计要点：
 *    · detectServer() 在文件加载时立即异步发起，不阻塞
 *    · getSavedHandle() 内部等待探测结果，服务器模式返回虚拟 data 句柄
 *    · 因此 admin.js 的 restoreDir() 无需修改即可自动连接
 * ============================================================ */
(function (global) {
  'use strict';

  var DB_NAME = 'kstar-fs';
  var DB_VERSION = 1;
  var STORE = 'handles';
  var KEY = 'dataDir';
  var _memHandles = {};

  /* ============================================================
   *  ① 服务器探测（异步，只跑一次，结果缓存）
   * ============================================================ */
  var _serverReady = null;
  var _isServer = false;

  function detectServer() {
    if (_serverReady) return _serverReady;
    _serverReady = new Promise(function (resolve) {
      try {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '/api/ping', true);
        xhr.timeout = 2500;
        xhr.onload = function () {
          if (xhr.status === 200) {
            try {
              var j = JSON.parse(xhr.responseText);
              _isServer = !!(j && j.ok);
            } catch (e) { _isServer = false; }
          }
          resolve(_isServer);
        };
        xhr.onerror   = function () { resolve(false); };
        xhr.ontimeout = function () { resolve(false); };
        xhr.send();
      } catch (e) {
        resolve(false);
      }
    });
    return _serverReady;
  }

  // 页面加载立即开始探测（异步，不阻塞）
  detectServer();

  /* ============================================================
   *  ② 虚拟目录句柄（服务器模式用）
   * ============================================================ */
  function vDir(path) {
    var name = path.split('/').pop() || 'data';
    return { __virtual: true, path: path, name: name };
  }
  function isVirtual(h) { return !!(h && h.__virtual); }

  /* ============================================================
   *  ③ HTTP API
   * ============================================================ */
  function apiJson(method, url, body) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open(method, url, true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
          try { resolve(xhr.responseText ? JSON.parse(xhr.responseText) : {}); }
          catch (e) { resolve({}); }
        } else {
          reject(new Error('HTTP ' + xhr.status));
        }
      };
      xhr.onerror = function () { reject(new Error('Network error')); };
      xhr.send(body != null ? JSON.stringify(body) : null);
    });
  }

  /* ============================================================
   *  ④ IndexedDB 兜底（FS 模式用）
   * ============================================================ */
  function openDB() {
    return new Promise(function (resolve, reject) {
      if (typeof indexedDB === 'undefined') return reject(new Error('no idb'));
      var req;
      try { req = indexedDB.open(DB_NAME, DB_VERSION); }
      catch (e) { return reject(e); }
      req.onupgradeneeded = function () {
        try {
          var db = req.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
        } catch (e) {}
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror   = function () { reject(req.error || new Error('idb open')); };
      req.onblocked = function () { reject(new Error('idb blocked')); };
    });
  }
  function idbGet(key) {
    return openDB().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readonly');
          var req = tx.objectStore(STORE).get(key);
          req.onsuccess = function () { resolve(req.result); };
          req.onerror   = function () { resolve(_memHandles[key]); };
        } catch (e) { resolve(_memHandles[key]); }
      });
    }).catch(function () { return _memHandles[key]; });
  }
  function idbSet(key, value) {
    _memHandles[key] = value;
    return openDB().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          var req = tx.objectStore(STORE).put(value, key);
          req.onsuccess = function () { resolve(); };
          req.onerror   = function () { resolve(); };
        } catch (e) { resolve(); }
      });
    }).catch(function () { return undefined; });
  }
  function idbDel(key) {
    delete _memHandles[key];
    return openDB().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          var req = tx.objectStore(STORE).delete(key);
          req.onsuccess = function () { resolve(); };
          req.onerror   = function () { resolve(); };
        } catch (e) { resolve(); }
      });
    }).catch(function () { return undefined; });
  }

  /* ============================================================
   *  ⑤ File System Access API（FS 模式用）
   * ============================================================ */
  function fsVerify(h, rw) {
    var opts = { mode: rw ? 'readwrite' : 'read' };
    return h.queryPermission(opts).then(function (s) {
      if (s === 'granted') return true;
      return h.requestPermission(opts).then(function (x) { return x === 'granted'; });
    });
  }
  function fsGetSub(parent, name, create) {
    return parent.getDirectoryHandle(name, { create: !!create });
  }
  function fsListJSON(dir) {
    if (!dir || typeof dir.values !== 'function') return Promise.resolve([]);
    var out = [], it = dir.values();
    function step() {
      return it.next().then(function (r) {
        if (r.done) return out;
        if (r.value.kind === 'file' && /\.json$/i.test(r.value.name)) out.push(r.value.name);
        return step();
      });
    }
    return step().catch(function () { return out; });
  }
  function fsReadJSON(dir, name) {
    return dir.getFileHandle(name, { create: false })
      .then(function (fh) { return fh.getFile(); })
      .then(function (f)  { return f.text(); })
      .then(function (t)  {
        if (!t.trim()) return null;
        try { return JSON.parse(t); }
        catch (e) { throw new Error('JSON parse error: ' + name); }
      })
      .catch(function (e) {
        if (e && e.name === 'NotFoundError') return null;
        throw e;
      });
  }
  function fsWriteJSON(dir, name, data) {
    return dir.getFileHandle(name, { create: true })
      .then(function (fh) { return fh.createWritable(); })
      .then(function (w) {
        return w.write(JSON.stringify(data, null, 2)).then(function () { return w.close(); });
      });
  }
  function fsDelete(dir, name) {
    return dir.removeEntry(name).catch(function (e) {
      if (e && e.name === 'NotFoundError') return;
      throw e;
    });
  }

  /* ============================================================
   *  ⑥ 对外统一接口
   * ============================================================ */

  function isSupported() {
    // http(s):// 下均支持（服务器模式或 FS 模式）
    if (typeof location !== 'undefined' &&
        (location.protocol === 'http:' || location.protocol === 'https:')) {
      return true;
    }
    return typeof window.showDirectoryPicker === 'function';
  }

  function pickDirectory() {
    return detectServer().then(function (isServer) {
      if (isServer) return vDir('data');
      return window.showDirectoryPicker({ mode: 'readwrite' });
    });
  }

  function verifyPermission(h, rw) {
    if (isVirtual(h)) return Promise.resolve(true);
    return fsVerify(h, rw);
  }

  /* ★ 关键：getSavedHandle 内部等探测结果 */
  function getSavedHandle() {
    return detectServer().then(function (isServer) {
      if (isServer) return vDir('data');
      return idbGet(KEY);
    });
  }

  function saveHandle(h) {
    if (isVirtual(h)) return Promise.resolve();
    return idbSet(KEY, h);
  }

  function clearSavedHandle() {
    return detectServer().then(function (isServer) {
      if (isServer) return undefined;
      return idbDel(KEY);
    });
  }

  function getSubdir(parent, name, create) {
    if (isVirtual(parent)) return Promise.resolve(vDir(parent.path + '/' + name));
    return fsGetSub(parent, name, create);
  }

  function listJSONFiles(dir) {
    if (isVirtual(dir)) {
      return apiJson('GET', '/api/decks-list')
        .then(function (j) { return (j && j.files) || []; })
        .catch(function () { return []; });
    }
    return fsListJSON(dir);
  }

  function readJSON(dir, name) {
    if (isVirtual(dir)) {
      var id = name.replace(/\.json$/i, '');
      return apiJson('GET', '/api/deck/' + encodeURIComponent(id))
        .catch(function () { return null; });
    }
    return fsReadJSON(dir, name);
  }

  function writeJSON(dir, name, data) {
    if (isVirtual(dir)) {
      if (dir.path === 'data' && name === '_snapshot.json') {
        return apiJson('PUT', '/api/snapshot', data).catch(function () {});
      }
      var id = name.replace(/\.json$/i, '');
      return apiJson('PUT', '/api/deck/' + encodeURIComponent(id), data)
        .catch(function () {});
    }
    return fsWriteJSON(dir, name, data);
  }

  function deleteEntry(dir, name) {
    if (isVirtual(dir)) {
      var id = name.replace(/\.json$/i, '');
      return apiJson('DELETE', '/api/deck/' + encodeURIComponent(id))
        .catch(function () {});
    }
    return fsDelete(dir, name);
  }

  global.DataStore = {
    detectServer: detectServer,
    isServerMode: function () { return _isServer; },   // ← ★ 加这行
    get serverMode() { return _isServer; },
    isSupported: isSupported,
    pickDirectory: pickDirectory,
    verifyPermission: verifyPermission,
    getSavedHandle: getSavedHandle,
    saveHandle: saveHandle,
    clearSavedHandle: clearSavedHandle,
    readJSON: readJSON,
    writeJSON: writeJSON,
    deleteEntry: deleteEntry,
    getSubdir: getSubdir,
    listJSONFiles: listJSONFiles
  };

})(window);