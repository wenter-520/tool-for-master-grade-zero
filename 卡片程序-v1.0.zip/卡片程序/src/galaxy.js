/* ============================================================
 *  galaxy.js —— 三维知识星空可视化引擎 v6.1
 *
 *  布局：3D 长方体分层 + 流形曲面 + 曲面块（由 app.js 提供）
 *    · L0 顶层领域：竖直堆叠的长方体层，每层独立自转
 *    · L1 子领域：层内流形曲面上的点
 *    · L2+ 子领域：L1 周围的小曲面块
 *    · 卡片：曲面块内网格散布 + 上下起伏
 *
 *  v6.1 新增：
 *    · setData 支持 highlightLayers —— 高亮选中的 L0 层
 *    · _renderLayerBoxes 支持高亮/淡化
 * ============================================================ */
(function (global) {
  'use strict';

  var TAU = Math.PI * 2;

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }

  function hexToRgb(hex) {
    if (!hex) return [125, 155, 255];
    hex = String(hex).replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var n = parseInt(hex, 16);
    if (isNaN(n)) return [125, 155, 255];
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgba(c, a) {
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
  }

  function Galaxy(canvas, options) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');

    this.opts = Object.assign({
      fov: 2400,
      minZoom: 0.05,
      maxZoom: 20.0,
      autoRotate: 0.000012,
      linkLimit: 1200,
      onSelect: null,
      onHover: null
    }, options || {});

    this.nodes = [];
    this.links = [];
    this.byId = new Map();
    this._adj = new Map();

    this.deckTree = null;
    this.highlightLayers = null;  // ★ 新增：Set 或 null
    this.totalTime = 0;

    this.rotY = -0.55;
    this.rotX = 0.32;
    this.rotZ = 0.0;

    this.zoom = 1.0;
    this.targetZoom = 1.0;

    this.panOffsetX = 0;
    this.panOffsetY = 0;
    this.panVelX = 0;
    this.panVelY = 0;

    this.dragging = false;
    this.moved = false;
    this.lastX = 0;
    this.lastY = 0;
    this.hoverId = null;
    this.selectedId = null;

    this.keys = { w:false, a:false, s:false, d:false, q:false, e:false };

    this._focus = null;

    this.pulse = 0;
    this._lastT = 0;

    this.dpr = 1;
    this.W = 0;
    this.H = 0;
    this._proj = [];
    this._bgStars = null;
    this._retryCount = 0;
    this._ro = null;

    this._onDocMove = null;
    this._onDocUp = null;

    this._onResize = this.resize.bind(this);
    this._tick = this.tick.bind(this);

    window.addEventListener('resize', this._onResize);

    if (typeof ResizeObserver === 'function') {
      var self0 = this;
      this._ro = new ResizeObserver(function () { self0.resize(); });
      this._ro.observe(this.canvas);
      if (this.canvas.parentElement) this._ro.observe(this.canvas.parentElement);
    }

    this._bindPointer();
    this._bindKeyboard();

    var g = this;
    this.resize();
    requestAnimationFrame(function () {
      g.resize();
      requestAnimationFrame(function () { g.resize(); });
    });

    this._raf = requestAnimationFrame(this._tick);
  }

  Galaxy.prototype._bindKeyboard = function () {
    var self = this;
    this._onKeyDown = function (e) {
      if (self.canvas.offsetParent === null) return;
      var tag = (e.target.tagName || '').toUpperCase();
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      var k = (e.key || '').toLowerCase();
      if (self.keys.hasOwnProperty(k)) {
        self.keys[k] = true;
        e.preventDefault();
      }
    };
    this._onKeyUp = function (e) {
      var k = (e.key || '').toLowerCase();
      if (self.keys.hasOwnProperty(k)) self.keys[k] = false;
    };
    window.addEventListener('keydown', this._onKeyDown);
    window.addEventListener('keyup', this._onKeyUp);
  };

  Galaxy.prototype.resize = function () {
    var el = this.canvas;
    var w = el.clientWidth;
    var h = el.clientHeight;

    if ((w < 1 || h < 1) && el.parentElement) {
      w = el.parentElement.clientWidth;
      h = el.parentElement.clientHeight;
    }

    if (w < 1 || h < 1) {
      if (this._retryCount < 30) {
        this._retryCount++;
        var self = this;
        setTimeout(function () { self.resize(); }, 50);
      }
      return;
    }
    this._retryCount = 0;

    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = w;
    this.H = h;

    var pw = Math.round(w * this.dpr);
    var ph = Math.round(h * this.dpr);

    if (el.width !== pw || el.height !== ph) {
      el.width = pw;
      el.height = ph;
      this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      this._bgStars = null;
    }
  };

  /**
   * ★ v6.1：新增 highlightLayers 参数
   *   highlightLayers 为 Set 时，只高亮这些 L0 层；
   *   为 null 或空 Set 时全部正常显示。
   */
  Galaxy.prototype.setData = function (nodes, links, deckTree, highlightLayers) {
    var self = this;

    this.nodes = nodes || [];
    this.links = [];
    this.byId = new Map();
    this._adj = new Map();

    if (deckTree) this.deckTree = deckTree;

    // ★ 存储高亮层信息
    if (highlightLayers && highlightLayers.size > 0) {
      this.highlightLayers = highlightLayers;
    } else {
      this.highlightLayers = null;
    }

    this.nodes.forEach(function (n, i) {
      n.index = i;
      n.rgb = hexToRgb(n.color);
      if (n.size == null) n.size = 3.6;
      if (n.phase == null) n.phase = (i * 1.618) % TAU;
      if (typeof n.mastery !== 'number') n.mastery = 0;
      if (typeof n.relX !== 'number') n.relX = 0;
      if (typeof n.relY !== 'number') n.relY = 0;
      if (typeof n.relZ !== 'number') n.relZ = 0;
      self.byId.set(n.id, n);
      self._adj.set(n.id, new Set());
    });

    (links || []).forEach(function (L) {
      var a = self.byId.get(L.a);
      var b = self.byId.get(L.b);
      if (!a || !b || a === b) return;
      L.ai = a.index;
      L.bi = b.index;
      self.links.push(L);
      self._adj.get(L.a).add(L.b);
      self._adj.get(L.b).add(L.a);
    });

    if (this.selectedId && !this.byId.has(this.selectedId)) this.selectedId = null;
    if (this.hoverId && !this.byId.has(this.hoverId)) this.hoverId = null;
  };

  Galaxy.prototype.isLinked = function (a, b) {
    var s = this._adj.get(a);
    return !!(s && s.has(b));
  };

  Galaxy.prototype.select = function (id) {
    this.selectedId = id;
    if (this.opts.onSelect) this.opts.onSelect(id);
  };

  Galaxy.prototype.resetView = function () {
    this.rotY = -0.55;
    this.rotX = 0.32;
    this.rotZ = 0.0;
    this.panOffsetX = 0;
    this.panOffsetY = 0;
    this.panVelX = 0;
    this.panVelY = 0;
    this.targetZoom = 1.0;
    this.fitToContent(1.75);
  };

  Galaxy.prototype._computeDeckTransform = function (deckId, time, cache) {
    if (cache[deckId]) return cache[deckId];

    var tree = this.deckTree;
    var d = tree && tree[deckId];
    if (!d) {
      var zero = { x: 0, y: 0, z: 0, cos: 1, sin: 0 };
      cache[deckId] = zero;
      return zero;
    }

    var p = d.parentId
      ? this._computeDeckTransform(d.parentId, time, cache)
      : { x: 0, y: 0, z: 0, cos: 1, sin: 0 };

    var ang = (d.spinPhase || 0) + (d.spinSpeed || 0) * time;
    var cl = Math.cos(ang), sl = Math.sin(ang);

    var rx = (d.relX || 0) * p.cos - (d.relZ || 0) * p.sin;
    var rz = (d.relX || 0) * p.sin + (d.relZ || 0) * p.cos;

    var wx = p.x + rx;
    var wy = p.y + (d.relY || 0);
    var wz = p.z + rz;

    var cos = p.cos * cl - p.sin * sl;
    var sin = p.sin * cl + p.cos * sl;

    var t = { x: wx, y: wy, z: wz, cos: cos, sin: sin };
    cache[deckId] = t;
    return t;
  };

  Galaxy.prototype._updateNodePositions = function (time) {
    if (!this.deckTree) return;
    var cache = {};
    for (var i = 0; i < this.nodes.length; i++) {
      var n = this.nodes[i];
      if (!n.deckId) continue;
      var t = this._computeDeckTransform(n.deckId, time, cache);
      var rx = n.relX * t.cos - n.relZ * t.sin;
      var rz = n.relX * t.sin + n.relZ * t.cos;
      n.x = t.x + rx;
      n.y = t.y + n.relY;
      n.z = t.z + rz;
    }
  };

  Galaxy.prototype.getDeckWorldPosition = function (deckId) {
    if (!this.deckTree) return null;
    var cache = {};
    var t = this._computeDeckTransform(deckId, this.totalTime || 0, cache);
    return { x: t.x, y: t.y, z: t.z };
  };

  Galaxy.prototype._bindPointer = function () {
    var self = this;
    var c = this.canvas;

    c.style.cursor = 'grab';

    c.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    c.addEventListener('mousedown', function (e) {
      if (e.button !== 0) e.preventDefault();
    });

    function onMove(e) {
      if (!self.dragging) return;
      var dx = e.clientX - self.lastX;
      var dy = e.clientY - self.lastY;
      if (Math.abs(dx) + Math.abs(dy) > 2) self.moved = true;

      self.panOffsetX += dx;
      self.panOffsetY += dy;
      self.panVelX = dx;
      self.panVelY = dy;

      self.lastX = e.clientX;
      self.lastY = e.clientY;
      e.preventDefault();
    }

    function onUp(e) {
      if (!self.dragging) return;
      self.dragging = false;
      c.style.cursor = 'grab';
      document.body.style.userSelect = '';

      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      document.removeEventListener('pointercancel', onUp);

      if (!self.moved) {
        var rect = c.getBoundingClientRect();
        var hit = self._hitTest(e.clientX - rect.left, e.clientY - rect.top);
        self.select(hit ? hit.id : null);
      }
    }

    self._onDocMove = onMove;
    self._onDocUp = onUp;

    c.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;

      self.dragging = true;
      self.moved = false;
      self.lastX = e.clientX;
      self.lastY = e.clientY;
      self.panVelX = 0;
      self.panVelY = 0;

      document.body.style.userSelect = 'none';
      c.style.cursor = 'grabbing';

      document.addEventListener('pointermove', onMove);
      document.addEventListener('pointerup', onUp);
      document.addEventListener('pointercancel', onUp);

      e.preventDefault();
    });

    c.addEventListener('pointermove', function (e) {
      if (self.dragging) return;
      var rect = c.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;
      var hit = self._hitTest(mx, my);
      var id = hit ? hit.id : null;
      if (id !== self.hoverId) {
        self.hoverId = id;
        c.style.cursor = id ? 'pointer' : 'grab';
      }
      if (self.opts.onHover) self.opts.onHover(hit, mx, my);
    });

    c.addEventListener('pointerleave', function () {
      if (self.dragging) return;
      if (self.hoverId) {
        self.hoverId = null;
        if (self.opts.onHover) self.opts.onHover(null);
      }
    });

    c.addEventListener('wheel', function (e) {
      e.preventDefault();

      var delta = e.deltaY;
      if (e.deltaMode === 1) delta *= 16;
      else if (e.deltaMode === 2) delta *= 400;
      delta = Math.max(-400, Math.min(400, delta));

      var k = Math.exp(-delta * 0.0018);
      var oldZoom = self.targetZoom;
      var newZoom = clamp(oldZoom * k, self.opts.minZoom, self.opts.maxZoom);
      if (newZoom === oldZoom) return;

      var rect = c.getBoundingClientRect();
      var mx = e.clientX - rect.left - self.W / 2 - self.panOffsetX;
      var my = e.clientY - rect.top  - self.H / 2 - self.panOffsetY;

      var ratio = 1 - newZoom / oldZoom;
      self.panOffsetX += mx * ratio;
      self.panOffsetY += my * ratio;

      self.targetZoom = newZoom;
    }, { passive: false });
  };

  Galaxy.prototype._hitTest = function (mx, my) {
    var best = null;
    var bestScore = Infinity;

    for (var i = 0; i < this._proj.length; i++) {
      var p = this._proj[i];
      var dx = p.sx - mx;
      var dy = p.sy - my;
      var d2 = dx * dx + dy * dy;

      var hitR = Math.max(14, p.r * 2.6);
      if (d2 > hitR * hitR) continue;

      var score = d2 + Math.max(0, p.z) * 1.6;
      if (score < bestScore) {
        bestScore = score;
        best = p.n;
      }
    }
    return best;
  };

  Galaxy.prototype._worldToScreen = function (x, y, z) {
    var cosY = Math.cos(this.rotY), sinY = Math.sin(this.rotY);
    var cosX = Math.cos(this.rotX), sinX = Math.sin(this.rotX);
    var cosZ = Math.cos(this.rotZ), sinZ = Math.sin(this.rotZ);

    var x1 =  x * cosY + z * sinY;
    var z1 = -x * sinY + z * cosY;
    var y2 = y * cosX - z1 * sinX;
    var z2 = y * sinX + z1 * cosX;
    var x3 = x1 * cosZ - y2 * sinZ;
    var y3 = x1 * sinZ + y2 * cosZ;

    var depth = this.opts.fov + z2;
    if (depth < 80) depth = 80;
    var s = (this.opts.fov / depth) * this.zoom;

    return {
      sx: this.W / 2 + x3 * s + this.panOffsetX,
      sy: this.H / 2 - y3 * s + this.panOffsetY,
      s: s, z: z2
    };
  };

  Galaxy.prototype.focusOn = function (worldPos, targetZoom, duration) {
    if (!worldPos) return;
    targetZoom = targetZoom || Math.max(1.2, this.targetZoom);
    duration = duration || 650;

    var savedZoom = this.zoom;
    this.zoom = targetZoom;
    var p = this._worldToScreen(worldPos.x, worldPos.y, worldPos.z);
    this.zoom = savedZoom;

    var dpx = this.W / 2 - p.sx;
    var dpy = this.H / 2 - p.sy;

    this._focus = {
      startTime: performance.now(),
      duration: duration,
      startZoom: this.zoom,
      endZoom: targetZoom,
      startPanX: this.panOffsetX,
      startPanY: this.panOffsetY,
      endPanX: this.panOffsetX + dpx,
      endPanY: this.panOffsetY + dpy
    };
  };

  Galaxy.prototype.fitToContent = function (padding) {
    padding = padding || 1.75;
    if (!this.nodes.length) return;

    var minX = Infinity, maxX = -Infinity;
    var minY = Infinity, maxY = -Infinity;
    var minZ = Infinity, maxZ = -Infinity;
    for (var i = 0; i < this.nodes.length; i++) {
      var n = this.nodes[i];
      if (n.x < minX) minX = n.x;
      if (n.x > maxX) maxX = n.x;
      if (n.y < minY) minY = n.y;
      if (n.y > maxY) maxY = n.y;
      if (n.z < minZ) minZ = n.z;
      if (n.z > maxZ) maxZ = n.z;
    }

    var w = Math.max(maxX - minX, 1);
    var h = Math.max(maxY - minY, 1);
    var d = Math.max(maxZ - minZ, 1);
    var diag = Math.sqrt(w * w + h * h + d * d);

    var zoomFit = Math.min(this.W, this.H) / (diag * padding);
    var z = clamp(zoomFit, this.opts.minZoom, this.opts.maxZoom);

    this.zoom = z;
    this.targetZoom = z;
    this.panOffsetX = 0;
    this.panOffsetY = 0;

    var cx = (minX + maxX) / 2;
    var cy = (minY + maxY) / 2;
    var cz = (minZ + maxZ) / 2;

    var p0 = this._worldToScreen(cx, cy, cz);
    this.panOffsetX = this.W / 2 - (p0.sx - this.panOffsetX);
    this.panOffsetY = this.H / 2 - (p0.sy - this.panOffsetY);
  };

  Galaxy.prototype.tick = function (t) {
    var dt = this._lastT ? Math.min(48, t - this._lastT) : 16;
    this._lastT = t;
    this.pulse += dt * 0.001;

    var dtSec = dt * 0.001;
    this.totalTime += dtSec;

    if (this.canvas.offsetParent !== null) {
      var rotSpeed = 1.6 * dtSec;
      if (this.keys.a) this.rotY -= rotSpeed;
      if (this.keys.d) this.rotY += rotSpeed;
      if (this.keys.w) this.rotX -= rotSpeed;
      if (this.keys.s) this.rotX += rotSpeed;
      if (this.keys.q) this.rotZ -= rotSpeed;
      if (this.keys.e) this.rotZ += rotSpeed;

      if (!this.dragging && !this._focus) {
        this.panOffsetX += this.panVelX;
        this.panOffsetY += this.panVelY;
        this.panVelX *= 0.88;
        this.panVelY *= 0.88;
        if (Math.abs(this.panVelX) < 0.1) this.panVelX = 0;
        if (Math.abs(this.panVelY) < 0.1) this.panVelY = 0;
      }

      if (this._focus) {
        var f = this._focus;
        var tt = Math.min(1, (performance.now() - f.startTime) / f.duration);
        var ease = tt < 0.5 ? 2 * tt * tt : 1 - Math.pow(-2 * tt + 2, 2) / 2;

        this.zoom = f.startZoom + (f.endZoom - f.startZoom) * ease;
        this.targetZoom = this.zoom;
        this.panOffsetX = f.startPanX + (f.endPanX - f.startPanX) * ease;
        this.panOffsetY = f.startPanY + (f.endPanY - f.startPanY) * ease;

        if (tt >= 1) this._focus = null;
      } else {
        var zoomDiff = Math.abs(this.targetZoom - this.zoom);
        var zl = zoomDiff > 1 ? 0.28 : 0.15;
        this.zoom = lerp(this.zoom, this.targetZoom, zl);
      }

      this.rotX = clamp(this.rotX, -1.36, 1.36);
      this.rotZ = this.rotZ % TAU;

      if (!this.hoverId && !this.selectedId && !this.dragging && !this._focus) {
        var anyKey = this.keys.w || this.keys.a || this.keys.s || this.keys.d;
        if (!anyKey) this.rotY += this.opts.autoRotate * dt;
      }

      this._updateNodePositions(this.totalTime);

      this.render();
    }

    this._raf = requestAnimationFrame(this._tick);
  };

  Galaxy.prototype._getBgStars = function () {
    if (this._bgStars) return this._bgStars;

    var count = clamp(Math.round((this.W * this.H) / 9000), 50, 220);
    var arr = [];
    for (var i = 0; i < count; i++) {
      arr.push({
        x: Math.random(),
        y: Math.random(),
        r: Math.random() * 0.9 + 0.2,
        a: Math.random() * 0.22 + 0.04,
        p: Math.random() * TAU,
        sp: 0.35 + Math.random() * 1.1
      });
    }
    this._bgStars = arr;
    return arr;
  };

  Galaxy.prototype._drawBackdrop = function (ctx) {
    var stars = this._getBgStars();
    var light = document.body.dataset.theme === 'light';

    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var tw = 0.62 + Math.sin(this.pulse * s.sp + s.p) * 0.38;
      ctx.fillStyle = light
        ? 'rgba(60,80,140,' + (s.a * tw * 0.75) + ')'
        : 'rgba(200,215,255,' + (s.a * tw) + ')';
      ctx.beginPath();
      ctx.arc(s.x * this.W, s.y * this.H, s.r, 0, TAU);
      ctx.fill();
    }
  };

  /* ==========================================================
   *  一级容器：长方体边框（★ 支持高亮/淡化）
   * ========================================================== */
  Galaxy.prototype._renderLayerBoxes = function (ctx) {
    if (!this.deckTree) return;
    var ids = Object.keys(this.deckTree);
    if (!ids.length) return;

    var cache = {};

    var EDGES = [
      [0,1],[1,2],[2,3],[3,0],
      [4,5],[5,6],[6,7],[7,4],
      [0,4],[1,5],[2,6],[3,7]
    ];

    var hasFilter = this.highlightLayers && this.highlightLayers.size > 0;

    for (var i = 0; i < ids.length; i++) {
      var id = ids[i];
      var d = this.deckTree[id];
      if (!d || d.kind !== 'layer') continue;

      // ★ 高亮状态：有筛选时，选中层高亮，未选中层极度淡化
      var isHighlighted = !hasFilter || this.highlightLayers.has(id);
      var dimFactor = isHighlighted ? 1.0 : 0.18;

      var t = this._computeDeckTransform(id, this.totalTime, cache);

      var hw = d.radius * 0.94;
      var hh = (d.halfH || 200) * 0.94;
      var hd = d.radius * 0.94;

      var local = [
        [-hw, -hh, -hd], [hw, -hh, -hd], [hw, -hh, hd], [-hw, -hh, hd],
        [-hw,  hh, -hd], [hw,  hh, -hd], [hw,  hh, hd], [-hw,  hh, hd]
      ];

      var proj = [];
      for (var j = 0; j < 8; j++) {
        var c = local[j];
        var rx = c[0] * t.cos - c[2] * t.sin;
        var rz = c[0] * t.sin + c[2] * t.cos;
        var wx = t.x + rx;
        var wy = t.y + c[1];
        var wz = t.z + rz;
        proj.push(this._worldToScreen(wx, wy, wz));
      }

      var rgb = hexToRgb(d.color);

      // 底面 / 顶面
      var faceAlpha = (isHighlighted ? 0.14 : 0.03) * dimFactor;
      ctx.lineWidth = isHighlighted ? 1.1 : 0.7;
      ctx.strokeStyle = 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + faceAlpha.toFixed(3) + ')';
      ctx.beginPath();
      ctx.moveTo(proj[0].sx, proj[0].sy);
      ctx.lineTo(proj[1].sx, proj[1].sy);
      ctx.lineTo(proj[2].sx, proj[2].sy);
      ctx.lineTo(proj[3].sx, proj[3].sy);
      ctx.closePath();
      ctx.moveTo(proj[4].sx, proj[4].sy);
      ctx.lineTo(proj[5].sx, proj[5].sy);
      ctx.lineTo(proj[6].sx, proj[6].sy);
      ctx.lineTo(proj[7].sx, proj[7].sy);
      ctx.closePath();
      ctx.stroke();

      // 竖边
      var edgeAlpha = (isHighlighted ? 0.32 : 0.06) * dimFactor;
      ctx.lineWidth = isHighlighted ? 1.4 : 0.85;
      ctx.strokeStyle = 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + edgeAlpha.toFixed(3) + ')';
      ctx.beginPath();
      for (var k = 8; k < 12; k++) {
        var e = EDGES[k];
        ctx.moveTo(proj[e[0]].sx, proj[e[0]].sy);
        ctx.lineTo(proj[e[1]].sx, proj[e[1]].sy);
      }
      ctx.stroke();

      // 顶面光晕（仅高亮层）
      if (isHighlighted) {
        var topCenter = { x: t.x, y: t.y + hh, z: t.z };
        var pc = this._worldToScreen(topCenter.x, topCenter.y, topCenter.z);
        var grad = ctx.createRadialGradient(pc.sx, pc.sy, 0, pc.sx, pc.sy, hw * pc.s * 0.9);
        grad.addColorStop(0, 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',0.09)');
        grad.addColorStop(1, 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(pc.sx, pc.sy, hw * pc.s * 0.9, 0, TAU);
        ctx.fill();
      }
    }
  };

  Galaxy.prototype._renderDeckLinks = function (ctx) {
    if (!this.deckTree) return;

    var ids = Object.keys(this.deckTree);
    if (ids.length < 2) return;

    var hasFilter = this.highlightLayers && this.highlightLayers.size > 0;
    var cache = {};
    var proj  = {};

    for (var i = 0; i < ids.length; i++) {
      var id = ids[i];
      var t  = this._computeDeckTransform(id, this.totalTime, cache);
      proj[id] = this._worldToScreen(t.x, t.y, t.z);
    }

    ctx.lineCap = 'round';

    for (var j = 0; j < ids.length; j++) {
      var cid = ids[j];
      var d   = this.deckTree[cid];
      if (!d || !d.parentId) continue;

      var pp = proj[d.parentId];
      var cp = proj[cid];
      if (!pp || !cp) continue;

      var dx = cp.sx - pp.sx;
      var dy = cp.sy - pp.sy;
      if (dx * dx + dy * dy < 64) continue;

      var level = d.level || 1;

      // ★ 若筛选生效，非选中层内的连线极度淡化
      var dimFactor = 1.0;
      if (hasFilter) {
        // 向上找到所属 L0 层
        var cur = d;
        var guard = 0;
        while (cur && cur.parentId && guard++ < 100) {
          var p = this.deckTree[cur.parentId];
          if (!p) break;
          cur = p;
        }
        if (!this.highlightLayers.has(cur.id)) dimFactor = 0.15;
      }

      var baseAlpha = level === 1 ? 0.24
                    : level === 2 ? 0.14
                    : 0.08;

      var depFade = clamp(1.35 - ((pp.z + cp.z) * 0.5) / 1400, 0.32, 1.15);
      var alpha   = baseAlpha * depFade * dimFactor;
      if (alpha < 0.02) continue;

      var rgb = hexToRgb(d.color);

      ctx.strokeStyle = 'rgba(' +
        rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + alpha.toFixed(3) + ')';
      ctx.lineWidth = Math.max(0.55, 1.6 - level * 0.3);

      ctx.beginPath();
      ctx.moveTo(pp.sx, pp.sy);
      ctx.lineTo(cp.sx, cp.sy);
      ctx.stroke();
    }
  };

  Galaxy.prototype.render = function () {
    var ctx = this.ctx;
    var W = this.W;
    var H = this.H;

    if (W < 1 || H < 1) return;

    ctx.clearRect(0, 0, W, H);
    this._drawBackdrop(ctx);

    var hasTree = this.deckTree && Object.keys(this.deckTree).length > 1;
    if (!this.nodes.length && !hasTree) return;

    this._renderLayerBoxes(ctx);
    this._renderDeckLinks(ctx);

    if (!this.nodes.length) return;

    var cx = W / 2;
    var cy = H / 2;
    var fov = this.opts.fov;
    var zoom = this.zoom;

    var cosY = Math.cos(this.rotY), sinY = Math.sin(this.rotY);
    var cosX = Math.cos(this.rotX), sinX = Math.sin(this.rotX);
    var cosZ = Math.cos(this.rotZ), sinZ = Math.sin(this.rotZ);

    var proj = this._proj;
    proj.length = 0;

    for (var i = 0; i < this.nodes.length; i++) {
      var n = this.nodes[i];

      var x1 =  n.x * cosY + n.z * sinY;
      var z1 = -n.x * sinY + n.z * cosY;
      var y2 = n.y * cosX - z1 * sinX;
      var z2 = n.y * sinX + z1 * cosX;
      var x3 = x1 * cosZ - y2 * sinZ;
      var y3 = x1 * sinZ + y2 * cosZ;

      var depth = fov + z2;
      if (depth < 80) depth = 80;

      var s = (fov / depth) * zoom;
      var sx = cx + x3 * s + this.panOffsetX;
      var sy = cy - y3 * s + this.panOffsetY;

      if (sx < -120 || sx > W + 120 || sy < -120 || sy > H + 120) continue;
      if (depth > fov * 2.5) continue;

      proj.push({
        n: n,
        sx: sx,
        sy: sy,
        s: s,
        z: z2,
        r: Math.max(0.85, n.size * s)
      });
    }

    var active = this.hoverId || this.selectedId;
    var self = this;

    var isMassive = proj.length > 1500;
    var showLinks = this.links.length <= this.opts.linkLimit;

    if (showLinks) {
      ctx.lineCap = 'round';
      for (var k = 0; k < this.links.length; k++) {
        var L = this.links[k];
        var a = proj[L.ai];
        var b = proj[L.bi];
        if (!a || !b) continue;

        var isAct = active && (L.a === active || L.b === active);
        if (isMassive && !isAct) continue;

        var ma = a.n.mastery || 0;
        var mb = b.n.mastery || 0;
        var linkM = Math.min(ma, mb);

        var alpha;
        if (active) {
          alpha = isAct ? 0.85 : 0.10;
        } else {
          alpha = (0.12 + linkM * 0.5) * (L.w || 0.5) + 0.06;
        }

        var dep = clamp(1.2 - ((a.z + b.z) * 0.5) / 900, 0.35, 1.2);
        alpha *= dep;
        if (alpha < 0.025) continue;

        ctx.strokeStyle = isAct
          ? 'rgba(180,205,255,' + alpha.toFixed(3) + ')'
          : 'rgba(130,158,215,' + alpha.toFixed(3) + ')';
        ctx.lineWidth = isAct ? 1.8 : 0.9;

        ctx.beginPath();
        ctx.moveTo(a.sx, a.sy);
        ctx.lineTo(b.sx, b.sy);
        ctx.stroke();
      }
    }

    var order = proj;
    if (proj.length > 800) {
      order.sort(function (p, q) { return q.z - p.z; });
    } else {
      order = proj.slice().sort(function (p, q) { return q.z - p.z; });
    }

    for (var j = 0; j < order.length; j++) {
      var p = order[j];
      var node = p.n;
      var mastery = typeof node.mastery === 'number' ? node.mastery : 0;

      var isHover = node.id === this.hoverId;
      var isSel   = node.id === this.selectedId;
      var isAct   = isHover || isSel;

      var isFar = p.s < 0.15 || (isMassive && !isAct && !this.isLinked(active, node.id));

      var alphaN = 0.55 + mastery * 0.45;

      if (active) {
        if (isAct) alphaN = 1;
        else if (self.isLinked(active, node.id)) alphaN = Math.max(alphaN, 0.78);
        else alphaN = Math.min(alphaN, 0.30);
      }

      alphaN *= clamp(0.75 + p.s * 0.35, 0.70, 1.10);

      var breathe = 1 + Math.sin(this.pulse * 1.7 + node.phase) * 0.085;
      var R = p.r * (isAct ? 1.7 : 1) * breathe;

      if (!isFar && R * 4.2 > 2.0) {
        var glowStrength = isAct ? 1 : (0.35 + mastery * 0.65);
        var glowR = R * 4.2 * (0.75 + glowStrength * 0.55);
        var g2 = ctx.createRadialGradient(p.sx, p.sy, 0, p.sx, p.sy, glowR);
        g2.addColorStop(0,    rgba(node.rgb, 0.45 * alphaN * glowStrength));
        g2.addColorStop(0.32, rgba(node.rgb, 0.15 * alphaN * glowStrength));
        g2.addColorStop(1,    rgba(node.rgb, 0));
        ctx.fillStyle = g2;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, glowR, 0, TAU);
        ctx.fill();
      }

      ctx.fillStyle = 'rgba(255,255,255,' + Math.min(1, 0.95 * alphaN).toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(p.sx, p.sy, Math.max(0.7, R * 0.50), 0, TAU);
      ctx.fill();

      if (!isFar) {
        ctx.strokeStyle = rgba(node.rgb, (0.60 + mastery * 0.40) * alphaN);
        ctx.lineWidth = Math.max(0.9, R * 0.24);
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, R, 0, TAU);
        ctx.stroke();
      }

      if (isSel) {
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.60 * alphaN).toFixed(3) + ')';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, R * 2.2, 0, TAU);
        ctx.stroke();
      }
    }
  };

  Galaxy.prototype.destroy = function () {
    cancelAnimationFrame(this._raf);
    window.removeEventListener('resize', this._onResize);
    window.removeEventListener('keydown', this._onKeyDown);
    window.removeEventListener('keyup', this._onKeyUp);
    if (this._ro) { this._ro.disconnect(); this._ro = null; }
    if (this._onDocMove) document.removeEventListener('pointermove', this._onDocMove);
    if (this._onDocUp) {
      document.removeEventListener('pointerup', this._onDocUp);
      document.removeEventListener('pointercancel', this._onDocUp);
    }
  };

  global.Galaxy = Galaxy;

})(window);