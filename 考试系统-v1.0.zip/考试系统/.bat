@echo off
chcp 65001 >nul 2>nul
setlocal EnableDelayedExpansion
title 《机器学习》智能试卷系统 · 一键启动

cd /d "%~dp0"

echo.
echo  ==========================================================
echo    《机器学习》智能试卷系统  ·  本地一键启动
echo  ==========================================================
echo.

:: ---------- 1. 主页面 ----------
set "PAGE="
if exist "index.html" set "PAGE=index.html"
if not defined PAGE if exist "inde.html" set "PAGE=inde.html"
if not defined PAGE (
    echo   [X] 未找到 index.html 或 inde.html
    echo       请把本脚本与网页文件放在同一个文件夹中。
    echo.
    pause
    exit /b 1
)
echo   [1/4] 主页面    :  %PAGE%

:: ---------- 2. 历史数据 ----------
set "DATA=ml-exam-data.json"
if exist "%DATA%" (
    echo   [2/4] 历史数据  :  %DATA%   ^(已找到，将自动加载^)
) else (
    echo   [2/4] 历史数据  :  暂无，首次保存时自动创建
)

:: ---------- 3. 空闲端口 ----------
set /a PORT=8080
:PORT_LOOP
netstat -an 2>nul | findstr /c:":!PORT! " | findstr /i "LISTENING" >nul 2>nul
if not errorlevel 1 (
    set /a PORT+=1
    if !PORT! gtr 8180 (
        echo   [X] 端口 8080-8180 全部被占用，请关闭占用程序后重试。
        echo.
        pause
        exit /b 1
    )
    goto PORT_LOOP
)
echo   [3/4] 服务端口  :  !PORT!

:: ---------- 4. 运行时 ----------
where node >nul 2>nul && set "RUNNER=node"
if not defined RUNNER where python >nul 2>nul && set "RUNNER=python"
if not defined RUNNER where py >nul 2>nul && set "RUNNER=py"
if not defined RUNNER set "RUNNER=none"
echo   [4/4] 运行时    :  !RUNNER!

:: ---------- 启动 ----------
if /i "!RUNNER!"=="node" (
    if not exist "server.js" (
        echo.
        echo   [!] 未找到 server.js
        echo       请把 server.js 与本脚本放在同一目录，才能启用数据自动读写。
        echo       否则将退化为只读静态服务。
        echo.
        start "ML-Exam-Server" node -e "const http=require('http'),fs=require('fs'),path=require('path'),P=!PORT!;const M={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8'};http.createServer((q,s)=>{let u=decodeURIComponent((q.url||'/').split('?')[0]);if(u==='/')u='/index.html';const fp=path.join(process.cwd(),u);fs.readFile(fp,(e,d)=>{if(e){s.writeHead(404);return s.end('404')}s.writeHead(200,{'Content-Type':M[path.extname(fp).toLowerCase()]||'application/octet-stream','Cache-Control':'no-store'});s.end(d)})}).listen(P,'127.0.0.1')"
    ) else (
        start "ML-Exam-Server" node server.js !PORT!
    )
    goto :LAUNCH
)

if /i "!RUNNER!"=="python" (
    echo   [!] Python 模式仅支持只读加载，无法回写历史文件。
    start "ML-Exam-Server" python -m http.server !PORT! --bind 127.0.0.1
    goto :LAUNCH
)

if /i "!RUNNER!"=="py" (
    echo   [!] Python 模式仅支持只读加载，无法回写历史文件。
    start "ML-Exam-Server" py -m http.server !PORT! --bind 127.0.0.1
    goto :LAUNCH
)

echo   [!] 未检测到 Node.js / Python，改为直接打开本地文件。
echo       建议安装 Node.js 后重新运行，可获得完整的数据自动同步。
echo.
start "" "%~dp0%PAGE%"
pause
exit /b 0

:LAUNCH
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:!PORT!/!PAGE!"

echo.
echo  ==========================================================
echo    服务已启动  ^>^>  http://127.0.0.1:!PORT!/!PAGE!
echo    浏览器已自动打开，若未弹出请手动复制地址访问。
echo.
echo    · 页面打开后会自动加载 ml-exam-data.json
echo    · 关闭标题为 "ML-Exam-Server" 的窗口即停止服务
echo    · 本窗口可以直接关闭
echo  ==========================================================
echo.
timeout /t 6 /nobreak >nul
exit /b 0