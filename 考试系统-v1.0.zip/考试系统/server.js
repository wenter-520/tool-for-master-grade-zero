/* server.js — 《机器学习》智能试卷系统本地服务
 * 静态文件 + 数据读写 API
 * 启动：node server.js [端口]
 */
const http = require('http');
const fs   = require('fs');
const path = require('path');
const url  = require('url');

const PORT      = parseInt(process.argv[2], 10) || 8080;
const ROOT      = process.cwd();
const DATA_FILE = path.join(ROOT, 'ml-exam-data.json');
const MAX_BODY  = 30 * 1024 * 1024;   // 30MB

const MIME = {
  '.html':'text/html; charset=utf-8',
  '.htm' :'text/html; charset=utf-8',
  '.js'  :'text/javascript; charset=utf-8',
  '.mjs' :'text/javascript; charset=utf-8',
  '.css' :'text/css; charset=utf-8',
  '.json':'application/json; charset=utf-8',
  '.svg' :'image/svg+xml',
  '.png' :'image/png',
  '.jpg' :'image/jpeg',
  '.jpeg':'image/jpeg',
  '.gif' :'image/gif',
  '.ico' :'image/x-icon',
  '.woff':'font/woff',
  '.woff2':'font/woff2',
  '.tex' :'text/plain; charset=utf-8',
  '.txt' :'text/plain; charset=utf-8'
};

function send(res, code, body, type) {
  res.writeHead(code, {
    'Content-Type': type || 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(body);
}
function sendJSON(res, code, obj) {
  send(res, code, JSON.stringify(obj), 'application/json; charset=utf-8');
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('payload too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    req.on('error', reject);
  });
}

function streamFile(res, fp) {
  const ext = path.extname(fp).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': 'no-store'
  });
  fs.createReadStream(fp).pipe(res);
}

function serveStatic(req, res, pathname) {
  let p = decodeURIComponent(pathname);
  if (p === '/' || p === '') p = '/index.html';
  const fp = path.resolve(ROOT, '.' + p);
  if (!fp.startsWith(ROOT)) return send(res, 403, 'Forbidden');

  fs.stat(fp, (err, st) => {
    if (err || !st.isFile()) {
      // 若请求 index.html 但不存在，回退 inde.html
      if (p === '/index.html') {
        const alt = path.join(ROOT, 'inde.html');
        fs.stat(alt, (e2, s2) => {
          if (!e2 && s2.isFile()) return streamFile(res, alt);
          send(res, 404, '404 Not Found');
        });
        return;
      }
      return send(res, 404, '404 Not Found');
    }
    streamFile(res, fp);
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,PUT,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  /* ---------- API ---------- */
  if (pathname === '/api/ping') {
    return sendJSON(res, 200, {
      ok: true, service: 'ml-exam-server', version: 2,
      dataFile: path.basename(DATA_FILE), time: Date.now()
    });
  }

  if (pathname === '/api/meta') {
    fs.stat(DATA_FILE, (err, st) => {
      if (err) return sendJSON(res, 200, { ok: true, exists: false });
      sendJSON(res, 200, { ok: true, exists: true, size: st.size, mtime: st.mtimeMs });
    });
    return;
  }

  if (pathname === '/api/data') {
    if (req.method === 'GET') {
      fs.readFile(DATA_FILE, 'utf-8', (err, txt) => {
        if (err) return sendJSON(res, 404, { ok: false, error: 'no-data-file' });
        try { sendJSON(res, 200, JSON.parse(txt)); }
        catch (e) { sendJSON(res, 500, { ok: false, error: 'invalid-json' }); }
      });
      return;
    }
    if (req.method === 'PUT' || req.method === 'POST') {
      try {
        const body = await readBody(req);
        const obj  = JSON.parse(body);            // 只接受合法 JSON
        const tmp  = DATA_FILE + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), 'utf-8');
        fs.renameSync(tmp, DATA_FILE);            // 原子替换
        sendJSON(res, 200, { ok: true, savedAt: Date.now(), bytes: body.length });
      } catch (e) {
        sendJSON(res, 400, { ok: false, error: e.message });
      }
      return;
    }
    return sendJSON(res, 405, { ok: false, error: 'method-not-allowed' });
  }

  /* ---------- 静态文件 ---------- */
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, 'Method Not Allowed');
  }
  serveStatic(req, res, pathname);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  ML-Exam-Server 已启动');
  console.log('  → http://127.0.0.1:' + PORT);
  console.log('  数据文件：' + DATA_FILE);
  console.log('  按 Ctrl+C 停止服务');
  console.log('');
});
server.on('error', e => {
  console.error('Server error:', e.message);
  process.exit(1);
});